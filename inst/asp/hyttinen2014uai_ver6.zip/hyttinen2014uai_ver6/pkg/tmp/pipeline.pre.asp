node(1..12).

ismember(1,1). 
ismember(2,2). 
ismember(3,1). ismember(3,2). 
ismember(4,3). 
ismember(5,1). ismember(5,3). 
ismember(6,2). ismember(6,3). 
ismember(7,1). ismember(7,2). ismember(7,3). 
ismember(8,4). 
ismember(9,1). ismember(9,4). 
ismember(10,2). ismember(10,4). 
ismember(11,1). ismember(11,2). ismember(11,4). 
ismember(12,3). ismember(12,4). 
ismember(13,1). ismember(13,3). ismember(13,4). 
ismember(14,2). ismember(14,3). ismember(14,4). 
ismember(15,1). ismember(15,2). ismember(15,3). ismember(15,4). 
ismember(16,5). 
ismember(17,1). ismember(17,5). 
ismember(18,2). ismember(18,5). 
ismember(19,1). ismember(19,2). ismember(19,5). 
ismember(20,3). ismember(20,5). 
ismember(21,1). ismember(21,3). ismember(21,5). 
ismember(22,2). ismember(22,3). ismember(22,5). 
ismember(23,1). ismember(23,2). ismember(23,3). ismember(23,5). 
ismember(24,4). ismember(24,5). 
ismember(25,1). ismember(25,4). ismember(25,5). 
ismember(26,2). ismember(26,4). ismember(26,5). 
ismember(27,1). ismember(27,2). ismember(27,4). ismember(27,5). 
ismember(28,3). ismember(28,4). ismember(28,5). 
ismember(29,1). ismember(29,3). ismember(29,4). ismember(29,5). 
ismember(30,2). ismember(30,3). ismember(30,4). ismember(30,5). 
ismember(31,1). ismember(31,2). ismember(31,3). ismember(31,4). ismember(31,5). 
ismember(32,6). 
ismember(33,1). ismember(33,6). 
ismember(34,2). ismember(34,6). 
ismember(35,1). ismember(35,2). ismember(35,6). 
ismember(36,3). ismember(36,6). 
ismember(37,1). ismember(37,3). ismember(37,6). 
ismember(38,2). ismember(38,3). ismember(38,6). 
ismember(39,1). ismember(39,2). ismember(39,3). ismember(39,6). 
ismember(40,4). ismember(40,6). 
ismember(41,1). ismember(41,4). ismember(41,6). 
ismember(42,2). ismember(42,4). ismember(42,6). 
ismember(43,1). ismember(43,2). ismember(43,4). ismember(43,6). 
ismember(44,3). ismember(44,4). ismember(44,6). 
ismember(45,1). ismember(45,3). ismember(45,4). ismember(45,6). 
ismember(46,2). ismember(46,3). ismember(46,4). ismember(46,6). 
ismember(47,1). ismember(47,2). ismember(47,3). ismember(47,4). ismember(47,6). 
ismember(48,5). ismember(48,6). 
ismember(49,1). ismember(49,5). ismember(49,6). 
ismember(50,2). ismember(50,5). ismember(50,6). 
ismember(51,1). ismember(51,2). ismember(51,5). ismember(51,6). 
ismember(52,3). ismember(52,5). ismember(52,6). 
ismember(53,1). ismember(53,3). ismember(53,5). ismember(53,6). 
ismember(54,2). ismember(54,3). ismember(54,5). ismember(54,6). 
ismember(55,1). ismember(55,2). ismember(55,3). ismember(55,5). ismember(55,6). 
ismember(56,4). ismember(56,5). ismember(56,6). 
ismember(57,1). ismember(57,4). ismember(57,5). ismember(57,6). 
ismember(58,2). ismember(58,4). ismember(58,5). ismember(58,6). 
ismember(59,1). ismember(59,2). ismember(59,4). ismember(59,5). ismember(59,6). 
ismember(60,3). ismember(60,4). ismember(60,5). ismember(60,6). 
ismember(61,1). ismember(61,3). ismember(61,4). ismember(61,5). ismember(61,6). 
ismember(62,2). ismember(62,3). ismember(62,4). ismember(62,5). ismember(62,6). 
ismember(63,1). ismember(63,2). ismember(63,3). ismember(63,4). ismember(63,5). ismember(63,6). 
ismember(64,7). 
ismember(65,1). ismember(65,7). 
ismember(66,2). ismember(66,7). 
ismember(67,1). ismember(67,2). ismember(67,7). 
ismember(68,3). ismember(68,7). 
ismember(69,1). ismember(69,3). ismember(69,7). 
ismember(70,2). ismember(70,3). ismember(70,7). 
ismember(71,1). ismember(71,2). ismember(71,3). ismember(71,7). 
ismember(72,4). ismember(72,7). 
ismember(73,1). ismember(73,4). ismember(73,7). 
ismember(74,2). ismember(74,4). ismember(74,7). 
ismember(75,1). ismember(75,2). ismember(75,4). ismember(75,7). 
ismember(76,3). ismember(76,4). ismember(76,7). 
ismember(77,1). ismember(77,3). ismember(77,4). ismember(77,7). 
ismember(78,2). ismember(78,3). ismember(78,4). ismember(78,7). 
ismember(79,1). ismember(79,2). ismember(79,3). ismember(79,4). ismember(79,7). 
ismember(80,5). ismember(80,7). 
ismember(81,1). ismember(81,5). ismember(81,7). 
ismember(82,2). ismember(82,5). ismember(82,7). 
ismember(83,1). ismember(83,2). ismember(83,5). ismember(83,7). 
ismember(84,3). ismember(84,5). ismember(84,7). 
ismember(85,1). ismember(85,3). ismember(85,5). ismember(85,7). 
ismember(86,2). ismember(86,3). ismember(86,5). ismember(86,7). 
ismember(87,1). ismember(87,2). ismember(87,3). ismember(87,5). ismember(87,7). 
ismember(88,4). ismember(88,5). ismember(88,7). 
ismember(89,1). ismember(89,4). ismember(89,5). ismember(89,7). 
ismember(90,2). ismember(90,4). ismember(90,5). ismember(90,7). 
ismember(91,1). ismember(91,2). ismember(91,4). ismember(91,5). ismember(91,7). 
ismember(92,3). ismember(92,4). ismember(92,5). ismember(92,7). 
ismember(93,1). ismember(93,3). ismember(93,4). ismember(93,5). ismember(93,7). 
ismember(94,2). ismember(94,3). ismember(94,4). ismember(94,5). ismember(94,7). 
ismember(95,1). ismember(95,2). ismember(95,3). ismember(95,4). ismember(95,5). ismember(95,7). 
ismember(96,6). ismember(96,7). 
ismember(97,1). ismember(97,6). ismember(97,7). 
ismember(98,2). ismember(98,6). ismember(98,7). 
ismember(99,1). ismember(99,2). ismember(99,6). ismember(99,7). 
ismember(100,3). ismember(100,6). ismember(100,7). 
ismember(101,1). ismember(101,3). ismember(101,6). ismember(101,7). 
ismember(102,2). ismember(102,3). ismember(102,6). ismember(102,7). 
ismember(103,1). ismember(103,2). ismember(103,3). ismember(103,6). ismember(103,7). 
ismember(104,4). ismember(104,6). ismember(104,7). 
ismember(105,1). ismember(105,4). ismember(105,6). ismember(105,7). 
ismember(106,2). ismember(106,4). ismember(106,6). ismember(106,7). 
ismember(107,1). ismember(107,2). ismember(107,4). ismember(107,6). ismember(107,7). 
ismember(108,3). ismember(108,4). ismember(108,6). ismember(108,7). 
ismember(109,1). ismember(109,3). ismember(109,4). ismember(109,6). ismember(109,7). 
ismember(110,2). ismember(110,3). ismember(110,4). ismember(110,6). ismember(110,7). 
ismember(111,1). ismember(111,2). ismember(111,3). ismember(111,4). ismember(111,6). ismember(111,7). 
ismember(112,5). ismember(112,6). ismember(112,7). 
ismember(113,1). ismember(113,5). ismember(113,6). ismember(113,7). 
ismember(114,2). ismember(114,5). ismember(114,6). ismember(114,7). 
ismember(115,1). ismember(115,2). ismember(115,5). ismember(115,6). ismember(115,7). 
ismember(116,3). ismember(116,5). ismember(116,6). ismember(116,7). 
ismember(117,1). ismember(117,3). ismember(117,5). ismember(117,6). ismember(117,7). 
ismember(118,2). ismember(118,3). ismember(118,5). ismember(118,6). ismember(118,7). 
ismember(119,1). ismember(119,2). ismember(119,3). ismember(119,5). ismember(119,6). ismember(119,7). 
ismember(120,4). ismember(120,5). ismember(120,6). ismember(120,7). 
ismember(121,1). ismember(121,4). ismember(121,5). ismember(121,6). ismember(121,7). 
ismember(122,2). ismember(122,4). ismember(122,5). ismember(122,6). ismember(122,7). 
ismember(123,1). ismember(123,2). ismember(123,4). ismember(123,5). ismember(123,6). ismember(123,7). 
ismember(124,3). ismember(124,4). ismember(124,5). ismember(124,6). ismember(124,7). 
ismember(125,1). ismember(125,3). ismember(125,4). ismember(125,5). ismember(125,6). ismember(125,7). 
ismember(126,2). ismember(126,3). ismember(126,4). ismember(126,5). ismember(126,6). ismember(126,7). 
ismember(127,1). ismember(127,2). ismember(127,3). ismember(127,4). ismember(127,5). ismember(127,6). ismember(127,7). 
ismember(128,8). 
ismember(129,1). ismember(129,8). 
ismember(130,2). ismember(130,8). 
ismember(131,1). ismember(131,2). ismember(131,8). 
ismember(132,3). ismember(132,8). 
ismember(133,1). ismember(133,3). ismember(133,8). 
ismember(134,2). ismember(134,3). ismember(134,8). 
ismember(135,1). ismember(135,2). ismember(135,3). ismember(135,8). 
ismember(136,4). ismember(136,8). 
ismember(137,1). ismember(137,4). ismember(137,8). 
ismember(138,2). ismember(138,4). ismember(138,8). 
ismember(139,1). ismember(139,2). ismember(139,4). ismember(139,8). 
ismember(140,3). ismember(140,4). ismember(140,8). 
ismember(141,1). ismember(141,3). ismember(141,4). ismember(141,8). 
ismember(142,2). ismember(142,3). ismember(142,4). ismember(142,8). 
ismember(143,1). ismember(143,2). ismember(143,3). ismember(143,4). ismember(143,8). 
ismember(144,5). ismember(144,8). 
ismember(145,1). ismember(145,5). ismember(145,8). 
ismember(146,2). ismember(146,5). ismember(146,8). 
ismember(147,1). ismember(147,2). ismember(147,5). ismember(147,8). 
ismember(148,3). ismember(148,5). ismember(148,8). 
ismember(149,1). ismember(149,3). ismember(149,5). ismember(149,8). 
ismember(150,2). ismember(150,3). ismember(150,5). ismember(150,8). 
ismember(151,1). ismember(151,2). ismember(151,3). ismember(151,5). ismember(151,8). 
ismember(152,4). ismember(152,5). ismember(152,8). 
ismember(153,1). ismember(153,4). ismember(153,5). ismember(153,8). 
ismember(154,2). ismember(154,4). ismember(154,5). ismember(154,8). 
ismember(155,1). ismember(155,2). ismember(155,4). ismember(155,5). ismember(155,8). 
ismember(156,3). ismember(156,4). ismember(156,5). ismember(156,8). 
ismember(157,1). ismember(157,3). ismember(157,4). ismember(157,5). ismember(157,8). 
ismember(158,2). ismember(158,3). ismember(158,4). ismember(158,5). ismember(158,8). 
ismember(159,1). ismember(159,2). ismember(159,3). ismember(159,4). ismember(159,5). ismember(159,8). 
ismember(160,6). ismember(160,8). 
ismember(161,1). ismember(161,6). ismember(161,8). 
ismember(162,2). ismember(162,6). ismember(162,8). 
ismember(163,1). ismember(163,2). ismember(163,6). ismember(163,8). 
ismember(164,3). ismember(164,6). ismember(164,8). 
ismember(165,1). ismember(165,3). ismember(165,6). ismember(165,8). 
ismember(166,2). ismember(166,3). ismember(166,6). ismember(166,8). 
ismember(167,1). ismember(167,2). ismember(167,3). ismember(167,6). ismember(167,8). 
ismember(168,4). ismember(168,6). ismember(168,8). 
ismember(169,1). ismember(169,4). ismember(169,6). ismember(169,8). 
ismember(170,2). ismember(170,4). ismember(170,6). ismember(170,8). 
ismember(171,1). ismember(171,2). ismember(171,4). ismember(171,6). ismember(171,8). 
ismember(172,3). ismember(172,4). ismember(172,6). ismember(172,8). 
ismember(173,1). ismember(173,3). ismember(173,4). ismember(173,6). ismember(173,8). 
ismember(174,2). ismember(174,3). ismember(174,4). ismember(174,6). ismember(174,8). 
ismember(175,1). ismember(175,2). ismember(175,3). ismember(175,4). ismember(175,6). ismember(175,8). 
ismember(176,5). ismember(176,6). ismember(176,8). 
ismember(177,1). ismember(177,5). ismember(177,6). ismember(177,8). 
ismember(178,2). ismember(178,5). ismember(178,6). ismember(178,8). 
ismember(179,1). ismember(179,2). ismember(179,5). ismember(179,6). ismember(179,8). 
ismember(180,3). ismember(180,5). ismember(180,6). ismember(180,8). 
ismember(181,1). ismember(181,3). ismember(181,5). ismember(181,6). ismember(181,8). 
ismember(182,2). ismember(182,3). ismember(182,5). ismember(182,6). ismember(182,8). 
ismember(183,1). ismember(183,2). ismember(183,3). ismember(183,5). ismember(183,6). ismember(183,8). 
ismember(184,4). ismember(184,5). ismember(184,6). ismember(184,8). 
ismember(185,1). ismember(185,4). ismember(185,5). ismember(185,6). ismember(185,8). 
ismember(186,2). ismember(186,4). ismember(186,5). ismember(186,6). ismember(186,8). 
ismember(187,1). ismember(187,2). ismember(187,4). ismember(187,5). ismember(187,6). ismember(187,8). 
ismember(188,3). ismember(188,4). ismember(188,5). ismember(188,6). ismember(188,8). 
ismember(189,1). ismember(189,3). ismember(189,4). ismember(189,5). ismember(189,6). ismember(189,8). 
ismember(190,2). ismember(190,3). ismember(190,4). ismember(190,5). ismember(190,6). ismember(190,8). 
ismember(191,1). ismember(191,2). ismember(191,3). ismember(191,4). ismember(191,5). ismember(191,6). ismember(191,8). 
ismember(192,7). ismember(192,8). 
ismember(193,1). ismember(193,7). ismember(193,8). 
ismember(194,2). ismember(194,7). ismember(194,8). 
ismember(195,1). ismember(195,2). ismember(195,7). ismember(195,8). 
ismember(196,3). ismember(196,7). ismember(196,8). 
ismember(197,1). ismember(197,3). ismember(197,7). ismember(197,8). 
ismember(198,2). ismember(198,3). ismember(198,7). ismember(198,8). 
ismember(199,1). ismember(199,2). ismember(199,3). ismember(199,7). ismember(199,8). 
ismember(200,4). ismember(200,7). ismember(200,8). 
ismember(201,1). ismember(201,4). ismember(201,7). ismember(201,8). 
ismember(202,2). ismember(202,4). ismember(202,7). ismember(202,8). 
ismember(203,1). ismember(203,2). ismember(203,4). ismember(203,7). ismember(203,8). 
ismember(204,3). ismember(204,4). ismember(204,7). ismember(204,8). 
ismember(205,1). ismember(205,3). ismember(205,4). ismember(205,7). ismember(205,8). 
ismember(206,2). ismember(206,3). ismember(206,4). ismember(206,7). ismember(206,8). 
ismember(207,1). ismember(207,2). ismember(207,3). ismember(207,4). ismember(207,7). ismember(207,8). 
ismember(208,5). ismember(208,7). ismember(208,8). 
ismember(209,1). ismember(209,5). ismember(209,7). ismember(209,8). 
ismember(210,2). ismember(210,5). ismember(210,7). ismember(210,8). 
ismember(211,1). ismember(211,2). ismember(211,5). ismember(211,7). ismember(211,8). 
ismember(212,3). ismember(212,5). ismember(212,7). ismember(212,8). 
ismember(213,1). ismember(213,3). ismember(213,5). ismember(213,7). ismember(213,8). 
ismember(214,2). ismember(214,3). ismember(214,5). ismember(214,7). ismember(214,8). 
ismember(215,1). ismember(215,2). ismember(215,3). ismember(215,5). ismember(215,7). ismember(215,8). 
ismember(216,4). ismember(216,5). ismember(216,7). ismember(216,8). 
ismember(217,1). ismember(217,4). ismember(217,5). ismember(217,7). ismember(217,8). 
ismember(218,2). ismember(218,4). ismember(218,5). ismember(218,7). ismember(218,8). 
ismember(219,1). ismember(219,2). ismember(219,4). ismember(219,5). ismember(219,7). ismember(219,8). 
ismember(220,3). ismember(220,4). ismember(220,5). ismember(220,7). ismember(220,8). 
ismember(221,1). ismember(221,3). ismember(221,4). ismember(221,5). ismember(221,7). ismember(221,8). 
ismember(222,2). ismember(222,3). ismember(222,4). ismember(222,5). ismember(222,7). ismember(222,8). 
ismember(223,1). ismember(223,2). ismember(223,3). ismember(223,4). ismember(223,5). ismember(223,7). ismember(223,8). 
ismember(224,6). ismember(224,7). ismember(224,8). 
ismember(225,1). ismember(225,6). ismember(225,7). ismember(225,8). 
ismember(226,2). ismember(226,6). ismember(226,7). ismember(226,8). 
ismember(227,1). ismember(227,2). ismember(227,6). ismember(227,7). ismember(227,8). 
ismember(228,3). ismember(228,6). ismember(228,7). ismember(228,8). 
ismember(229,1). ismember(229,3). ismember(229,6). ismember(229,7). ismember(229,8). 
ismember(230,2). ismember(230,3). ismember(230,6). ismember(230,7). ismember(230,8). 
ismember(231,1). ismember(231,2). ismember(231,3). ismember(231,6). ismember(231,7). ismember(231,8). 
ismember(232,4). ismember(232,6). ismember(232,7). ismember(232,8). 
ismember(233,1). ismember(233,4). ismember(233,6). ismember(233,7). ismember(233,8). 
ismember(234,2). ismember(234,4). ismember(234,6). ismember(234,7). ismember(234,8). 
ismember(235,1). ismember(235,2). ismember(235,4). ismember(235,6). ismember(235,7). ismember(235,8). 
ismember(236,3). ismember(236,4). ismember(236,6). ismember(236,7). ismember(236,8). 
ismember(237,1). ismember(237,3). ismember(237,4). ismember(237,6). ismember(237,7). ismember(237,8). 
ismember(238,2). ismember(238,3). ismember(238,4). ismember(238,6). ismember(238,7). ismember(238,8). 
ismember(239,1). ismember(239,2). ismember(239,3). ismember(239,4). ismember(239,6). ismember(239,7). ismember(239,8). 
ismember(240,5). ismember(240,6). ismember(240,7). ismember(240,8). 
ismember(241,1). ismember(241,5). ismember(241,6). ismember(241,7). ismember(241,8). 
ismember(242,2). ismember(242,5). ismember(242,6). ismember(242,7). ismember(242,8). 
ismember(243,1). ismember(243,2). ismember(243,5). ismember(243,6). ismember(243,7). ismember(243,8). 
ismember(244,3). ismember(244,5). ismember(244,6). ismember(244,7). ismember(244,8). 
ismember(245,1). ismember(245,3). ismember(245,5). ismember(245,6). ismember(245,7). ismember(245,8). 
ismember(246,2). ismember(246,3). ismember(246,5). ismember(246,6). ismember(246,7). ismember(246,8). 
ismember(247,1). ismember(247,2). ismember(247,3). ismember(247,5). ismember(247,6). ismember(247,7). ismember(247,8). 
ismember(248,4). ismember(248,5). ismember(248,6). ismember(248,7). ismember(248,8). 
ismember(249,1). ismember(249,4). ismember(249,5). ismember(249,6). ismember(249,7). ismember(249,8). 
ismember(250,2). ismember(250,4). ismember(250,5). ismember(250,6). ismember(250,7). ismember(250,8). 
ismember(251,1). ismember(251,2). ismember(251,4). ismember(251,5). ismember(251,6). ismember(251,7). ismember(251,8). 
ismember(252,3). ismember(252,4). ismember(252,5). ismember(252,6). ismember(252,7). ismember(252,8). 
ismember(253,1). ismember(253,3). ismember(253,4). ismember(253,5). ismember(253,6). ismember(253,7). ismember(253,8). 
ismember(254,2). ismember(254,3). ismember(254,4). ismember(254,5). ismember(254,6). ismember(254,7). ismember(254,8). 
ismember(255,1). ismember(255,2). ismember(255,3). ismember(255,4). ismember(255,5). ismember(255,6). ismember(255,7). ismember(255,8). 
ismember(256,9). 
ismember(257,1). ismember(257,9). 
ismember(258,2). ismember(258,9). 
ismember(259,1). ismember(259,2). ismember(259,9). 
ismember(260,3). ismember(260,9). 
ismember(261,1). ismember(261,3). ismember(261,9). 
ismember(262,2). ismember(262,3). ismember(262,9). 
ismember(263,1). ismember(263,2). ismember(263,3). ismember(263,9). 
ismember(264,4). ismember(264,9). 
ismember(265,1). ismember(265,4). ismember(265,9). 
ismember(266,2). ismember(266,4). ismember(266,9). 
ismember(267,1). ismember(267,2). ismember(267,4). ismember(267,9). 
ismember(268,3). ismember(268,4). ismember(268,9). 
ismember(269,1). ismember(269,3). ismember(269,4). ismember(269,9). 
ismember(270,2). ismember(270,3). ismember(270,4). ismember(270,9). 
ismember(271,1). ismember(271,2). ismember(271,3). ismember(271,4). ismember(271,9). 
ismember(272,5). ismember(272,9). 
ismember(273,1). ismember(273,5). ismember(273,9). 
ismember(274,2). ismember(274,5). ismember(274,9). 
ismember(275,1). ismember(275,2). ismember(275,5). ismember(275,9). 
ismember(276,3). ismember(276,5). ismember(276,9). 
ismember(277,1). ismember(277,3). ismember(277,5). ismember(277,9). 
ismember(278,2). ismember(278,3). ismember(278,5). ismember(278,9). 
ismember(279,1). ismember(279,2). ismember(279,3). ismember(279,5). ismember(279,9). 
ismember(280,4). ismember(280,5). ismember(280,9). 
ismember(281,1). ismember(281,4). ismember(281,5). ismember(281,9). 
ismember(282,2). ismember(282,4). ismember(282,5). ismember(282,9). 
ismember(283,1). ismember(283,2). ismember(283,4). ismember(283,5). ismember(283,9). 
ismember(284,3). ismember(284,4). ismember(284,5). ismember(284,9). 
ismember(285,1). ismember(285,3). ismember(285,4). ismember(285,5). ismember(285,9). 
ismember(286,2). ismember(286,3). ismember(286,4). ismember(286,5). ismember(286,9). 
ismember(287,1). ismember(287,2). ismember(287,3). ismember(287,4). ismember(287,5). ismember(287,9). 
ismember(288,6). ismember(288,9). 
ismember(289,1). ismember(289,6). ismember(289,9). 
ismember(290,2). ismember(290,6). ismember(290,9). 
ismember(291,1). ismember(291,2). ismember(291,6). ismember(291,9). 
ismember(292,3). ismember(292,6). ismember(292,9). 
ismember(293,1). ismember(293,3). ismember(293,6). ismember(293,9). 
ismember(294,2). ismember(294,3). ismember(294,6). ismember(294,9). 
ismember(295,1). ismember(295,2). ismember(295,3). ismember(295,6). ismember(295,9). 
ismember(296,4). ismember(296,6). ismember(296,9). 
ismember(297,1). ismember(297,4). ismember(297,6). ismember(297,9). 
ismember(298,2). ismember(298,4). ismember(298,6). ismember(298,9). 
ismember(299,1). ismember(299,2). ismember(299,4). ismember(299,6). ismember(299,9). 
ismember(300,3). ismember(300,4). ismember(300,6). ismember(300,9). 
ismember(301,1). ismember(301,3). ismember(301,4). ismember(301,6). ismember(301,9). 
ismember(302,2). ismember(302,3). ismember(302,4). ismember(302,6). ismember(302,9). 
ismember(303,1). ismember(303,2). ismember(303,3). ismember(303,4). ismember(303,6). ismember(303,9). 
ismember(304,5). ismember(304,6). ismember(304,9). 
ismember(305,1). ismember(305,5). ismember(305,6). ismember(305,9). 
ismember(306,2). ismember(306,5). ismember(306,6). ismember(306,9). 
ismember(307,1). ismember(307,2). ismember(307,5). ismember(307,6). ismember(307,9). 
ismember(308,3). ismember(308,5). ismember(308,6). ismember(308,9). 
ismember(309,1). ismember(309,3). ismember(309,5). ismember(309,6). ismember(309,9). 
ismember(310,2). ismember(310,3). ismember(310,5). ismember(310,6). ismember(310,9). 
ismember(311,1). ismember(311,2). ismember(311,3). ismember(311,5). ismember(311,6). ismember(311,9). 
ismember(312,4). ismember(312,5). ismember(312,6). ismember(312,9). 
ismember(313,1). ismember(313,4). ismember(313,5). ismember(313,6). ismember(313,9). 
ismember(314,2). ismember(314,4). ismember(314,5). ismember(314,6). ismember(314,9). 
ismember(315,1). ismember(315,2). ismember(315,4). ismember(315,5). ismember(315,6). ismember(315,9). 
ismember(316,3). ismember(316,4). ismember(316,5). ismember(316,6). ismember(316,9). 
ismember(317,1). ismember(317,3). ismember(317,4). ismember(317,5). ismember(317,6). ismember(317,9). 
ismember(318,2). ismember(318,3). ismember(318,4). ismember(318,5). ismember(318,6). ismember(318,9). 
ismember(319,1). ismember(319,2). ismember(319,3). ismember(319,4). ismember(319,5). ismember(319,6). ismember(319,9). 
ismember(320,7). ismember(320,9). 
ismember(321,1). ismember(321,7). ismember(321,9). 
ismember(322,2). ismember(322,7). ismember(322,9). 
ismember(323,1). ismember(323,2). ismember(323,7). ismember(323,9). 
ismember(324,3). ismember(324,7). ismember(324,9). 
ismember(325,1). ismember(325,3). ismember(325,7). ismember(325,9). 
ismember(326,2). ismember(326,3). ismember(326,7). ismember(326,9). 
ismember(327,1). ismember(327,2). ismember(327,3). ismember(327,7). ismember(327,9). 
ismember(328,4). ismember(328,7). ismember(328,9). 
ismember(329,1). ismember(329,4). ismember(329,7). ismember(329,9). 
ismember(330,2). ismember(330,4). ismember(330,7). ismember(330,9). 
ismember(331,1). ismember(331,2). ismember(331,4). ismember(331,7). ismember(331,9). 
ismember(332,3). ismember(332,4). ismember(332,7). ismember(332,9). 
ismember(333,1). ismember(333,3). ismember(333,4). ismember(333,7). ismember(333,9). 
ismember(334,2). ismember(334,3). ismember(334,4). ismember(334,7). ismember(334,9). 
ismember(335,1). ismember(335,2). ismember(335,3). ismember(335,4). ismember(335,7). ismember(335,9). 
ismember(336,5). ismember(336,7). ismember(336,9). 
ismember(337,1). ismember(337,5). ismember(337,7). ismember(337,9). 
ismember(338,2). ismember(338,5). ismember(338,7). ismember(338,9). 
ismember(339,1). ismember(339,2). ismember(339,5). ismember(339,7). ismember(339,9). 
ismember(340,3). ismember(340,5). ismember(340,7). ismember(340,9). 
ismember(341,1). ismember(341,3). ismember(341,5). ismember(341,7). ismember(341,9). 
ismember(342,2). ismember(342,3). ismember(342,5). ismember(342,7). ismember(342,9). 
ismember(343,1). ismember(343,2). ismember(343,3). ismember(343,5). ismember(343,7). ismember(343,9). 
ismember(344,4). ismember(344,5). ismember(344,7). ismember(344,9). 
ismember(345,1). ismember(345,4). ismember(345,5). ismember(345,7). ismember(345,9). 
ismember(346,2). ismember(346,4). ismember(346,5). ismember(346,7). ismember(346,9). 
ismember(347,1). ismember(347,2). ismember(347,4). ismember(347,5). ismember(347,7). ismember(347,9). 
ismember(348,3). ismember(348,4). ismember(348,5). ismember(348,7). ismember(348,9). 
ismember(349,1). ismember(349,3). ismember(349,4). ismember(349,5). ismember(349,7). ismember(349,9). 
ismember(350,2). ismember(350,3). ismember(350,4). ismember(350,5). ismember(350,7). ismember(350,9). 
ismember(351,1). ismember(351,2). ismember(351,3). ismember(351,4). ismember(351,5). ismember(351,7). ismember(351,9). 
ismember(352,6). ismember(352,7). ismember(352,9). 
ismember(353,1). ismember(353,6). ismember(353,7). ismember(353,9). 
ismember(354,2). ismember(354,6). ismember(354,7). ismember(354,9). 
ismember(355,1). ismember(355,2). ismember(355,6). ismember(355,7). ismember(355,9). 
ismember(356,3). ismember(356,6). ismember(356,7). ismember(356,9). 
ismember(357,1). ismember(357,3). ismember(357,6). ismember(357,7). ismember(357,9). 
ismember(358,2). ismember(358,3). ismember(358,6). ismember(358,7). ismember(358,9). 
ismember(359,1). ismember(359,2). ismember(359,3). ismember(359,6). ismember(359,7). ismember(359,9). 
ismember(360,4). ismember(360,6). ismember(360,7). ismember(360,9). 
ismember(361,1). ismember(361,4). ismember(361,6). ismember(361,7). ismember(361,9). 
ismember(362,2). ismember(362,4). ismember(362,6). ismember(362,7). ismember(362,9). 
ismember(363,1). ismember(363,2). ismember(363,4). ismember(363,6). ismember(363,7). ismember(363,9). 
ismember(364,3). ismember(364,4). ismember(364,6). ismember(364,7). ismember(364,9). 
ismember(365,1). ismember(365,3). ismember(365,4). ismember(365,6). ismember(365,7). ismember(365,9). 
ismember(366,2). ismember(366,3). ismember(366,4). ismember(366,6). ismember(366,7). ismember(366,9). 
ismember(367,1). ismember(367,2). ismember(367,3). ismember(367,4). ismember(367,6). ismember(367,7). ismember(367,9). 
ismember(368,5). ismember(368,6). ismember(368,7). ismember(368,9). 
ismember(369,1). ismember(369,5). ismember(369,6). ismember(369,7). ismember(369,9). 
ismember(370,2). ismember(370,5). ismember(370,6). ismember(370,7). ismember(370,9). 
ismember(371,1). ismember(371,2). ismember(371,5). ismember(371,6). ismember(371,7). ismember(371,9). 
ismember(372,3). ismember(372,5). ismember(372,6). ismember(372,7). ismember(372,9). 
ismember(373,1). ismember(373,3). ismember(373,5). ismember(373,6). ismember(373,7). ismember(373,9). 
ismember(374,2). ismember(374,3). ismember(374,5). ismember(374,6). ismember(374,7). ismember(374,9). 
ismember(375,1). ismember(375,2). ismember(375,3). ismember(375,5). ismember(375,6). ismember(375,7). ismember(375,9). 
ismember(376,4). ismember(376,5). ismember(376,6). ismember(376,7). ismember(376,9). 
ismember(377,1). ismember(377,4). ismember(377,5). ismember(377,6). ismember(377,7). ismember(377,9). 
ismember(378,2). ismember(378,4). ismember(378,5). ismember(378,6). ismember(378,7). ismember(378,9). 
ismember(379,1). ismember(379,2). ismember(379,4). ismember(379,5). ismember(379,6). ismember(379,7). ismember(379,9). 
ismember(380,3). ismember(380,4). ismember(380,5). ismember(380,6). ismember(380,7). ismember(380,9). 
ismember(381,1). ismember(381,3). ismember(381,4). ismember(381,5). ismember(381,6). ismember(381,7). ismember(381,9). 
ismember(382,2). ismember(382,3). ismember(382,4). ismember(382,5). ismember(382,6). ismember(382,7). ismember(382,9). 
ismember(383,1). ismember(383,2). ismember(383,3). ismember(383,4). ismember(383,5). ismember(383,6). ismember(383,7). ismember(383,9). 
ismember(384,8). ismember(384,9). 
ismember(385,1). ismember(385,8). ismember(385,9). 
ismember(386,2). ismember(386,8). ismember(386,9). 
ismember(387,1). ismember(387,2). ismember(387,8). ismember(387,9). 
ismember(388,3). ismember(388,8). ismember(388,9). 
ismember(389,1). ismember(389,3). ismember(389,8). ismember(389,9). 
ismember(390,2). ismember(390,3). ismember(390,8). ismember(390,9). 
ismember(391,1). ismember(391,2). ismember(391,3). ismember(391,8). ismember(391,9). 
ismember(392,4). ismember(392,8). ismember(392,9). 
ismember(393,1). ismember(393,4). ismember(393,8). ismember(393,9). 
ismember(394,2). ismember(394,4). ismember(394,8). ismember(394,9). 
ismember(395,1). ismember(395,2). ismember(395,4). ismember(395,8). ismember(395,9). 
ismember(396,3). ismember(396,4). ismember(396,8). ismember(396,9). 
ismember(397,1). ismember(397,3). ismember(397,4). ismember(397,8). ismember(397,9). 
ismember(398,2). ismember(398,3). ismember(398,4). ismember(398,8). ismember(398,9). 
ismember(399,1). ismember(399,2). ismember(399,3). ismember(399,4). ismember(399,8). ismember(399,9). 
ismember(400,5). ismember(400,8). ismember(400,9). 
ismember(401,1). ismember(401,5). ismember(401,8). ismember(401,9). 
ismember(402,2). ismember(402,5). ismember(402,8). ismember(402,9). 
ismember(403,1). ismember(403,2). ismember(403,5). ismember(403,8). ismember(403,9). 
ismember(404,3). ismember(404,5). ismember(404,8). ismember(404,9). 
ismember(405,1). ismember(405,3). ismember(405,5). ismember(405,8). ismember(405,9). 
ismember(406,2). ismember(406,3). ismember(406,5). ismember(406,8). ismember(406,9). 
ismember(407,1). ismember(407,2). ismember(407,3). ismember(407,5). ismember(407,8). ismember(407,9). 
ismember(408,4). ismember(408,5). ismember(408,8). ismember(408,9). 
ismember(409,1). ismember(409,4). ismember(409,5). ismember(409,8). ismember(409,9). 
ismember(410,2). ismember(410,4). ismember(410,5). ismember(410,8). ismember(410,9). 
ismember(411,1). ismember(411,2). ismember(411,4). ismember(411,5). ismember(411,8). ismember(411,9). 
ismember(412,3). ismember(412,4). ismember(412,5). ismember(412,8). ismember(412,9). 
ismember(413,1). ismember(413,3). ismember(413,4). ismember(413,5). ismember(413,8). ismember(413,9). 
ismember(414,2). ismember(414,3). ismember(414,4). ismember(414,5). ismember(414,8). ismember(414,9). 
ismember(415,1). ismember(415,2). ismember(415,3). ismember(415,4). ismember(415,5). ismember(415,8). ismember(415,9). 
ismember(416,6). ismember(416,8). ismember(416,9). 
ismember(417,1). ismember(417,6). ismember(417,8). ismember(417,9). 
ismember(418,2). ismember(418,6). ismember(418,8). ismember(418,9). 
ismember(419,1). ismember(419,2). ismember(419,6). ismember(419,8). ismember(419,9). 
ismember(420,3). ismember(420,6). ismember(420,8). ismember(420,9). 
ismember(421,1). ismember(421,3). ismember(421,6). ismember(421,8). ismember(421,9). 
ismember(422,2). ismember(422,3). ismember(422,6). ismember(422,8). ismember(422,9). 
ismember(423,1). ismember(423,2). ismember(423,3). ismember(423,6). ismember(423,8). ismember(423,9). 
ismember(424,4). ismember(424,6). ismember(424,8). ismember(424,9). 
ismember(425,1). ismember(425,4). ismember(425,6). ismember(425,8). ismember(425,9). 
ismember(426,2). ismember(426,4). ismember(426,6). ismember(426,8). ismember(426,9). 
ismember(427,1). ismember(427,2). ismember(427,4). ismember(427,6). ismember(427,8). ismember(427,9). 
ismember(428,3). ismember(428,4). ismember(428,6). ismember(428,8). ismember(428,9). 
ismember(429,1). ismember(429,3). ismember(429,4). ismember(429,6). ismember(429,8). ismember(429,9). 
ismember(430,2). ismember(430,3). ismember(430,4). ismember(430,6). ismember(430,8). ismember(430,9). 
ismember(431,1). ismember(431,2). ismember(431,3). ismember(431,4). ismember(431,6). ismember(431,8). ismember(431,9). 
ismember(432,5). ismember(432,6). ismember(432,8). ismember(432,9). 
ismember(433,1). ismember(433,5). ismember(433,6). ismember(433,8). ismember(433,9). 
ismember(434,2). ismember(434,5). ismember(434,6). ismember(434,8). ismember(434,9). 
ismember(435,1). ismember(435,2). ismember(435,5). ismember(435,6). ismember(435,8). ismember(435,9). 
ismember(436,3). ismember(436,5). ismember(436,6). ismember(436,8). ismember(436,9). 
ismember(437,1). ismember(437,3). ismember(437,5). ismember(437,6). ismember(437,8). ismember(437,9). 
ismember(438,2). ismember(438,3). ismember(438,5). ismember(438,6). ismember(438,8). ismember(438,9). 
ismember(439,1). ismember(439,2). ismember(439,3). ismember(439,5). ismember(439,6). ismember(439,8). ismember(439,9). 
ismember(440,4). ismember(440,5). ismember(440,6). ismember(440,8). ismember(440,9). 
ismember(441,1). ismember(441,4). ismember(441,5). ismember(441,6). ismember(441,8). ismember(441,9). 
ismember(442,2). ismember(442,4). ismember(442,5). ismember(442,6). ismember(442,8). ismember(442,9). 
ismember(443,1). ismember(443,2). ismember(443,4). ismember(443,5). ismember(443,6). ismember(443,8). ismember(443,9). 
ismember(444,3). ismember(444,4). ismember(444,5). ismember(444,6). ismember(444,8). ismember(444,9). 
ismember(445,1). ismember(445,3). ismember(445,4). ismember(445,5). ismember(445,6). ismember(445,8). ismember(445,9). 
ismember(446,2). ismember(446,3). ismember(446,4). ismember(446,5). ismember(446,6). ismember(446,8). ismember(446,9). 
ismember(447,1). ismember(447,2). ismember(447,3). ismember(447,4). ismember(447,5). ismember(447,6). ismember(447,8). ismember(447,9). 
ismember(448,7). ismember(448,8). ismember(448,9). 
ismember(449,1). ismember(449,7). ismember(449,8). ismember(449,9). 
ismember(450,2). ismember(450,7). ismember(450,8). ismember(450,9). 
ismember(451,1). ismember(451,2). ismember(451,7). ismember(451,8). ismember(451,9). 
ismember(452,3). ismember(452,7). ismember(452,8). ismember(452,9). 
ismember(453,1). ismember(453,3). ismember(453,7). ismember(453,8). ismember(453,9). 
ismember(454,2). ismember(454,3). ismember(454,7). ismember(454,8). ismember(454,9). 
ismember(455,1). ismember(455,2). ismember(455,3). ismember(455,7). ismember(455,8). ismember(455,9). 
ismember(456,4). ismember(456,7). ismember(456,8). ismember(456,9). 
ismember(457,1). ismember(457,4). ismember(457,7). ismember(457,8). ismember(457,9). 
ismember(458,2). ismember(458,4). ismember(458,7). ismember(458,8). ismember(458,9). 
ismember(459,1). ismember(459,2). ismember(459,4). ismember(459,7). ismember(459,8). ismember(459,9). 
ismember(460,3). ismember(460,4). ismember(460,7). ismember(460,8). ismember(460,9). 
ismember(461,1). ismember(461,3). ismember(461,4). ismember(461,7). ismember(461,8). ismember(461,9). 
ismember(462,2). ismember(462,3). ismember(462,4). ismember(462,7). ismember(462,8). ismember(462,9). 
ismember(463,1). ismember(463,2). ismember(463,3). ismember(463,4). ismember(463,7). ismember(463,8). ismember(463,9). 
ismember(464,5). ismember(464,7). ismember(464,8). ismember(464,9). 
ismember(465,1). ismember(465,5). ismember(465,7). ismember(465,8). ismember(465,9). 
ismember(466,2). ismember(466,5). ismember(466,7). ismember(466,8). ismember(466,9). 
ismember(467,1). ismember(467,2). ismember(467,5). ismember(467,7). ismember(467,8). ismember(467,9). 
ismember(468,3). ismember(468,5). ismember(468,7). ismember(468,8). ismember(468,9). 
ismember(469,1). ismember(469,3). ismember(469,5). ismember(469,7). ismember(469,8). ismember(469,9). 
ismember(470,2). ismember(470,3). ismember(470,5). ismember(470,7). ismember(470,8). ismember(470,9). 
ismember(471,1). ismember(471,2). ismember(471,3). ismember(471,5). ismember(471,7). ismember(471,8). ismember(471,9). 
ismember(472,4). ismember(472,5). ismember(472,7). ismember(472,8). ismember(472,9). 
ismember(473,1). ismember(473,4). ismember(473,5). ismember(473,7). ismember(473,8). ismember(473,9). 
ismember(474,2). ismember(474,4). ismember(474,5). ismember(474,7). ismember(474,8). ismember(474,9). 
ismember(475,1). ismember(475,2). ismember(475,4). ismember(475,5). ismember(475,7). ismember(475,8). ismember(475,9). 
ismember(476,3). ismember(476,4). ismember(476,5). ismember(476,7). ismember(476,8). ismember(476,9). 
ismember(477,1). ismember(477,3). ismember(477,4). ismember(477,5). ismember(477,7). ismember(477,8). ismember(477,9). 
ismember(478,2). ismember(478,3). ismember(478,4). ismember(478,5). ismember(478,7). ismember(478,8). ismember(478,9). 
ismember(479,1). ismember(479,2). ismember(479,3). ismember(479,4). ismember(479,5). ismember(479,7). ismember(479,8). ismember(479,9). 
ismember(480,6). ismember(480,7). ismember(480,8). ismember(480,9). 
ismember(481,1). ismember(481,6). ismember(481,7). ismember(481,8). ismember(481,9). 
ismember(482,2). ismember(482,6). ismember(482,7). ismember(482,8). ismember(482,9). 
ismember(483,1). ismember(483,2). ismember(483,6). ismember(483,7). ismember(483,8). ismember(483,9). 
ismember(484,3). ismember(484,6). ismember(484,7). ismember(484,8). ismember(484,9). 
ismember(485,1). ismember(485,3). ismember(485,6). ismember(485,7). ismember(485,8). ismember(485,9). 
ismember(486,2). ismember(486,3). ismember(486,6). ismember(486,7). ismember(486,8). ismember(486,9). 
ismember(487,1). ismember(487,2). ismember(487,3). ismember(487,6). ismember(487,7). ismember(487,8). ismember(487,9). 
ismember(488,4). ismember(488,6). ismember(488,7). ismember(488,8). ismember(488,9). 
ismember(489,1). ismember(489,4). ismember(489,6). ismember(489,7). ismember(489,8). ismember(489,9). 
ismember(490,2). ismember(490,4). ismember(490,6). ismember(490,7). ismember(490,8). ismember(490,9). 
ismember(491,1). ismember(491,2). ismember(491,4). ismember(491,6). ismember(491,7). ismember(491,8). ismember(491,9). 
ismember(492,3). ismember(492,4). ismember(492,6). ismember(492,7). ismember(492,8). ismember(492,9). 
ismember(493,1). ismember(493,3). ismember(493,4). ismember(493,6). ismember(493,7). ismember(493,8). ismember(493,9). 
ismember(494,2). ismember(494,3). ismember(494,4). ismember(494,6). ismember(494,7). ismember(494,8). ismember(494,9). 
ismember(495,1). ismember(495,2). ismember(495,3). ismember(495,4). ismember(495,6). ismember(495,7). ismember(495,8). ismember(495,9). 
ismember(496,5). ismember(496,6). ismember(496,7). ismember(496,8). ismember(496,9). 
ismember(497,1). ismember(497,5). ismember(497,6). ismember(497,7). ismember(497,8). ismember(497,9). 
ismember(498,2). ismember(498,5). ismember(498,6). ismember(498,7). ismember(498,8). ismember(498,9). 
ismember(499,1). ismember(499,2). ismember(499,5). ismember(499,6). ismember(499,7). ismember(499,8). ismember(499,9). 
ismember(500,3). ismember(500,5). ismember(500,6). ismember(500,7). ismember(500,8). ismember(500,9). 
ismember(501,1). ismember(501,3). ismember(501,5). ismember(501,6). ismember(501,7). ismember(501,8). ismember(501,9). 
ismember(502,2). ismember(502,3). ismember(502,5). ismember(502,6). ismember(502,7). ismember(502,8). ismember(502,9). 
ismember(503,1). ismember(503,2). ismember(503,3). ismember(503,5). ismember(503,6). ismember(503,7). ismember(503,8). ismember(503,9). 
ismember(504,4). ismember(504,5). ismember(504,6). ismember(504,7). ismember(504,8). ismember(504,9). 
ismember(505,1). ismember(505,4). ismember(505,5). ismember(505,6). ismember(505,7). ismember(505,8). ismember(505,9). 
ismember(506,2). ismember(506,4). ismember(506,5). ismember(506,6). ismember(506,7). ismember(506,8). ismember(506,9). 
ismember(507,1). ismember(507,2). ismember(507,4). ismember(507,5). ismember(507,6). ismember(507,7). ismember(507,8). ismember(507,9). 
ismember(508,3). ismember(508,4). ismember(508,5). ismember(508,6). ismember(508,7). ismember(508,8). ismember(508,9). 
ismember(509,1). ismember(509,3). ismember(509,4). ismember(509,5). ismember(509,6). ismember(509,7). ismember(509,8). ismember(509,9). 
ismember(510,2). ismember(510,3). ismember(510,4). ismember(510,5). ismember(510,6). ismember(510,7). ismember(510,8). ismember(510,9). 
ismember(511,1). ismember(511,2). ismember(511,3). ismember(511,4). ismember(511,5). ismember(511,6). ismember(511,7). ismember(511,8). ismember(511,9). 
ismember(512,10). 
ismember(513,1). ismember(513,10). 
ismember(514,2). ismember(514,10). 
ismember(515,1). ismember(515,2). ismember(515,10). 
ismember(516,3). ismember(516,10). 
ismember(517,1). ismember(517,3). ismember(517,10). 
ismember(518,2). ismember(518,3). ismember(518,10). 
ismember(519,1). ismember(519,2). ismember(519,3). ismember(519,10). 
ismember(520,4). ismember(520,10). 
ismember(521,1). ismember(521,4). ismember(521,10). 
ismember(522,2). ismember(522,4). ismember(522,10). 
ismember(523,1). ismember(523,2). ismember(523,4). ismember(523,10). 
ismember(524,3). ismember(524,4). ismember(524,10). 
ismember(525,1). ismember(525,3). ismember(525,4). ismember(525,10). 
ismember(526,2). ismember(526,3). ismember(526,4). ismember(526,10). 
ismember(527,1). ismember(527,2). ismember(527,3). ismember(527,4). ismember(527,10). 
ismember(528,5). ismember(528,10). 
ismember(529,1). ismember(529,5). ismember(529,10). 
ismember(530,2). ismember(530,5). ismember(530,10). 
ismember(531,1). ismember(531,2). ismember(531,5). ismember(531,10). 
ismember(532,3). ismember(532,5). ismember(532,10). 
ismember(533,1). ismember(533,3). ismember(533,5). ismember(533,10). 
ismember(534,2). ismember(534,3). ismember(534,5). ismember(534,10). 
ismember(535,1). ismember(535,2). ismember(535,3). ismember(535,5). ismember(535,10). 
ismember(536,4). ismember(536,5). ismember(536,10). 
ismember(537,1). ismember(537,4). ismember(537,5). ismember(537,10). 
ismember(538,2). ismember(538,4). ismember(538,5). ismember(538,10). 
ismember(539,1). ismember(539,2). ismember(539,4). ismember(539,5). ismember(539,10). 
ismember(540,3). ismember(540,4). ismember(540,5). ismember(540,10). 
ismember(541,1). ismember(541,3). ismember(541,4). ismember(541,5). ismember(541,10). 
ismember(542,2). ismember(542,3). ismember(542,4). ismember(542,5). ismember(542,10). 
ismember(543,1). ismember(543,2). ismember(543,3). ismember(543,4). ismember(543,5). ismember(543,10). 
ismember(544,6). ismember(544,10). 
ismember(545,1). ismember(545,6). ismember(545,10). 
ismember(546,2). ismember(546,6). ismember(546,10). 
ismember(547,1). ismember(547,2). ismember(547,6). ismember(547,10). 
ismember(548,3). ismember(548,6). ismember(548,10). 
ismember(549,1). ismember(549,3). ismember(549,6). ismember(549,10). 
ismember(550,2). ismember(550,3). ismember(550,6). ismember(550,10). 
ismember(551,1). ismember(551,2). ismember(551,3). ismember(551,6). ismember(551,10). 
ismember(552,4). ismember(552,6). ismember(552,10). 
ismember(553,1). ismember(553,4). ismember(553,6). ismember(553,10). 
ismember(554,2). ismember(554,4). ismember(554,6). ismember(554,10). 
ismember(555,1). ismember(555,2). ismember(555,4). ismember(555,6). ismember(555,10). 
ismember(556,3). ismember(556,4). ismember(556,6). ismember(556,10). 
ismember(557,1). ismember(557,3). ismember(557,4). ismember(557,6). ismember(557,10). 
ismember(558,2). ismember(558,3). ismember(558,4). ismember(558,6). ismember(558,10). 
ismember(559,1). ismember(559,2). ismember(559,3). ismember(559,4). ismember(559,6). ismember(559,10). 
ismember(560,5). ismember(560,6). ismember(560,10). 
ismember(561,1). ismember(561,5). ismember(561,6). ismember(561,10). 
ismember(562,2). ismember(562,5). ismember(562,6). ismember(562,10). 
ismember(563,1). ismember(563,2). ismember(563,5). ismember(563,6). ismember(563,10). 
ismember(564,3). ismember(564,5). ismember(564,6). ismember(564,10). 
ismember(565,1). ismember(565,3). ismember(565,5). ismember(565,6). ismember(565,10). 
ismember(566,2). ismember(566,3). ismember(566,5). ismember(566,6). ismember(566,10). 
ismember(567,1). ismember(567,2). ismember(567,3). ismember(567,5). ismember(567,6). ismember(567,10). 
ismember(568,4). ismember(568,5). ismember(568,6). ismember(568,10). 
ismember(569,1). ismember(569,4). ismember(569,5). ismember(569,6). ismember(569,10). 
ismember(570,2). ismember(570,4). ismember(570,5). ismember(570,6). ismember(570,10). 
ismember(571,1). ismember(571,2). ismember(571,4). ismember(571,5). ismember(571,6). ismember(571,10). 
ismember(572,3). ismember(572,4). ismember(572,5). ismember(572,6). ismember(572,10). 
ismember(573,1). ismember(573,3). ismember(573,4). ismember(573,5). ismember(573,6). ismember(573,10). 
ismember(574,2). ismember(574,3). ismember(574,4). ismember(574,5). ismember(574,6). ismember(574,10). 
ismember(575,1). ismember(575,2). ismember(575,3). ismember(575,4). ismember(575,5). ismember(575,6). ismember(575,10). 
ismember(576,7). ismember(576,10). 
ismember(577,1). ismember(577,7). ismember(577,10). 
ismember(578,2). ismember(578,7). ismember(578,10). 
ismember(579,1). ismember(579,2). ismember(579,7). ismember(579,10). 
ismember(580,3). ismember(580,7). ismember(580,10). 
ismember(581,1). ismember(581,3). ismember(581,7). ismember(581,10). 
ismember(582,2). ismember(582,3). ismember(582,7). ismember(582,10). 
ismember(583,1). ismember(583,2). ismember(583,3). ismember(583,7). ismember(583,10). 
ismember(584,4). ismember(584,7). ismember(584,10). 
ismember(585,1). ismember(585,4). ismember(585,7). ismember(585,10). 
ismember(586,2). ismember(586,4). ismember(586,7). ismember(586,10). 
ismember(587,1). ismember(587,2). ismember(587,4). ismember(587,7). ismember(587,10). 
ismember(588,3). ismember(588,4). ismember(588,7). ismember(588,10). 
ismember(589,1). ismember(589,3). ismember(589,4). ismember(589,7). ismember(589,10). 
ismember(590,2). ismember(590,3). ismember(590,4). ismember(590,7). ismember(590,10). 
ismember(591,1). ismember(591,2). ismember(591,3). ismember(591,4). ismember(591,7). ismember(591,10). 
ismember(592,5). ismember(592,7). ismember(592,10). 
ismember(593,1). ismember(593,5). ismember(593,7). ismember(593,10). 
ismember(594,2). ismember(594,5). ismember(594,7). ismember(594,10). 
ismember(595,1). ismember(595,2). ismember(595,5). ismember(595,7). ismember(595,10). 
ismember(596,3). ismember(596,5). ismember(596,7). ismember(596,10). 
ismember(597,1). ismember(597,3). ismember(597,5). ismember(597,7). ismember(597,10). 
ismember(598,2). ismember(598,3). ismember(598,5). ismember(598,7). ismember(598,10). 
ismember(599,1). ismember(599,2). ismember(599,3). ismember(599,5). ismember(599,7). ismember(599,10). 
ismember(600,4). ismember(600,5). ismember(600,7). ismember(600,10). 
ismember(601,1). ismember(601,4). ismember(601,5). ismember(601,7). ismember(601,10). 
ismember(602,2). ismember(602,4). ismember(602,5). ismember(602,7). ismember(602,10). 
ismember(603,1). ismember(603,2). ismember(603,4). ismember(603,5). ismember(603,7). ismember(603,10). 
ismember(604,3). ismember(604,4). ismember(604,5). ismember(604,7). ismember(604,10). 
ismember(605,1). ismember(605,3). ismember(605,4). ismember(605,5). ismember(605,7). ismember(605,10). 
ismember(606,2). ismember(606,3). ismember(606,4). ismember(606,5). ismember(606,7). ismember(606,10). 
ismember(607,1). ismember(607,2). ismember(607,3). ismember(607,4). ismember(607,5). ismember(607,7). ismember(607,10). 
ismember(608,6). ismember(608,7). ismember(608,10). 
ismember(609,1). ismember(609,6). ismember(609,7). ismember(609,10). 
ismember(610,2). ismember(610,6). ismember(610,7). ismember(610,10). 
ismember(611,1). ismember(611,2). ismember(611,6). ismember(611,7). ismember(611,10). 
ismember(612,3). ismember(612,6). ismember(612,7). ismember(612,10). 
ismember(613,1). ismember(613,3). ismember(613,6). ismember(613,7). ismember(613,10). 
ismember(614,2). ismember(614,3). ismember(614,6). ismember(614,7). ismember(614,10). 
ismember(615,1). ismember(615,2). ismember(615,3). ismember(615,6). ismember(615,7). ismember(615,10). 
ismember(616,4). ismember(616,6). ismember(616,7). ismember(616,10). 
ismember(617,1). ismember(617,4). ismember(617,6). ismember(617,7). ismember(617,10). 
ismember(618,2). ismember(618,4). ismember(618,6). ismember(618,7). ismember(618,10). 
ismember(619,1). ismember(619,2). ismember(619,4). ismember(619,6). ismember(619,7). ismember(619,10). 
ismember(620,3). ismember(620,4). ismember(620,6). ismember(620,7). ismember(620,10). 
ismember(621,1). ismember(621,3). ismember(621,4). ismember(621,6). ismember(621,7). ismember(621,10). 
ismember(622,2). ismember(622,3). ismember(622,4). ismember(622,6). ismember(622,7). ismember(622,10). 
ismember(623,1). ismember(623,2). ismember(623,3). ismember(623,4). ismember(623,6). ismember(623,7). ismember(623,10). 
ismember(624,5). ismember(624,6). ismember(624,7). ismember(624,10). 
ismember(625,1). ismember(625,5). ismember(625,6). ismember(625,7). ismember(625,10). 
ismember(626,2). ismember(626,5). ismember(626,6). ismember(626,7). ismember(626,10). 
ismember(627,1). ismember(627,2). ismember(627,5). ismember(627,6). ismember(627,7). ismember(627,10). 
ismember(628,3). ismember(628,5). ismember(628,6). ismember(628,7). ismember(628,10). 
ismember(629,1). ismember(629,3). ismember(629,5). ismember(629,6). ismember(629,7). ismember(629,10). 
ismember(630,2). ismember(630,3). ismember(630,5). ismember(630,6). ismember(630,7). ismember(630,10). 
ismember(631,1). ismember(631,2). ismember(631,3). ismember(631,5). ismember(631,6). ismember(631,7). ismember(631,10). 
ismember(632,4). ismember(632,5). ismember(632,6). ismember(632,7). ismember(632,10). 
ismember(633,1). ismember(633,4). ismember(633,5). ismember(633,6). ismember(633,7). ismember(633,10). 
ismember(634,2). ismember(634,4). ismember(634,5). ismember(634,6). ismember(634,7). ismember(634,10). 
ismember(635,1). ismember(635,2). ismember(635,4). ismember(635,5). ismember(635,6). ismember(635,7). ismember(635,10). 
ismember(636,3). ismember(636,4). ismember(636,5). ismember(636,6). ismember(636,7). ismember(636,10). 
ismember(637,1). ismember(637,3). ismember(637,4). ismember(637,5). ismember(637,6). ismember(637,7). ismember(637,10). 
ismember(638,2). ismember(638,3). ismember(638,4). ismember(638,5). ismember(638,6). ismember(638,7). ismember(638,10). 
ismember(639,1). ismember(639,2). ismember(639,3). ismember(639,4). ismember(639,5). ismember(639,6). ismember(639,7). ismember(639,10). 
ismember(640,8). ismember(640,10). 
ismember(641,1). ismember(641,8). ismember(641,10). 
ismember(642,2). ismember(642,8). ismember(642,10). 
ismember(643,1). ismember(643,2). ismember(643,8). ismember(643,10). 
ismember(644,3). ismember(644,8). ismember(644,10). 
ismember(645,1). ismember(645,3). ismember(645,8). ismember(645,10). 
ismember(646,2). ismember(646,3). ismember(646,8). ismember(646,10). 
ismember(647,1). ismember(647,2). ismember(647,3). ismember(647,8). ismember(647,10). 
ismember(648,4). ismember(648,8). ismember(648,10). 
ismember(649,1). ismember(649,4). ismember(649,8). ismember(649,10). 
ismember(650,2). ismember(650,4). ismember(650,8). ismember(650,10). 
ismember(651,1). ismember(651,2). ismember(651,4). ismember(651,8). ismember(651,10). 
ismember(652,3). ismember(652,4). ismember(652,8). ismember(652,10). 
ismember(653,1). ismember(653,3). ismember(653,4). ismember(653,8). ismember(653,10). 
ismember(654,2). ismember(654,3). ismember(654,4). ismember(654,8). ismember(654,10). 
ismember(655,1). ismember(655,2). ismember(655,3). ismember(655,4). ismember(655,8). ismember(655,10). 
ismember(656,5). ismember(656,8). ismember(656,10). 
ismember(657,1). ismember(657,5). ismember(657,8). ismember(657,10). 
ismember(658,2). ismember(658,5). ismember(658,8). ismember(658,10). 
ismember(659,1). ismember(659,2). ismember(659,5). ismember(659,8). ismember(659,10). 
ismember(660,3). ismember(660,5). ismember(660,8). ismember(660,10). 
ismember(661,1). ismember(661,3). ismember(661,5). ismember(661,8). ismember(661,10). 
ismember(662,2). ismember(662,3). ismember(662,5). ismember(662,8). ismember(662,10). 
ismember(663,1). ismember(663,2). ismember(663,3). ismember(663,5). ismember(663,8). ismember(663,10). 
ismember(664,4). ismember(664,5). ismember(664,8). ismember(664,10). 
ismember(665,1). ismember(665,4). ismember(665,5). ismember(665,8). ismember(665,10). 
ismember(666,2). ismember(666,4). ismember(666,5). ismember(666,8). ismember(666,10). 
ismember(667,1). ismember(667,2). ismember(667,4). ismember(667,5). ismember(667,8). ismember(667,10). 
ismember(668,3). ismember(668,4). ismember(668,5). ismember(668,8). ismember(668,10). 
ismember(669,1). ismember(669,3). ismember(669,4). ismember(669,5). ismember(669,8). ismember(669,10). 
ismember(670,2). ismember(670,3). ismember(670,4). ismember(670,5). ismember(670,8). ismember(670,10). 
ismember(671,1). ismember(671,2). ismember(671,3). ismember(671,4). ismember(671,5). ismember(671,8). ismember(671,10). 
ismember(672,6). ismember(672,8). ismember(672,10). 
ismember(673,1). ismember(673,6). ismember(673,8). ismember(673,10). 
ismember(674,2). ismember(674,6). ismember(674,8). ismember(674,10). 
ismember(675,1). ismember(675,2). ismember(675,6). ismember(675,8). ismember(675,10). 
ismember(676,3). ismember(676,6). ismember(676,8). ismember(676,10). 
ismember(677,1). ismember(677,3). ismember(677,6). ismember(677,8). ismember(677,10). 
ismember(678,2). ismember(678,3). ismember(678,6). ismember(678,8). ismember(678,10). 
ismember(679,1). ismember(679,2). ismember(679,3). ismember(679,6). ismember(679,8). ismember(679,10). 
ismember(680,4). ismember(680,6). ismember(680,8). ismember(680,10). 
ismember(681,1). ismember(681,4). ismember(681,6). ismember(681,8). ismember(681,10). 
ismember(682,2). ismember(682,4). ismember(682,6). ismember(682,8). ismember(682,10). 
ismember(683,1). ismember(683,2). ismember(683,4). ismember(683,6). ismember(683,8). ismember(683,10). 
ismember(684,3). ismember(684,4). ismember(684,6). ismember(684,8). ismember(684,10). 
ismember(685,1). ismember(685,3). ismember(685,4). ismember(685,6). ismember(685,8). ismember(685,10). 
ismember(686,2). ismember(686,3). ismember(686,4). ismember(686,6). ismember(686,8). ismember(686,10). 
ismember(687,1). ismember(687,2). ismember(687,3). ismember(687,4). ismember(687,6). ismember(687,8). ismember(687,10). 
ismember(688,5). ismember(688,6). ismember(688,8). ismember(688,10). 
ismember(689,1). ismember(689,5). ismember(689,6). ismember(689,8). ismember(689,10). 
ismember(690,2). ismember(690,5). ismember(690,6). ismember(690,8). ismember(690,10). 
ismember(691,1). ismember(691,2). ismember(691,5). ismember(691,6). ismember(691,8). ismember(691,10). 
ismember(692,3). ismember(692,5). ismember(692,6). ismember(692,8). ismember(692,10). 
ismember(693,1). ismember(693,3). ismember(693,5). ismember(693,6). ismember(693,8). ismember(693,10). 
ismember(694,2). ismember(694,3). ismember(694,5). ismember(694,6). ismember(694,8). ismember(694,10). 
ismember(695,1). ismember(695,2). ismember(695,3). ismember(695,5). ismember(695,6). ismember(695,8). ismember(695,10). 
ismember(696,4). ismember(696,5). ismember(696,6). ismember(696,8). ismember(696,10). 
ismember(697,1). ismember(697,4). ismember(697,5). ismember(697,6). ismember(697,8). ismember(697,10). 
ismember(698,2). ismember(698,4). ismember(698,5). ismember(698,6). ismember(698,8). ismember(698,10). 
ismember(699,1). ismember(699,2). ismember(699,4). ismember(699,5). ismember(699,6). ismember(699,8). ismember(699,10). 
ismember(700,3). ismember(700,4). ismember(700,5). ismember(700,6). ismember(700,8). ismember(700,10). 
ismember(701,1). ismember(701,3). ismember(701,4). ismember(701,5). ismember(701,6). ismember(701,8). ismember(701,10). 
ismember(702,2). ismember(702,3). ismember(702,4). ismember(702,5). ismember(702,6). ismember(702,8). ismember(702,10). 
ismember(703,1). ismember(703,2). ismember(703,3). ismember(703,4). ismember(703,5). ismember(703,6). ismember(703,8). ismember(703,10). 
ismember(704,7). ismember(704,8). ismember(704,10). 
ismember(705,1). ismember(705,7). ismember(705,8). ismember(705,10). 
ismember(706,2). ismember(706,7). ismember(706,8). ismember(706,10). 
ismember(707,1). ismember(707,2). ismember(707,7). ismember(707,8). ismember(707,10). 
ismember(708,3). ismember(708,7). ismember(708,8). ismember(708,10). 
ismember(709,1). ismember(709,3). ismember(709,7). ismember(709,8). ismember(709,10). 
ismember(710,2). ismember(710,3). ismember(710,7). ismember(710,8). ismember(710,10). 
ismember(711,1). ismember(711,2). ismember(711,3). ismember(711,7). ismember(711,8). ismember(711,10). 
ismember(712,4). ismember(712,7). ismember(712,8). ismember(712,10). 
ismember(713,1). ismember(713,4). ismember(713,7). ismember(713,8). ismember(713,10). 
ismember(714,2). ismember(714,4). ismember(714,7). ismember(714,8). ismember(714,10). 
ismember(715,1). ismember(715,2). ismember(715,4). ismember(715,7). ismember(715,8). ismember(715,10). 
ismember(716,3). ismember(716,4). ismember(716,7). ismember(716,8). ismember(716,10). 
ismember(717,1). ismember(717,3). ismember(717,4). ismember(717,7). ismember(717,8). ismember(717,10). 
ismember(718,2). ismember(718,3). ismember(718,4). ismember(718,7). ismember(718,8). ismember(718,10). 
ismember(719,1). ismember(719,2). ismember(719,3). ismember(719,4). ismember(719,7). ismember(719,8). ismember(719,10). 
ismember(720,5). ismember(720,7). ismember(720,8). ismember(720,10). 
ismember(721,1). ismember(721,5). ismember(721,7). ismember(721,8). ismember(721,10). 
ismember(722,2). ismember(722,5). ismember(722,7). ismember(722,8). ismember(722,10). 
ismember(723,1). ismember(723,2). ismember(723,5). ismember(723,7). ismember(723,8). ismember(723,10). 
ismember(724,3). ismember(724,5). ismember(724,7). ismember(724,8). ismember(724,10). 
ismember(725,1). ismember(725,3). ismember(725,5). ismember(725,7). ismember(725,8). ismember(725,10). 
ismember(726,2). ismember(726,3). ismember(726,5). ismember(726,7). ismember(726,8). ismember(726,10). 
ismember(727,1). ismember(727,2). ismember(727,3). ismember(727,5). ismember(727,7). ismember(727,8). ismember(727,10). 
ismember(728,4). ismember(728,5). ismember(728,7). ismember(728,8). ismember(728,10). 
ismember(729,1). ismember(729,4). ismember(729,5). ismember(729,7). ismember(729,8). ismember(729,10). 
ismember(730,2). ismember(730,4). ismember(730,5). ismember(730,7). ismember(730,8). ismember(730,10). 
ismember(731,1). ismember(731,2). ismember(731,4). ismember(731,5). ismember(731,7). ismember(731,8). ismember(731,10). 
ismember(732,3). ismember(732,4). ismember(732,5). ismember(732,7). ismember(732,8). ismember(732,10). 
ismember(733,1). ismember(733,3). ismember(733,4). ismember(733,5). ismember(733,7). ismember(733,8). ismember(733,10). 
ismember(734,2). ismember(734,3). ismember(734,4). ismember(734,5). ismember(734,7). ismember(734,8). ismember(734,10). 
ismember(735,1). ismember(735,2). ismember(735,3). ismember(735,4). ismember(735,5). ismember(735,7). ismember(735,8). ismember(735,10). 
ismember(736,6). ismember(736,7). ismember(736,8). ismember(736,10). 
ismember(737,1). ismember(737,6). ismember(737,7). ismember(737,8). ismember(737,10). 
ismember(738,2). ismember(738,6). ismember(738,7). ismember(738,8). ismember(738,10). 
ismember(739,1). ismember(739,2). ismember(739,6). ismember(739,7). ismember(739,8). ismember(739,10). 
ismember(740,3). ismember(740,6). ismember(740,7). ismember(740,8). ismember(740,10). 
ismember(741,1). ismember(741,3). ismember(741,6). ismember(741,7). ismember(741,8). ismember(741,10). 
ismember(742,2). ismember(742,3). ismember(742,6). ismember(742,7). ismember(742,8). ismember(742,10). 
ismember(743,1). ismember(743,2). ismember(743,3). ismember(743,6). ismember(743,7). ismember(743,8). ismember(743,10). 
ismember(744,4). ismember(744,6). ismember(744,7). ismember(744,8). ismember(744,10). 
ismember(745,1). ismember(745,4). ismember(745,6). ismember(745,7). ismember(745,8). ismember(745,10). 
ismember(746,2). ismember(746,4). ismember(746,6). ismember(746,7). ismember(746,8). ismember(746,10). 
ismember(747,1). ismember(747,2). ismember(747,4). ismember(747,6). ismember(747,7). ismember(747,8). ismember(747,10). 
ismember(748,3). ismember(748,4). ismember(748,6). ismember(748,7). ismember(748,8). ismember(748,10). 
ismember(749,1). ismember(749,3). ismember(749,4). ismember(749,6). ismember(749,7). ismember(749,8). ismember(749,10). 
ismember(750,2). ismember(750,3). ismember(750,4). ismember(750,6). ismember(750,7). ismember(750,8). ismember(750,10). 
ismember(751,1). ismember(751,2). ismember(751,3). ismember(751,4). ismember(751,6). ismember(751,7). ismember(751,8). ismember(751,10). 
ismember(752,5). ismember(752,6). ismember(752,7). ismember(752,8). ismember(752,10). 
ismember(753,1). ismember(753,5). ismember(753,6). ismember(753,7). ismember(753,8). ismember(753,10). 
ismember(754,2). ismember(754,5). ismember(754,6). ismember(754,7). ismember(754,8). ismember(754,10). 
ismember(755,1). ismember(755,2). ismember(755,5). ismember(755,6). ismember(755,7). ismember(755,8). ismember(755,10). 
ismember(756,3). ismember(756,5). ismember(756,6). ismember(756,7). ismember(756,8). ismember(756,10). 
ismember(757,1). ismember(757,3). ismember(757,5). ismember(757,6). ismember(757,7). ismember(757,8). ismember(757,10). 
ismember(758,2). ismember(758,3). ismember(758,5). ismember(758,6). ismember(758,7). ismember(758,8). ismember(758,10). 
ismember(759,1). ismember(759,2). ismember(759,3). ismember(759,5). ismember(759,6). ismember(759,7). ismember(759,8). ismember(759,10). 
ismember(760,4). ismember(760,5). ismember(760,6). ismember(760,7). ismember(760,8). ismember(760,10). 
ismember(761,1). ismember(761,4). ismember(761,5). ismember(761,6). ismember(761,7). ismember(761,8). ismember(761,10). 
ismember(762,2). ismember(762,4). ismember(762,5). ismember(762,6). ismember(762,7). ismember(762,8). ismember(762,10). 
ismember(763,1). ismember(763,2). ismember(763,4). ismember(763,5). ismember(763,6). ismember(763,7). ismember(763,8). ismember(763,10). 
ismember(764,3). ismember(764,4). ismember(764,5). ismember(764,6). ismember(764,7). ismember(764,8). ismember(764,10). 
ismember(765,1). ismember(765,3). ismember(765,4). ismember(765,5). ismember(765,6). ismember(765,7). ismember(765,8). ismember(765,10). 
ismember(766,2). ismember(766,3). ismember(766,4). ismember(766,5). ismember(766,6). ismember(766,7). ismember(766,8). ismember(766,10). 
ismember(767,1). ismember(767,2). ismember(767,3). ismember(767,4). ismember(767,5). ismember(767,6). ismember(767,7). ismember(767,8). ismember(767,10). 
ismember(768,9). ismember(768,10). 
ismember(769,1). ismember(769,9). ismember(769,10). 
ismember(770,2). ismember(770,9). ismember(770,10). 
ismember(771,1). ismember(771,2). ismember(771,9). ismember(771,10). 
ismember(772,3). ismember(772,9). ismember(772,10). 
ismember(773,1). ismember(773,3). ismember(773,9). ismember(773,10). 
ismember(774,2). ismember(774,3). ismember(774,9). ismember(774,10). 
ismember(775,1). ismember(775,2). ismember(775,3). ismember(775,9). ismember(775,10). 
ismember(776,4). ismember(776,9). ismember(776,10). 
ismember(777,1). ismember(777,4). ismember(777,9). ismember(777,10). 
ismember(778,2). ismember(778,4). ismember(778,9). ismember(778,10). 
ismember(779,1). ismember(779,2). ismember(779,4). ismember(779,9). ismember(779,10). 
ismember(780,3). ismember(780,4). ismember(780,9). ismember(780,10). 
ismember(781,1). ismember(781,3). ismember(781,4). ismember(781,9). ismember(781,10). 
ismember(782,2). ismember(782,3). ismember(782,4). ismember(782,9). ismember(782,10). 
ismember(783,1). ismember(783,2). ismember(783,3). ismember(783,4). ismember(783,9). ismember(783,10). 
ismember(784,5). ismember(784,9). ismember(784,10). 
ismember(785,1). ismember(785,5). ismember(785,9). ismember(785,10). 
ismember(786,2). ismember(786,5). ismember(786,9). ismember(786,10). 
ismember(787,1). ismember(787,2). ismember(787,5). ismember(787,9). ismember(787,10). 
ismember(788,3). ismember(788,5). ismember(788,9). ismember(788,10). 
ismember(789,1). ismember(789,3). ismember(789,5). ismember(789,9). ismember(789,10). 
ismember(790,2). ismember(790,3). ismember(790,5). ismember(790,9). ismember(790,10). 
ismember(791,1). ismember(791,2). ismember(791,3). ismember(791,5). ismember(791,9). ismember(791,10). 
ismember(792,4). ismember(792,5). ismember(792,9). ismember(792,10). 
ismember(793,1). ismember(793,4). ismember(793,5). ismember(793,9). ismember(793,10). 
ismember(794,2). ismember(794,4). ismember(794,5). ismember(794,9). ismember(794,10). 
ismember(795,1). ismember(795,2). ismember(795,4). ismember(795,5). ismember(795,9). ismember(795,10). 
ismember(796,3). ismember(796,4). ismember(796,5). ismember(796,9). ismember(796,10). 
ismember(797,1). ismember(797,3). ismember(797,4). ismember(797,5). ismember(797,9). ismember(797,10). 
ismember(798,2). ismember(798,3). ismember(798,4). ismember(798,5). ismember(798,9). ismember(798,10). 
ismember(799,1). ismember(799,2). ismember(799,3). ismember(799,4). ismember(799,5). ismember(799,9). ismember(799,10). 
ismember(800,6). ismember(800,9). ismember(800,10). 
ismember(801,1). ismember(801,6). ismember(801,9). ismember(801,10). 
ismember(802,2). ismember(802,6). ismember(802,9). ismember(802,10). 
ismember(803,1). ismember(803,2). ismember(803,6). ismember(803,9). ismember(803,10). 
ismember(804,3). ismember(804,6). ismember(804,9). ismember(804,10). 
ismember(805,1). ismember(805,3). ismember(805,6). ismember(805,9). ismember(805,10). 
ismember(806,2). ismember(806,3). ismember(806,6). ismember(806,9). ismember(806,10). 
ismember(807,1). ismember(807,2). ismember(807,3). ismember(807,6). ismember(807,9). ismember(807,10). 
ismember(808,4). ismember(808,6). ismember(808,9). ismember(808,10). 
ismember(809,1). ismember(809,4). ismember(809,6). ismember(809,9). ismember(809,10). 
ismember(810,2). ismember(810,4). ismember(810,6). ismember(810,9). ismember(810,10). 
ismember(811,1). ismember(811,2). ismember(811,4). ismember(811,6). ismember(811,9). ismember(811,10). 
ismember(812,3). ismember(812,4). ismember(812,6). ismember(812,9). ismember(812,10). 
ismember(813,1). ismember(813,3). ismember(813,4). ismember(813,6). ismember(813,9). ismember(813,10). 
ismember(814,2). ismember(814,3). ismember(814,4). ismember(814,6). ismember(814,9). ismember(814,10). 
ismember(815,1). ismember(815,2). ismember(815,3). ismember(815,4). ismember(815,6). ismember(815,9). ismember(815,10). 
ismember(816,5). ismember(816,6). ismember(816,9). ismember(816,10). 
ismember(817,1). ismember(817,5). ismember(817,6). ismember(817,9). ismember(817,10). 
ismember(818,2). ismember(818,5). ismember(818,6). ismember(818,9). ismember(818,10). 
ismember(819,1). ismember(819,2). ismember(819,5). ismember(819,6). ismember(819,9). ismember(819,10). 
ismember(820,3). ismember(820,5). ismember(820,6). ismember(820,9). ismember(820,10). 
ismember(821,1). ismember(821,3). ismember(821,5). ismember(821,6). ismember(821,9). ismember(821,10). 
ismember(822,2). ismember(822,3). ismember(822,5). ismember(822,6). ismember(822,9). ismember(822,10). 
ismember(823,1). ismember(823,2). ismember(823,3). ismember(823,5). ismember(823,6). ismember(823,9). ismember(823,10). 
ismember(824,4). ismember(824,5). ismember(824,6). ismember(824,9). ismember(824,10). 
ismember(825,1). ismember(825,4). ismember(825,5). ismember(825,6). ismember(825,9). ismember(825,10). 
ismember(826,2). ismember(826,4). ismember(826,5). ismember(826,6). ismember(826,9). ismember(826,10). 
ismember(827,1). ismember(827,2). ismember(827,4). ismember(827,5). ismember(827,6). ismember(827,9). ismember(827,10). 
ismember(828,3). ismember(828,4). ismember(828,5). ismember(828,6). ismember(828,9). ismember(828,10). 
ismember(829,1). ismember(829,3). ismember(829,4). ismember(829,5). ismember(829,6). ismember(829,9). ismember(829,10). 
ismember(830,2). ismember(830,3). ismember(830,4). ismember(830,5). ismember(830,6). ismember(830,9). ismember(830,10). 
ismember(831,1). ismember(831,2). ismember(831,3). ismember(831,4). ismember(831,5). ismember(831,6). ismember(831,9). ismember(831,10). 
ismember(832,7). ismember(832,9). ismember(832,10). 
ismember(833,1). ismember(833,7). ismember(833,9). ismember(833,10). 
ismember(834,2). ismember(834,7). ismember(834,9). ismember(834,10). 
ismember(835,1). ismember(835,2). ismember(835,7). ismember(835,9). ismember(835,10). 
ismember(836,3). ismember(836,7). ismember(836,9). ismember(836,10). 
ismember(837,1). ismember(837,3). ismember(837,7). ismember(837,9). ismember(837,10). 
ismember(838,2). ismember(838,3). ismember(838,7). ismember(838,9). ismember(838,10). 
ismember(839,1). ismember(839,2). ismember(839,3). ismember(839,7). ismember(839,9). ismember(839,10). 
ismember(840,4). ismember(840,7). ismember(840,9). ismember(840,10). 
ismember(841,1). ismember(841,4). ismember(841,7). ismember(841,9). ismember(841,10). 
ismember(842,2). ismember(842,4). ismember(842,7). ismember(842,9). ismember(842,10). 
ismember(843,1). ismember(843,2). ismember(843,4). ismember(843,7). ismember(843,9). ismember(843,10). 
ismember(844,3). ismember(844,4). ismember(844,7). ismember(844,9). ismember(844,10). 
ismember(845,1). ismember(845,3). ismember(845,4). ismember(845,7). ismember(845,9). ismember(845,10). 
ismember(846,2). ismember(846,3). ismember(846,4). ismember(846,7). ismember(846,9). ismember(846,10). 
ismember(847,1). ismember(847,2). ismember(847,3). ismember(847,4). ismember(847,7). ismember(847,9). ismember(847,10). 
ismember(848,5). ismember(848,7). ismember(848,9). ismember(848,10). 
ismember(849,1). ismember(849,5). ismember(849,7). ismember(849,9). ismember(849,10). 
ismember(850,2). ismember(850,5). ismember(850,7). ismember(850,9). ismember(850,10). 
ismember(851,1). ismember(851,2). ismember(851,5). ismember(851,7). ismember(851,9). ismember(851,10). 
ismember(852,3). ismember(852,5). ismember(852,7). ismember(852,9). ismember(852,10). 
ismember(853,1). ismember(853,3). ismember(853,5). ismember(853,7). ismember(853,9). ismember(853,10). 
ismember(854,2). ismember(854,3). ismember(854,5). ismember(854,7). ismember(854,9). ismember(854,10). 
ismember(855,1). ismember(855,2). ismember(855,3). ismember(855,5). ismember(855,7). ismember(855,9). ismember(855,10). 
ismember(856,4). ismember(856,5). ismember(856,7). ismember(856,9). ismember(856,10). 
ismember(857,1). ismember(857,4). ismember(857,5). ismember(857,7). ismember(857,9). ismember(857,10). 
ismember(858,2). ismember(858,4). ismember(858,5). ismember(858,7). ismember(858,9). ismember(858,10). 
ismember(859,1). ismember(859,2). ismember(859,4). ismember(859,5). ismember(859,7). ismember(859,9). ismember(859,10). 
ismember(860,3). ismember(860,4). ismember(860,5). ismember(860,7). ismember(860,9). ismember(860,10). 
ismember(861,1). ismember(861,3). ismember(861,4). ismember(861,5). ismember(861,7). ismember(861,9). ismember(861,10). 
ismember(862,2). ismember(862,3). ismember(862,4). ismember(862,5). ismember(862,7). ismember(862,9). ismember(862,10). 
ismember(863,1). ismember(863,2). ismember(863,3). ismember(863,4). ismember(863,5). ismember(863,7). ismember(863,9). ismember(863,10). 
ismember(864,6). ismember(864,7). ismember(864,9). ismember(864,10). 
ismember(865,1). ismember(865,6). ismember(865,7). ismember(865,9). ismember(865,10). 
ismember(866,2). ismember(866,6). ismember(866,7). ismember(866,9). ismember(866,10). 
ismember(867,1). ismember(867,2). ismember(867,6). ismember(867,7). ismember(867,9). ismember(867,10). 
ismember(868,3). ismember(868,6). ismember(868,7). ismember(868,9). ismember(868,10). 
ismember(869,1). ismember(869,3). ismember(869,6). ismember(869,7). ismember(869,9). ismember(869,10). 
ismember(870,2). ismember(870,3). ismember(870,6). ismember(870,7). ismember(870,9). ismember(870,10). 
ismember(871,1). ismember(871,2). ismember(871,3). ismember(871,6). ismember(871,7). ismember(871,9). ismember(871,10). 
ismember(872,4). ismember(872,6). ismember(872,7). ismember(872,9). ismember(872,10). 
ismember(873,1). ismember(873,4). ismember(873,6). ismember(873,7). ismember(873,9). ismember(873,10). 
ismember(874,2). ismember(874,4). ismember(874,6). ismember(874,7). ismember(874,9). ismember(874,10). 
ismember(875,1). ismember(875,2). ismember(875,4). ismember(875,6). ismember(875,7). ismember(875,9). ismember(875,10). 
ismember(876,3). ismember(876,4). ismember(876,6). ismember(876,7). ismember(876,9). ismember(876,10). 
ismember(877,1). ismember(877,3). ismember(877,4). ismember(877,6). ismember(877,7). ismember(877,9). ismember(877,10). 
ismember(878,2). ismember(878,3). ismember(878,4). ismember(878,6). ismember(878,7). ismember(878,9). ismember(878,10). 
ismember(879,1). ismember(879,2). ismember(879,3). ismember(879,4). ismember(879,6). ismember(879,7). ismember(879,9). ismember(879,10). 
ismember(880,5). ismember(880,6). ismember(880,7). ismember(880,9). ismember(880,10). 
ismember(881,1). ismember(881,5). ismember(881,6). ismember(881,7). ismember(881,9). ismember(881,10). 
ismember(882,2). ismember(882,5). ismember(882,6). ismember(882,7). ismember(882,9). ismember(882,10). 
ismember(883,1). ismember(883,2). ismember(883,5). ismember(883,6). ismember(883,7). ismember(883,9). ismember(883,10). 
ismember(884,3). ismember(884,5). ismember(884,6). ismember(884,7). ismember(884,9). ismember(884,10). 
ismember(885,1). ismember(885,3). ismember(885,5). ismember(885,6). ismember(885,7). ismember(885,9). ismember(885,10). 
ismember(886,2). ismember(886,3). ismember(886,5). ismember(886,6). ismember(886,7). ismember(886,9). ismember(886,10). 
ismember(887,1). ismember(887,2). ismember(887,3). ismember(887,5). ismember(887,6). ismember(887,7). ismember(887,9). ismember(887,10). 
ismember(888,4). ismember(888,5). ismember(888,6). ismember(888,7). ismember(888,9). ismember(888,10). 
ismember(889,1). ismember(889,4). ismember(889,5). ismember(889,6). ismember(889,7). ismember(889,9). ismember(889,10). 
ismember(890,2). ismember(890,4). ismember(890,5). ismember(890,6). ismember(890,7). ismember(890,9). ismember(890,10). 
ismember(891,1). ismember(891,2). ismember(891,4). ismember(891,5). ismember(891,6). ismember(891,7). ismember(891,9). ismember(891,10). 
ismember(892,3). ismember(892,4). ismember(892,5). ismember(892,6). ismember(892,7). ismember(892,9). ismember(892,10). 
ismember(893,1). ismember(893,3). ismember(893,4). ismember(893,5). ismember(893,6). ismember(893,7). ismember(893,9). ismember(893,10). 
ismember(894,2). ismember(894,3). ismember(894,4). ismember(894,5). ismember(894,6). ismember(894,7). ismember(894,9). ismember(894,10). 
ismember(895,1). ismember(895,2). ismember(895,3). ismember(895,4). ismember(895,5). ismember(895,6). ismember(895,7). ismember(895,9). ismember(895,10). 
ismember(896,8). ismember(896,9). ismember(896,10). 
ismember(897,1). ismember(897,8). ismember(897,9). ismember(897,10). 
ismember(898,2). ismember(898,8). ismember(898,9). ismember(898,10). 
ismember(899,1). ismember(899,2). ismember(899,8). ismember(899,9). ismember(899,10). 
ismember(900,3). ismember(900,8). ismember(900,9). ismember(900,10). 
ismember(901,1). ismember(901,3). ismember(901,8). ismember(901,9). ismember(901,10). 
ismember(902,2). ismember(902,3). ismember(902,8). ismember(902,9). ismember(902,10). 
ismember(903,1). ismember(903,2). ismember(903,3). ismember(903,8). ismember(903,9). ismember(903,10). 
ismember(904,4). ismember(904,8). ismember(904,9). ismember(904,10). 
ismember(905,1). ismember(905,4). ismember(905,8). ismember(905,9). ismember(905,10). 
ismember(906,2). ismember(906,4). ismember(906,8). ismember(906,9). ismember(906,10). 
ismember(907,1). ismember(907,2). ismember(907,4). ismember(907,8). ismember(907,9). ismember(907,10). 
ismember(908,3). ismember(908,4). ismember(908,8). ismember(908,9). ismember(908,10). 
ismember(909,1). ismember(909,3). ismember(909,4). ismember(909,8). ismember(909,9). ismember(909,10). 
ismember(910,2). ismember(910,3). ismember(910,4). ismember(910,8). ismember(910,9). ismember(910,10). 
ismember(911,1). ismember(911,2). ismember(911,3). ismember(911,4). ismember(911,8). ismember(911,9). ismember(911,10). 
ismember(912,5). ismember(912,8). ismember(912,9). ismember(912,10). 
ismember(913,1). ismember(913,5). ismember(913,8). ismember(913,9). ismember(913,10). 
ismember(914,2). ismember(914,5). ismember(914,8). ismember(914,9). ismember(914,10). 
ismember(915,1). ismember(915,2). ismember(915,5). ismember(915,8). ismember(915,9). ismember(915,10). 
ismember(916,3). ismember(916,5). ismember(916,8). ismember(916,9). ismember(916,10). 
ismember(917,1). ismember(917,3). ismember(917,5). ismember(917,8). ismember(917,9). ismember(917,10). 
ismember(918,2). ismember(918,3). ismember(918,5). ismember(918,8). ismember(918,9). ismember(918,10). 
ismember(919,1). ismember(919,2). ismember(919,3). ismember(919,5). ismember(919,8). ismember(919,9). ismember(919,10). 
ismember(920,4). ismember(920,5). ismember(920,8). ismember(920,9). ismember(920,10). 
ismember(921,1). ismember(921,4). ismember(921,5). ismember(921,8). ismember(921,9). ismember(921,10). 
ismember(922,2). ismember(922,4). ismember(922,5). ismember(922,8). ismember(922,9). ismember(922,10). 
ismember(923,1). ismember(923,2). ismember(923,4). ismember(923,5). ismember(923,8). ismember(923,9). ismember(923,10). 
ismember(924,3). ismember(924,4). ismember(924,5). ismember(924,8). ismember(924,9). ismember(924,10). 
ismember(925,1). ismember(925,3). ismember(925,4). ismember(925,5). ismember(925,8). ismember(925,9). ismember(925,10). 
ismember(926,2). ismember(926,3). ismember(926,4). ismember(926,5). ismember(926,8). ismember(926,9). ismember(926,10). 
ismember(927,1). ismember(927,2). ismember(927,3). ismember(927,4). ismember(927,5). ismember(927,8). ismember(927,9). ismember(927,10). 
ismember(928,6). ismember(928,8). ismember(928,9). ismember(928,10). 
ismember(929,1). ismember(929,6). ismember(929,8). ismember(929,9). ismember(929,10). 
ismember(930,2). ismember(930,6). ismember(930,8). ismember(930,9). ismember(930,10). 
ismember(931,1). ismember(931,2). ismember(931,6). ismember(931,8). ismember(931,9). ismember(931,10). 
ismember(932,3). ismember(932,6). ismember(932,8). ismember(932,9). ismember(932,10). 
ismember(933,1). ismember(933,3). ismember(933,6). ismember(933,8). ismember(933,9). ismember(933,10). 
ismember(934,2). ismember(934,3). ismember(934,6). ismember(934,8). ismember(934,9). ismember(934,10). 
ismember(935,1). ismember(935,2). ismember(935,3). ismember(935,6). ismember(935,8). ismember(935,9). ismember(935,10). 
ismember(936,4). ismember(936,6). ismember(936,8). ismember(936,9). ismember(936,10). 
ismember(937,1). ismember(937,4). ismember(937,6). ismember(937,8). ismember(937,9). ismember(937,10). 
ismember(938,2). ismember(938,4). ismember(938,6). ismember(938,8). ismember(938,9). ismember(938,10). 
ismember(939,1). ismember(939,2). ismember(939,4). ismember(939,6). ismember(939,8). ismember(939,9). ismember(939,10). 
ismember(940,3). ismember(940,4). ismember(940,6). ismember(940,8). ismember(940,9). ismember(940,10). 
ismember(941,1). ismember(941,3). ismember(941,4). ismember(941,6). ismember(941,8). ismember(941,9). ismember(941,10). 
ismember(942,2). ismember(942,3). ismember(942,4). ismember(942,6). ismember(942,8). ismember(942,9). ismember(942,10). 
ismember(943,1). ismember(943,2). ismember(943,3). ismember(943,4). ismember(943,6). ismember(943,8). ismember(943,9). ismember(943,10). 
ismember(944,5). ismember(944,6). ismember(944,8). ismember(944,9). ismember(944,10). 
ismember(945,1). ismember(945,5). ismember(945,6). ismember(945,8). ismember(945,9). ismember(945,10). 
ismember(946,2). ismember(946,5). ismember(946,6). ismember(946,8). ismember(946,9). ismember(946,10). 
ismember(947,1). ismember(947,2). ismember(947,5). ismember(947,6). ismember(947,8). ismember(947,9). ismember(947,10). 
ismember(948,3). ismember(948,5). ismember(948,6). ismember(948,8). ismember(948,9). ismember(948,10). 
ismember(949,1). ismember(949,3). ismember(949,5). ismember(949,6). ismember(949,8). ismember(949,9). ismember(949,10). 
ismember(950,2). ismember(950,3). ismember(950,5). ismember(950,6). ismember(950,8). ismember(950,9). ismember(950,10). 
ismember(951,1). ismember(951,2). ismember(951,3). ismember(951,5). ismember(951,6). ismember(951,8). ismember(951,9). ismember(951,10). 
ismember(952,4). ismember(952,5). ismember(952,6). ismember(952,8). ismember(952,9). ismember(952,10). 
ismember(953,1). ismember(953,4). ismember(953,5). ismember(953,6). ismember(953,8). ismember(953,9). ismember(953,10). 
ismember(954,2). ismember(954,4). ismember(954,5). ismember(954,6). ismember(954,8). ismember(954,9). ismember(954,10). 
ismember(955,1). ismember(955,2). ismember(955,4). ismember(955,5). ismember(955,6). ismember(955,8). ismember(955,9). ismember(955,10). 
ismember(956,3). ismember(956,4). ismember(956,5). ismember(956,6). ismember(956,8). ismember(956,9). ismember(956,10). 
ismember(957,1). ismember(957,3). ismember(957,4). ismember(957,5). ismember(957,6). ismember(957,8). ismember(957,9). ismember(957,10). 
ismember(958,2). ismember(958,3). ismember(958,4). ismember(958,5). ismember(958,6). ismember(958,8). ismember(958,9). ismember(958,10). 
ismember(959,1). ismember(959,2). ismember(959,3). ismember(959,4). ismember(959,5). ismember(959,6). ismember(959,8). ismember(959,9). ismember(959,10). 
ismember(960,7). ismember(960,8). ismember(960,9). ismember(960,10). 
ismember(961,1). ismember(961,7). ismember(961,8). ismember(961,9). ismember(961,10). 
ismember(962,2). ismember(962,7). ismember(962,8). ismember(962,9). ismember(962,10). 
ismember(963,1). ismember(963,2). ismember(963,7). ismember(963,8). ismember(963,9). ismember(963,10). 
ismember(964,3). ismember(964,7). ismember(964,8). ismember(964,9). ismember(964,10). 
ismember(965,1). ismember(965,3). ismember(965,7). ismember(965,8). ismember(965,9). ismember(965,10). 
ismember(966,2). ismember(966,3). ismember(966,7). ismember(966,8). ismember(966,9). ismember(966,10). 
ismember(967,1). ismember(967,2). ismember(967,3). ismember(967,7). ismember(967,8). ismember(967,9). ismember(967,10). 
ismember(968,4). ismember(968,7). ismember(968,8). ismember(968,9). ismember(968,10). 
ismember(969,1). ismember(969,4). ismember(969,7). ismember(969,8). ismember(969,9). ismember(969,10). 
ismember(970,2). ismember(970,4). ismember(970,7). ismember(970,8). ismember(970,9). ismember(970,10). 
ismember(971,1). ismember(971,2). ismember(971,4). ismember(971,7). ismember(971,8). ismember(971,9). ismember(971,10). 
ismember(972,3). ismember(972,4). ismember(972,7). ismember(972,8). ismember(972,9). ismember(972,10). 
ismember(973,1). ismember(973,3). ismember(973,4). ismember(973,7). ismember(973,8). ismember(973,9). ismember(973,10). 
ismember(974,2). ismember(974,3). ismember(974,4). ismember(974,7). ismember(974,8). ismember(974,9). ismember(974,10). 
ismember(975,1). ismember(975,2). ismember(975,3). ismember(975,4). ismember(975,7). ismember(975,8). ismember(975,9). ismember(975,10). 
ismember(976,5). ismember(976,7). ismember(976,8). ismember(976,9). ismember(976,10). 
ismember(977,1). ismember(977,5). ismember(977,7). ismember(977,8). ismember(977,9). ismember(977,10). 
ismember(978,2). ismember(978,5). ismember(978,7). ismember(978,8). ismember(978,9). ismember(978,10). 
ismember(979,1). ismember(979,2). ismember(979,5). ismember(979,7). ismember(979,8). ismember(979,9). ismember(979,10). 
ismember(980,3). ismember(980,5). ismember(980,7). ismember(980,8). ismember(980,9). ismember(980,10). 
ismember(981,1). ismember(981,3). ismember(981,5). ismember(981,7). ismember(981,8). ismember(981,9). ismember(981,10). 
ismember(982,2). ismember(982,3). ismember(982,5). ismember(982,7). ismember(982,8). ismember(982,9). ismember(982,10). 
ismember(983,1). ismember(983,2). ismember(983,3). ismember(983,5). ismember(983,7). ismember(983,8). ismember(983,9). ismember(983,10). 
ismember(984,4). ismember(984,5). ismember(984,7). ismember(984,8). ismember(984,9). ismember(984,10). 
ismember(985,1). ismember(985,4). ismember(985,5). ismember(985,7). ismember(985,8). ismember(985,9). ismember(985,10). 
ismember(986,2). ismember(986,4). ismember(986,5). ismember(986,7). ismember(986,8). ismember(986,9). ismember(986,10). 
ismember(987,1). ismember(987,2). ismember(987,4). ismember(987,5). ismember(987,7). ismember(987,8). ismember(987,9). ismember(987,10). 
ismember(988,3). ismember(988,4). ismember(988,5). ismember(988,7). ismember(988,8). ismember(988,9). ismember(988,10). 
ismember(989,1). ismember(989,3). ismember(989,4). ismember(989,5). ismember(989,7). ismember(989,8). ismember(989,9). ismember(989,10). 
ismember(990,2). ismember(990,3). ismember(990,4). ismember(990,5). ismember(990,7). ismember(990,8). ismember(990,9). ismember(990,10). 
ismember(991,1). ismember(991,2). ismember(991,3). ismember(991,4). ismember(991,5). ismember(991,7). ismember(991,8). ismember(991,9). ismember(991,10). 
ismember(992,6). ismember(992,7). ismember(992,8). ismember(992,9). ismember(992,10). 
ismember(993,1). ismember(993,6). ismember(993,7). ismember(993,8). ismember(993,9). ismember(993,10). 
ismember(994,2). ismember(994,6). ismember(994,7). ismember(994,8). ismember(994,9). ismember(994,10). 
ismember(995,1). ismember(995,2). ismember(995,6). ismember(995,7). ismember(995,8). ismember(995,9). ismember(995,10). 
ismember(996,3). ismember(996,6). ismember(996,7). ismember(996,8). ismember(996,9). ismember(996,10). 
ismember(997,1). ismember(997,3). ismember(997,6). ismember(997,7). ismember(997,8). ismember(997,9). ismember(997,10). 
ismember(998,2). ismember(998,3). ismember(998,6). ismember(998,7). ismember(998,8). ismember(998,9). ismember(998,10). 
ismember(999,1). ismember(999,2). ismember(999,3). ismember(999,6). ismember(999,7). ismember(999,8). ismember(999,9). ismember(999,10). 
ismember(1000,4). ismember(1000,6). ismember(1000,7). ismember(1000,8). ismember(1000,9). ismember(1000,10). 
ismember(1001,1). ismember(1001,4). ismember(1001,6). ismember(1001,7). ismember(1001,8). ismember(1001,9). ismember(1001,10). 
ismember(1002,2). ismember(1002,4). ismember(1002,6). ismember(1002,7). ismember(1002,8). ismember(1002,9). ismember(1002,10). 
ismember(1003,1). ismember(1003,2). ismember(1003,4). ismember(1003,6). ismember(1003,7). ismember(1003,8). ismember(1003,9). ismember(1003,10). 
ismember(1004,3). ismember(1004,4). ismember(1004,6). ismember(1004,7). ismember(1004,8). ismember(1004,9). ismember(1004,10). 
ismember(1005,1). ismember(1005,3). ismember(1005,4). ismember(1005,6). ismember(1005,7). ismember(1005,8). ismember(1005,9). ismember(1005,10). 
ismember(1006,2). ismember(1006,3). ismember(1006,4). ismember(1006,6). ismember(1006,7). ismember(1006,8). ismember(1006,9). ismember(1006,10). 
ismember(1007,1). ismember(1007,2). ismember(1007,3). ismember(1007,4). ismember(1007,6). ismember(1007,7). ismember(1007,8). ismember(1007,9). ismember(1007,10). 
ismember(1008,5). ismember(1008,6). ismember(1008,7). ismember(1008,8). ismember(1008,9). ismember(1008,10). 
ismember(1009,1). ismember(1009,5). ismember(1009,6). ismember(1009,7). ismember(1009,8). ismember(1009,9). ismember(1009,10). 
ismember(1010,2). ismember(1010,5). ismember(1010,6). ismember(1010,7). ismember(1010,8). ismember(1010,9). ismember(1010,10). 
ismember(1011,1). ismember(1011,2). ismember(1011,5). ismember(1011,6). ismember(1011,7). ismember(1011,8). ismember(1011,9). ismember(1011,10). 
ismember(1012,3). ismember(1012,5). ismember(1012,6). ismember(1012,7). ismember(1012,8). ismember(1012,9). ismember(1012,10). 
ismember(1013,1). ismember(1013,3). ismember(1013,5). ismember(1013,6). ismember(1013,7). ismember(1013,8). ismember(1013,9). ismember(1013,10). 
ismember(1014,2). ismember(1014,3). ismember(1014,5). ismember(1014,6). ismember(1014,7). ismember(1014,8). ismember(1014,9). ismember(1014,10). 
ismember(1015,1). ismember(1015,2). ismember(1015,3). ismember(1015,5). ismember(1015,6). ismember(1015,7). ismember(1015,8). ismember(1015,9). ismember(1015,10). 
ismember(1016,4). ismember(1016,5). ismember(1016,6). ismember(1016,7). ismember(1016,8). ismember(1016,9). ismember(1016,10). 
ismember(1017,1). ismember(1017,4). ismember(1017,5). ismember(1017,6). ismember(1017,7). ismember(1017,8). ismember(1017,9). ismember(1017,10). 
ismember(1018,2). ismember(1018,4). ismember(1018,5). ismember(1018,6). ismember(1018,7). ismember(1018,8). ismember(1018,9). ismember(1018,10). 
ismember(1019,1). ismember(1019,2). ismember(1019,4). ismember(1019,5). ismember(1019,6). ismember(1019,7). ismember(1019,8). ismember(1019,9). ismember(1019,10). 
ismember(1020,3). ismember(1020,4). ismember(1020,5). ismember(1020,6). ismember(1020,7). ismember(1020,8). ismember(1020,9). ismember(1020,10). 
ismember(1021,1). ismember(1021,3). ismember(1021,4). ismember(1021,5). ismember(1021,6). ismember(1021,7). ismember(1021,8). ismember(1021,9). ismember(1021,10). 
ismember(1022,2). ismember(1022,3). ismember(1022,4). ismember(1022,5). ismember(1022,6). ismember(1022,7). ismember(1022,8). ismember(1022,9). ismember(1022,10). 
ismember(1023,1). ismember(1023,2). ismember(1023,3). ismember(1023,4). ismember(1023,5). ismember(1023,6). ismember(1023,7). ismember(1023,8). ismember(1023,9). ismember(1023,10). 
ismember(1024,11). 
ismember(1025,1). ismember(1025,11). 
ismember(1026,2). ismember(1026,11). 
ismember(1027,1). ismember(1027,2). ismember(1027,11). 
ismember(1028,3). ismember(1028,11). 
ismember(1029,1). ismember(1029,3). ismember(1029,11). 
ismember(1030,2). ismember(1030,3). ismember(1030,11). 
ismember(1031,1). ismember(1031,2). ismember(1031,3). ismember(1031,11). 
ismember(1032,4). ismember(1032,11). 
ismember(1033,1). ismember(1033,4). ismember(1033,11). 
ismember(1034,2). ismember(1034,4). ismember(1034,11). 
ismember(1035,1). ismember(1035,2). ismember(1035,4). ismember(1035,11). 
ismember(1036,3). ismember(1036,4). ismember(1036,11). 
ismember(1037,1). ismember(1037,3). ismember(1037,4). ismember(1037,11). 
ismember(1038,2). ismember(1038,3). ismember(1038,4). ismember(1038,11). 
ismember(1039,1). ismember(1039,2). ismember(1039,3). ismember(1039,4). ismember(1039,11). 
ismember(1040,5). ismember(1040,11). 
ismember(1041,1). ismember(1041,5). ismember(1041,11). 
ismember(1042,2). ismember(1042,5). ismember(1042,11). 
ismember(1043,1). ismember(1043,2). ismember(1043,5). ismember(1043,11). 
ismember(1044,3). ismember(1044,5). ismember(1044,11). 
ismember(1045,1). ismember(1045,3). ismember(1045,5). ismember(1045,11). 
ismember(1046,2). ismember(1046,3). ismember(1046,5). ismember(1046,11). 
ismember(1047,1). ismember(1047,2). ismember(1047,3). ismember(1047,5). ismember(1047,11). 
ismember(1048,4). ismember(1048,5). ismember(1048,11). 
ismember(1049,1). ismember(1049,4). ismember(1049,5). ismember(1049,11). 
ismember(1050,2). ismember(1050,4). ismember(1050,5). ismember(1050,11). 
ismember(1051,1). ismember(1051,2). ismember(1051,4). ismember(1051,5). ismember(1051,11). 
ismember(1052,3). ismember(1052,4). ismember(1052,5). ismember(1052,11). 
ismember(1053,1). ismember(1053,3). ismember(1053,4). ismember(1053,5). ismember(1053,11). 
ismember(1054,2). ismember(1054,3). ismember(1054,4). ismember(1054,5). ismember(1054,11). 
ismember(1055,1). ismember(1055,2). ismember(1055,3). ismember(1055,4). ismember(1055,5). ismember(1055,11). 
ismember(1056,6). ismember(1056,11). 
ismember(1057,1). ismember(1057,6). ismember(1057,11). 
ismember(1058,2). ismember(1058,6). ismember(1058,11). 
ismember(1059,1). ismember(1059,2). ismember(1059,6). ismember(1059,11). 
ismember(1060,3). ismember(1060,6). ismember(1060,11). 
ismember(1061,1). ismember(1061,3). ismember(1061,6). ismember(1061,11). 
ismember(1062,2). ismember(1062,3). ismember(1062,6). ismember(1062,11). 
ismember(1063,1). ismember(1063,2). ismember(1063,3). ismember(1063,6). ismember(1063,11). 
ismember(1064,4). ismember(1064,6). ismember(1064,11). 
ismember(1065,1). ismember(1065,4). ismember(1065,6). ismember(1065,11). 
ismember(1066,2). ismember(1066,4). ismember(1066,6). ismember(1066,11). 
ismember(1067,1). ismember(1067,2). ismember(1067,4). ismember(1067,6). ismember(1067,11). 
ismember(1068,3). ismember(1068,4). ismember(1068,6). ismember(1068,11). 
ismember(1069,1). ismember(1069,3). ismember(1069,4). ismember(1069,6). ismember(1069,11). 
ismember(1070,2). ismember(1070,3). ismember(1070,4). ismember(1070,6). ismember(1070,11). 
ismember(1071,1). ismember(1071,2). ismember(1071,3). ismember(1071,4). ismember(1071,6). ismember(1071,11). 
ismember(1072,5). ismember(1072,6). ismember(1072,11). 
ismember(1073,1). ismember(1073,5). ismember(1073,6). ismember(1073,11). 
ismember(1074,2). ismember(1074,5). ismember(1074,6). ismember(1074,11). 
ismember(1075,1). ismember(1075,2). ismember(1075,5). ismember(1075,6). ismember(1075,11). 
ismember(1076,3). ismember(1076,5). ismember(1076,6). ismember(1076,11). 
ismember(1077,1). ismember(1077,3). ismember(1077,5). ismember(1077,6). ismember(1077,11). 
ismember(1078,2). ismember(1078,3). ismember(1078,5). ismember(1078,6). ismember(1078,11). 
ismember(1079,1). ismember(1079,2). ismember(1079,3). ismember(1079,5). ismember(1079,6). ismember(1079,11). 
ismember(1080,4). ismember(1080,5). ismember(1080,6). ismember(1080,11). 
ismember(1081,1). ismember(1081,4). ismember(1081,5). ismember(1081,6). ismember(1081,11). 
ismember(1082,2). ismember(1082,4). ismember(1082,5). ismember(1082,6). ismember(1082,11). 
ismember(1083,1). ismember(1083,2). ismember(1083,4). ismember(1083,5). ismember(1083,6). ismember(1083,11). 
ismember(1084,3). ismember(1084,4). ismember(1084,5). ismember(1084,6). ismember(1084,11). 
ismember(1085,1). ismember(1085,3). ismember(1085,4). ismember(1085,5). ismember(1085,6). ismember(1085,11). 
ismember(1086,2). ismember(1086,3). ismember(1086,4). ismember(1086,5). ismember(1086,6). ismember(1086,11). 
ismember(1087,1). ismember(1087,2). ismember(1087,3). ismember(1087,4). ismember(1087,5). ismember(1087,6). ismember(1087,11). 
ismember(1088,7). ismember(1088,11). 
ismember(1089,1). ismember(1089,7). ismember(1089,11). 
ismember(1090,2). ismember(1090,7). ismember(1090,11). 
ismember(1091,1). ismember(1091,2). ismember(1091,7). ismember(1091,11). 
ismember(1092,3). ismember(1092,7). ismember(1092,11). 
ismember(1093,1). ismember(1093,3). ismember(1093,7). ismember(1093,11). 
ismember(1094,2). ismember(1094,3). ismember(1094,7). ismember(1094,11). 
ismember(1095,1). ismember(1095,2). ismember(1095,3). ismember(1095,7). ismember(1095,11). 
ismember(1096,4). ismember(1096,7). ismember(1096,11). 
ismember(1097,1). ismember(1097,4). ismember(1097,7). ismember(1097,11). 
ismember(1098,2). ismember(1098,4). ismember(1098,7). ismember(1098,11). 
ismember(1099,1). ismember(1099,2). ismember(1099,4). ismember(1099,7). ismember(1099,11). 
ismember(1100,3). ismember(1100,4). ismember(1100,7). ismember(1100,11). 
ismember(1101,1). ismember(1101,3). ismember(1101,4). ismember(1101,7). ismember(1101,11). 
ismember(1102,2). ismember(1102,3). ismember(1102,4). ismember(1102,7). ismember(1102,11). 
ismember(1103,1). ismember(1103,2). ismember(1103,3). ismember(1103,4). ismember(1103,7). ismember(1103,11). 
ismember(1104,5). ismember(1104,7). ismember(1104,11). 
ismember(1105,1). ismember(1105,5). ismember(1105,7). ismember(1105,11). 
ismember(1106,2). ismember(1106,5). ismember(1106,7). ismember(1106,11). 
ismember(1107,1). ismember(1107,2). ismember(1107,5). ismember(1107,7). ismember(1107,11). 
ismember(1108,3). ismember(1108,5). ismember(1108,7). ismember(1108,11). 
ismember(1109,1). ismember(1109,3). ismember(1109,5). ismember(1109,7). ismember(1109,11). 
ismember(1110,2). ismember(1110,3). ismember(1110,5). ismember(1110,7). ismember(1110,11). 
ismember(1111,1). ismember(1111,2). ismember(1111,3). ismember(1111,5). ismember(1111,7). ismember(1111,11). 
ismember(1112,4). ismember(1112,5). ismember(1112,7). ismember(1112,11). 
ismember(1113,1). ismember(1113,4). ismember(1113,5). ismember(1113,7). ismember(1113,11). 
ismember(1114,2). ismember(1114,4). ismember(1114,5). ismember(1114,7). ismember(1114,11). 
ismember(1115,1). ismember(1115,2). ismember(1115,4). ismember(1115,5). ismember(1115,7). ismember(1115,11). 
ismember(1116,3). ismember(1116,4). ismember(1116,5). ismember(1116,7). ismember(1116,11). 
ismember(1117,1). ismember(1117,3). ismember(1117,4). ismember(1117,5). ismember(1117,7). ismember(1117,11). 
ismember(1118,2). ismember(1118,3). ismember(1118,4). ismember(1118,5). ismember(1118,7). ismember(1118,11). 
ismember(1119,1). ismember(1119,2). ismember(1119,3). ismember(1119,4). ismember(1119,5). ismember(1119,7). ismember(1119,11). 
ismember(1120,6). ismember(1120,7). ismember(1120,11). 
ismember(1121,1). ismember(1121,6). ismember(1121,7). ismember(1121,11). 
ismember(1122,2). ismember(1122,6). ismember(1122,7). ismember(1122,11). 
ismember(1123,1). ismember(1123,2). ismember(1123,6). ismember(1123,7). ismember(1123,11). 
ismember(1124,3). ismember(1124,6). ismember(1124,7). ismember(1124,11). 
ismember(1125,1). ismember(1125,3). ismember(1125,6). ismember(1125,7). ismember(1125,11). 
ismember(1126,2). ismember(1126,3). ismember(1126,6). ismember(1126,7). ismember(1126,11). 
ismember(1127,1). ismember(1127,2). ismember(1127,3). ismember(1127,6). ismember(1127,7). ismember(1127,11). 
ismember(1128,4). ismember(1128,6). ismember(1128,7). ismember(1128,11). 
ismember(1129,1). ismember(1129,4). ismember(1129,6). ismember(1129,7). ismember(1129,11). 
ismember(1130,2). ismember(1130,4). ismember(1130,6). ismember(1130,7). ismember(1130,11). 
ismember(1131,1). ismember(1131,2). ismember(1131,4). ismember(1131,6). ismember(1131,7). ismember(1131,11). 
ismember(1132,3). ismember(1132,4). ismember(1132,6). ismember(1132,7). ismember(1132,11). 
ismember(1133,1). ismember(1133,3). ismember(1133,4). ismember(1133,6). ismember(1133,7). ismember(1133,11). 
ismember(1134,2). ismember(1134,3). ismember(1134,4). ismember(1134,6). ismember(1134,7). ismember(1134,11). 
ismember(1135,1). ismember(1135,2). ismember(1135,3). ismember(1135,4). ismember(1135,6). ismember(1135,7). ismember(1135,11). 
ismember(1136,5). ismember(1136,6). ismember(1136,7). ismember(1136,11). 
ismember(1137,1). ismember(1137,5). ismember(1137,6). ismember(1137,7). ismember(1137,11). 
ismember(1138,2). ismember(1138,5). ismember(1138,6). ismember(1138,7). ismember(1138,11). 
ismember(1139,1). ismember(1139,2). ismember(1139,5). ismember(1139,6). ismember(1139,7). ismember(1139,11). 
ismember(1140,3). ismember(1140,5). ismember(1140,6). ismember(1140,7). ismember(1140,11). 
ismember(1141,1). ismember(1141,3). ismember(1141,5). ismember(1141,6). ismember(1141,7). ismember(1141,11). 
ismember(1142,2). ismember(1142,3). ismember(1142,5). ismember(1142,6). ismember(1142,7). ismember(1142,11). 
ismember(1143,1). ismember(1143,2). ismember(1143,3). ismember(1143,5). ismember(1143,6). ismember(1143,7). ismember(1143,11). 
ismember(1144,4). ismember(1144,5). ismember(1144,6). ismember(1144,7). ismember(1144,11). 
ismember(1145,1). ismember(1145,4). ismember(1145,5). ismember(1145,6). ismember(1145,7). ismember(1145,11). 
ismember(1146,2). ismember(1146,4). ismember(1146,5). ismember(1146,6). ismember(1146,7). ismember(1146,11). 
ismember(1147,1). ismember(1147,2). ismember(1147,4). ismember(1147,5). ismember(1147,6). ismember(1147,7). ismember(1147,11). 
ismember(1148,3). ismember(1148,4). ismember(1148,5). ismember(1148,6). ismember(1148,7). ismember(1148,11). 
ismember(1149,1). ismember(1149,3). ismember(1149,4). ismember(1149,5). ismember(1149,6). ismember(1149,7). ismember(1149,11). 
ismember(1150,2). ismember(1150,3). ismember(1150,4). ismember(1150,5). ismember(1150,6). ismember(1150,7). ismember(1150,11). 
ismember(1151,1). ismember(1151,2). ismember(1151,3). ismember(1151,4). ismember(1151,5). ismember(1151,6). ismember(1151,7). ismember(1151,11). 
ismember(1152,8). ismember(1152,11). 
ismember(1153,1). ismember(1153,8). ismember(1153,11). 
ismember(1154,2). ismember(1154,8). ismember(1154,11). 
ismember(1155,1). ismember(1155,2). ismember(1155,8). ismember(1155,11). 
ismember(1156,3). ismember(1156,8). ismember(1156,11). 
ismember(1157,1). ismember(1157,3). ismember(1157,8). ismember(1157,11). 
ismember(1158,2). ismember(1158,3). ismember(1158,8). ismember(1158,11). 
ismember(1159,1). ismember(1159,2). ismember(1159,3). ismember(1159,8). ismember(1159,11). 
ismember(1160,4). ismember(1160,8). ismember(1160,11). 
ismember(1161,1). ismember(1161,4). ismember(1161,8). ismember(1161,11). 
ismember(1162,2). ismember(1162,4). ismember(1162,8). ismember(1162,11). 
ismember(1163,1). ismember(1163,2). ismember(1163,4). ismember(1163,8). ismember(1163,11). 
ismember(1164,3). ismember(1164,4). ismember(1164,8). ismember(1164,11). 
ismember(1165,1). ismember(1165,3). ismember(1165,4). ismember(1165,8). ismember(1165,11). 
ismember(1166,2). ismember(1166,3). ismember(1166,4). ismember(1166,8). ismember(1166,11). 
ismember(1167,1). ismember(1167,2). ismember(1167,3). ismember(1167,4). ismember(1167,8). ismember(1167,11). 
ismember(1168,5). ismember(1168,8). ismember(1168,11). 
ismember(1169,1). ismember(1169,5). ismember(1169,8). ismember(1169,11). 
ismember(1170,2). ismember(1170,5). ismember(1170,8). ismember(1170,11). 
ismember(1171,1). ismember(1171,2). ismember(1171,5). ismember(1171,8). ismember(1171,11). 
ismember(1172,3). ismember(1172,5). ismember(1172,8). ismember(1172,11). 
ismember(1173,1). ismember(1173,3). ismember(1173,5). ismember(1173,8). ismember(1173,11). 
ismember(1174,2). ismember(1174,3). ismember(1174,5). ismember(1174,8). ismember(1174,11). 
ismember(1175,1). ismember(1175,2). ismember(1175,3). ismember(1175,5). ismember(1175,8). ismember(1175,11). 
ismember(1176,4). ismember(1176,5). ismember(1176,8). ismember(1176,11). 
ismember(1177,1). ismember(1177,4). ismember(1177,5). ismember(1177,8). ismember(1177,11). 
ismember(1178,2). ismember(1178,4). ismember(1178,5). ismember(1178,8). ismember(1178,11). 
ismember(1179,1). ismember(1179,2). ismember(1179,4). ismember(1179,5). ismember(1179,8). ismember(1179,11). 
ismember(1180,3). ismember(1180,4). ismember(1180,5). ismember(1180,8). ismember(1180,11). 
ismember(1181,1). ismember(1181,3). ismember(1181,4). ismember(1181,5). ismember(1181,8). ismember(1181,11). 
ismember(1182,2). ismember(1182,3). ismember(1182,4). ismember(1182,5). ismember(1182,8). ismember(1182,11). 
ismember(1183,1). ismember(1183,2). ismember(1183,3). ismember(1183,4). ismember(1183,5). ismember(1183,8). ismember(1183,11). 
ismember(1184,6). ismember(1184,8). ismember(1184,11). 
ismember(1185,1). ismember(1185,6). ismember(1185,8). ismember(1185,11). 
ismember(1186,2). ismember(1186,6). ismember(1186,8). ismember(1186,11). 
ismember(1187,1). ismember(1187,2). ismember(1187,6). ismember(1187,8). ismember(1187,11). 
ismember(1188,3). ismember(1188,6). ismember(1188,8). ismember(1188,11). 
ismember(1189,1). ismember(1189,3). ismember(1189,6). ismember(1189,8). ismember(1189,11). 
ismember(1190,2). ismember(1190,3). ismember(1190,6). ismember(1190,8). ismember(1190,11). 
ismember(1191,1). ismember(1191,2). ismember(1191,3). ismember(1191,6). ismember(1191,8). ismember(1191,11). 
ismember(1192,4). ismember(1192,6). ismember(1192,8). ismember(1192,11). 
ismember(1193,1). ismember(1193,4). ismember(1193,6). ismember(1193,8). ismember(1193,11). 
ismember(1194,2). ismember(1194,4). ismember(1194,6). ismember(1194,8). ismember(1194,11). 
ismember(1195,1). ismember(1195,2). ismember(1195,4). ismember(1195,6). ismember(1195,8). ismember(1195,11). 
ismember(1196,3). ismember(1196,4). ismember(1196,6). ismember(1196,8). ismember(1196,11). 
ismember(1197,1). ismember(1197,3). ismember(1197,4). ismember(1197,6). ismember(1197,8). ismember(1197,11). 
ismember(1198,2). ismember(1198,3). ismember(1198,4). ismember(1198,6). ismember(1198,8). ismember(1198,11). 
ismember(1199,1). ismember(1199,2). ismember(1199,3). ismember(1199,4). ismember(1199,6). ismember(1199,8). ismember(1199,11). 
ismember(1200,5). ismember(1200,6). ismember(1200,8). ismember(1200,11). 
ismember(1201,1). ismember(1201,5). ismember(1201,6). ismember(1201,8). ismember(1201,11). 
ismember(1202,2). ismember(1202,5). ismember(1202,6). ismember(1202,8). ismember(1202,11). 
ismember(1203,1). ismember(1203,2). ismember(1203,5). ismember(1203,6). ismember(1203,8). ismember(1203,11). 
ismember(1204,3). ismember(1204,5). ismember(1204,6). ismember(1204,8). ismember(1204,11). 
ismember(1205,1). ismember(1205,3). ismember(1205,5). ismember(1205,6). ismember(1205,8). ismember(1205,11). 
ismember(1206,2). ismember(1206,3). ismember(1206,5). ismember(1206,6). ismember(1206,8). ismember(1206,11). 
ismember(1207,1). ismember(1207,2). ismember(1207,3). ismember(1207,5). ismember(1207,6). ismember(1207,8). ismember(1207,11). 
ismember(1208,4). ismember(1208,5). ismember(1208,6). ismember(1208,8). ismember(1208,11). 
ismember(1209,1). ismember(1209,4). ismember(1209,5). ismember(1209,6). ismember(1209,8). ismember(1209,11). 
ismember(1210,2). ismember(1210,4). ismember(1210,5). ismember(1210,6). ismember(1210,8). ismember(1210,11). 
ismember(1211,1). ismember(1211,2). ismember(1211,4). ismember(1211,5). ismember(1211,6). ismember(1211,8). ismember(1211,11). 
ismember(1212,3). ismember(1212,4). ismember(1212,5). ismember(1212,6). ismember(1212,8). ismember(1212,11). 
ismember(1213,1). ismember(1213,3). ismember(1213,4). ismember(1213,5). ismember(1213,6). ismember(1213,8). ismember(1213,11). 
ismember(1214,2). ismember(1214,3). ismember(1214,4). ismember(1214,5). ismember(1214,6). ismember(1214,8). ismember(1214,11). 
ismember(1215,1). ismember(1215,2). ismember(1215,3). ismember(1215,4). ismember(1215,5). ismember(1215,6). ismember(1215,8). ismember(1215,11). 
ismember(1216,7). ismember(1216,8). ismember(1216,11). 
ismember(1217,1). ismember(1217,7). ismember(1217,8). ismember(1217,11). 
ismember(1218,2). ismember(1218,7). ismember(1218,8). ismember(1218,11). 
ismember(1219,1). ismember(1219,2). ismember(1219,7). ismember(1219,8). ismember(1219,11). 
ismember(1220,3). ismember(1220,7). ismember(1220,8). ismember(1220,11). 
ismember(1221,1). ismember(1221,3). ismember(1221,7). ismember(1221,8). ismember(1221,11). 
ismember(1222,2). ismember(1222,3). ismember(1222,7). ismember(1222,8). ismember(1222,11). 
ismember(1223,1). ismember(1223,2). ismember(1223,3). ismember(1223,7). ismember(1223,8). ismember(1223,11). 
ismember(1224,4). ismember(1224,7). ismember(1224,8). ismember(1224,11). 
ismember(1225,1). ismember(1225,4). ismember(1225,7). ismember(1225,8). ismember(1225,11). 
ismember(1226,2). ismember(1226,4). ismember(1226,7). ismember(1226,8). ismember(1226,11). 
ismember(1227,1). ismember(1227,2). ismember(1227,4). ismember(1227,7). ismember(1227,8). ismember(1227,11). 
ismember(1228,3). ismember(1228,4). ismember(1228,7). ismember(1228,8). ismember(1228,11). 
ismember(1229,1). ismember(1229,3). ismember(1229,4). ismember(1229,7). ismember(1229,8). ismember(1229,11). 
ismember(1230,2). ismember(1230,3). ismember(1230,4). ismember(1230,7). ismember(1230,8). ismember(1230,11). 
ismember(1231,1). ismember(1231,2). ismember(1231,3). ismember(1231,4). ismember(1231,7). ismember(1231,8). ismember(1231,11). 
ismember(1232,5). ismember(1232,7). ismember(1232,8). ismember(1232,11). 
ismember(1233,1). ismember(1233,5). ismember(1233,7). ismember(1233,8). ismember(1233,11). 
ismember(1234,2). ismember(1234,5). ismember(1234,7). ismember(1234,8). ismember(1234,11). 
ismember(1235,1). ismember(1235,2). ismember(1235,5). ismember(1235,7). ismember(1235,8). ismember(1235,11). 
ismember(1236,3). ismember(1236,5). ismember(1236,7). ismember(1236,8). ismember(1236,11). 
ismember(1237,1). ismember(1237,3). ismember(1237,5). ismember(1237,7). ismember(1237,8). ismember(1237,11). 
ismember(1238,2). ismember(1238,3). ismember(1238,5). ismember(1238,7). ismember(1238,8). ismember(1238,11). 
ismember(1239,1). ismember(1239,2). ismember(1239,3). ismember(1239,5). ismember(1239,7). ismember(1239,8). ismember(1239,11). 
ismember(1240,4). ismember(1240,5). ismember(1240,7). ismember(1240,8). ismember(1240,11). 
ismember(1241,1). ismember(1241,4). ismember(1241,5). ismember(1241,7). ismember(1241,8). ismember(1241,11). 
ismember(1242,2). ismember(1242,4). ismember(1242,5). ismember(1242,7). ismember(1242,8). ismember(1242,11). 
ismember(1243,1). ismember(1243,2). ismember(1243,4). ismember(1243,5). ismember(1243,7). ismember(1243,8). ismember(1243,11). 
ismember(1244,3). ismember(1244,4). ismember(1244,5). ismember(1244,7). ismember(1244,8). ismember(1244,11). 
ismember(1245,1). ismember(1245,3). ismember(1245,4). ismember(1245,5). ismember(1245,7). ismember(1245,8). ismember(1245,11). 
ismember(1246,2). ismember(1246,3). ismember(1246,4). ismember(1246,5). ismember(1246,7). ismember(1246,8). ismember(1246,11). 
ismember(1247,1). ismember(1247,2). ismember(1247,3). ismember(1247,4). ismember(1247,5). ismember(1247,7). ismember(1247,8). ismember(1247,11). 
ismember(1248,6). ismember(1248,7). ismember(1248,8). ismember(1248,11). 
ismember(1249,1). ismember(1249,6). ismember(1249,7). ismember(1249,8). ismember(1249,11). 
ismember(1250,2). ismember(1250,6). ismember(1250,7). ismember(1250,8). ismember(1250,11). 
ismember(1251,1). ismember(1251,2). ismember(1251,6). ismember(1251,7). ismember(1251,8). ismember(1251,11). 
ismember(1252,3). ismember(1252,6). ismember(1252,7). ismember(1252,8). ismember(1252,11). 
ismember(1253,1). ismember(1253,3). ismember(1253,6). ismember(1253,7). ismember(1253,8). ismember(1253,11). 
ismember(1254,2). ismember(1254,3). ismember(1254,6). ismember(1254,7). ismember(1254,8). ismember(1254,11). 
ismember(1255,1). ismember(1255,2). ismember(1255,3). ismember(1255,6). ismember(1255,7). ismember(1255,8). ismember(1255,11). 
ismember(1256,4). ismember(1256,6). ismember(1256,7). ismember(1256,8). ismember(1256,11). 
ismember(1257,1). ismember(1257,4). ismember(1257,6). ismember(1257,7). ismember(1257,8). ismember(1257,11). 
ismember(1258,2). ismember(1258,4). ismember(1258,6). ismember(1258,7). ismember(1258,8). ismember(1258,11). 
ismember(1259,1). ismember(1259,2). ismember(1259,4). ismember(1259,6). ismember(1259,7). ismember(1259,8). ismember(1259,11). 
ismember(1260,3). ismember(1260,4). ismember(1260,6). ismember(1260,7). ismember(1260,8). ismember(1260,11). 
ismember(1261,1). ismember(1261,3). ismember(1261,4). ismember(1261,6). ismember(1261,7). ismember(1261,8). ismember(1261,11). 
ismember(1262,2). ismember(1262,3). ismember(1262,4). ismember(1262,6). ismember(1262,7). ismember(1262,8). ismember(1262,11). 
ismember(1263,1). ismember(1263,2). ismember(1263,3). ismember(1263,4). ismember(1263,6). ismember(1263,7). ismember(1263,8). ismember(1263,11). 
ismember(1264,5). ismember(1264,6). ismember(1264,7). ismember(1264,8). ismember(1264,11). 
ismember(1265,1). ismember(1265,5). ismember(1265,6). ismember(1265,7). ismember(1265,8). ismember(1265,11). 
ismember(1266,2). ismember(1266,5). ismember(1266,6). ismember(1266,7). ismember(1266,8). ismember(1266,11). 
ismember(1267,1). ismember(1267,2). ismember(1267,5). ismember(1267,6). ismember(1267,7). ismember(1267,8). ismember(1267,11). 
ismember(1268,3). ismember(1268,5). ismember(1268,6). ismember(1268,7). ismember(1268,8). ismember(1268,11). 
ismember(1269,1). ismember(1269,3). ismember(1269,5). ismember(1269,6). ismember(1269,7). ismember(1269,8). ismember(1269,11). 
ismember(1270,2). ismember(1270,3). ismember(1270,5). ismember(1270,6). ismember(1270,7). ismember(1270,8). ismember(1270,11). 
ismember(1271,1). ismember(1271,2). ismember(1271,3). ismember(1271,5). ismember(1271,6). ismember(1271,7). ismember(1271,8). ismember(1271,11). 
ismember(1272,4). ismember(1272,5). ismember(1272,6). ismember(1272,7). ismember(1272,8). ismember(1272,11). 
ismember(1273,1). ismember(1273,4). ismember(1273,5). ismember(1273,6). ismember(1273,7). ismember(1273,8). ismember(1273,11). 
ismember(1274,2). ismember(1274,4). ismember(1274,5). ismember(1274,6). ismember(1274,7). ismember(1274,8). ismember(1274,11). 
ismember(1275,1). ismember(1275,2). ismember(1275,4). ismember(1275,5). ismember(1275,6). ismember(1275,7). ismember(1275,8). ismember(1275,11). 
ismember(1276,3). ismember(1276,4). ismember(1276,5). ismember(1276,6). ismember(1276,7). ismember(1276,8). ismember(1276,11). 
ismember(1277,1). ismember(1277,3). ismember(1277,4). ismember(1277,5). ismember(1277,6). ismember(1277,7). ismember(1277,8). ismember(1277,11). 
ismember(1278,2). ismember(1278,3). ismember(1278,4). ismember(1278,5). ismember(1278,6). ismember(1278,7). ismember(1278,8). ismember(1278,11). 
ismember(1279,1). ismember(1279,2). ismember(1279,3). ismember(1279,4). ismember(1279,5). ismember(1279,6). ismember(1279,7). ismember(1279,8). ismember(1279,11). 
ismember(1280,9). ismember(1280,11). 
ismember(1281,1). ismember(1281,9). ismember(1281,11). 
ismember(1282,2). ismember(1282,9). ismember(1282,11). 
ismember(1283,1). ismember(1283,2). ismember(1283,9). ismember(1283,11). 
ismember(1284,3). ismember(1284,9). ismember(1284,11). 
ismember(1285,1). ismember(1285,3). ismember(1285,9). ismember(1285,11). 
ismember(1286,2). ismember(1286,3). ismember(1286,9). ismember(1286,11). 
ismember(1287,1). ismember(1287,2). ismember(1287,3). ismember(1287,9). ismember(1287,11). 
ismember(1288,4). ismember(1288,9). ismember(1288,11). 
ismember(1289,1). ismember(1289,4). ismember(1289,9). ismember(1289,11). 
ismember(1290,2). ismember(1290,4). ismember(1290,9). ismember(1290,11). 
ismember(1291,1). ismember(1291,2). ismember(1291,4). ismember(1291,9). ismember(1291,11). 
ismember(1292,3). ismember(1292,4). ismember(1292,9). ismember(1292,11). 
ismember(1293,1). ismember(1293,3). ismember(1293,4). ismember(1293,9). ismember(1293,11). 
ismember(1294,2). ismember(1294,3). ismember(1294,4). ismember(1294,9). ismember(1294,11). 
ismember(1295,1). ismember(1295,2). ismember(1295,3). ismember(1295,4). ismember(1295,9). ismember(1295,11). 
ismember(1296,5). ismember(1296,9). ismember(1296,11). 
ismember(1297,1). ismember(1297,5). ismember(1297,9). ismember(1297,11). 
ismember(1298,2). ismember(1298,5). ismember(1298,9). ismember(1298,11). 
ismember(1299,1). ismember(1299,2). ismember(1299,5). ismember(1299,9). ismember(1299,11). 
ismember(1300,3). ismember(1300,5). ismember(1300,9). ismember(1300,11). 
ismember(1301,1). ismember(1301,3). ismember(1301,5). ismember(1301,9). ismember(1301,11). 
ismember(1302,2). ismember(1302,3). ismember(1302,5). ismember(1302,9). ismember(1302,11). 
ismember(1303,1). ismember(1303,2). ismember(1303,3). ismember(1303,5). ismember(1303,9). ismember(1303,11). 
ismember(1304,4). ismember(1304,5). ismember(1304,9). ismember(1304,11). 
ismember(1305,1). ismember(1305,4). ismember(1305,5). ismember(1305,9). ismember(1305,11). 
ismember(1306,2). ismember(1306,4). ismember(1306,5). ismember(1306,9). ismember(1306,11). 
ismember(1307,1). ismember(1307,2). ismember(1307,4). ismember(1307,5). ismember(1307,9). ismember(1307,11). 
ismember(1308,3). ismember(1308,4). ismember(1308,5). ismember(1308,9). ismember(1308,11). 
ismember(1309,1). ismember(1309,3). ismember(1309,4). ismember(1309,5). ismember(1309,9). ismember(1309,11). 
ismember(1310,2). ismember(1310,3). ismember(1310,4). ismember(1310,5). ismember(1310,9). ismember(1310,11). 
ismember(1311,1). ismember(1311,2). ismember(1311,3). ismember(1311,4). ismember(1311,5). ismember(1311,9). ismember(1311,11). 
ismember(1312,6). ismember(1312,9). ismember(1312,11). 
ismember(1313,1). ismember(1313,6). ismember(1313,9). ismember(1313,11). 
ismember(1314,2). ismember(1314,6). ismember(1314,9). ismember(1314,11). 
ismember(1315,1). ismember(1315,2). ismember(1315,6). ismember(1315,9). ismember(1315,11). 
ismember(1316,3). ismember(1316,6). ismember(1316,9). ismember(1316,11). 
ismember(1317,1). ismember(1317,3). ismember(1317,6). ismember(1317,9). ismember(1317,11). 
ismember(1318,2). ismember(1318,3). ismember(1318,6). ismember(1318,9). ismember(1318,11). 
ismember(1319,1). ismember(1319,2). ismember(1319,3). ismember(1319,6). ismember(1319,9). ismember(1319,11). 
ismember(1320,4). ismember(1320,6). ismember(1320,9). ismember(1320,11). 
ismember(1321,1). ismember(1321,4). ismember(1321,6). ismember(1321,9). ismember(1321,11). 
ismember(1322,2). ismember(1322,4). ismember(1322,6). ismember(1322,9). ismember(1322,11). 
ismember(1323,1). ismember(1323,2). ismember(1323,4). ismember(1323,6). ismember(1323,9). ismember(1323,11). 
ismember(1324,3). ismember(1324,4). ismember(1324,6). ismember(1324,9). ismember(1324,11). 
ismember(1325,1). ismember(1325,3). ismember(1325,4). ismember(1325,6). ismember(1325,9). ismember(1325,11). 
ismember(1326,2). ismember(1326,3). ismember(1326,4). ismember(1326,6). ismember(1326,9). ismember(1326,11). 
ismember(1327,1). ismember(1327,2). ismember(1327,3). ismember(1327,4). ismember(1327,6). ismember(1327,9). ismember(1327,11). 
ismember(1328,5). ismember(1328,6). ismember(1328,9). ismember(1328,11). 
ismember(1329,1). ismember(1329,5). ismember(1329,6). ismember(1329,9). ismember(1329,11). 
ismember(1330,2). ismember(1330,5). ismember(1330,6). ismember(1330,9). ismember(1330,11). 
ismember(1331,1). ismember(1331,2). ismember(1331,5). ismember(1331,6). ismember(1331,9). ismember(1331,11). 
ismember(1332,3). ismember(1332,5). ismember(1332,6). ismember(1332,9). ismember(1332,11). 
ismember(1333,1). ismember(1333,3). ismember(1333,5). ismember(1333,6). ismember(1333,9). ismember(1333,11). 
ismember(1334,2). ismember(1334,3). ismember(1334,5). ismember(1334,6). ismember(1334,9). ismember(1334,11). 
ismember(1335,1). ismember(1335,2). ismember(1335,3). ismember(1335,5). ismember(1335,6). ismember(1335,9). ismember(1335,11). 
ismember(1336,4). ismember(1336,5). ismember(1336,6). ismember(1336,9). ismember(1336,11). 
ismember(1337,1). ismember(1337,4). ismember(1337,5). ismember(1337,6). ismember(1337,9). ismember(1337,11). 
ismember(1338,2). ismember(1338,4). ismember(1338,5). ismember(1338,6). ismember(1338,9). ismember(1338,11). 
ismember(1339,1). ismember(1339,2). ismember(1339,4). ismember(1339,5). ismember(1339,6). ismember(1339,9). ismember(1339,11). 
ismember(1340,3). ismember(1340,4). ismember(1340,5). ismember(1340,6). ismember(1340,9). ismember(1340,11). 
ismember(1341,1). ismember(1341,3). ismember(1341,4). ismember(1341,5). ismember(1341,6). ismember(1341,9). ismember(1341,11). 
ismember(1342,2). ismember(1342,3). ismember(1342,4). ismember(1342,5). ismember(1342,6). ismember(1342,9). ismember(1342,11). 
ismember(1343,1). ismember(1343,2). ismember(1343,3). ismember(1343,4). ismember(1343,5). ismember(1343,6). ismember(1343,9). ismember(1343,11). 
ismember(1344,7). ismember(1344,9). ismember(1344,11). 
ismember(1345,1). ismember(1345,7). ismember(1345,9). ismember(1345,11). 
ismember(1346,2). ismember(1346,7). ismember(1346,9). ismember(1346,11). 
ismember(1347,1). ismember(1347,2). ismember(1347,7). ismember(1347,9). ismember(1347,11). 
ismember(1348,3). ismember(1348,7). ismember(1348,9). ismember(1348,11). 
ismember(1349,1). ismember(1349,3). ismember(1349,7). ismember(1349,9). ismember(1349,11). 
ismember(1350,2). ismember(1350,3). ismember(1350,7). ismember(1350,9). ismember(1350,11). 
ismember(1351,1). ismember(1351,2). ismember(1351,3). ismember(1351,7). ismember(1351,9). ismember(1351,11). 
ismember(1352,4). ismember(1352,7). ismember(1352,9). ismember(1352,11). 
ismember(1353,1). ismember(1353,4). ismember(1353,7). ismember(1353,9). ismember(1353,11). 
ismember(1354,2). ismember(1354,4). ismember(1354,7). ismember(1354,9). ismember(1354,11). 
ismember(1355,1). ismember(1355,2). ismember(1355,4). ismember(1355,7). ismember(1355,9). ismember(1355,11). 
ismember(1356,3). ismember(1356,4). ismember(1356,7). ismember(1356,9). ismember(1356,11). 
ismember(1357,1). ismember(1357,3). ismember(1357,4). ismember(1357,7). ismember(1357,9). ismember(1357,11). 
ismember(1358,2). ismember(1358,3). ismember(1358,4). ismember(1358,7). ismember(1358,9). ismember(1358,11). 
ismember(1359,1). ismember(1359,2). ismember(1359,3). ismember(1359,4). ismember(1359,7). ismember(1359,9). ismember(1359,11). 
ismember(1360,5). ismember(1360,7). ismember(1360,9). ismember(1360,11). 
ismember(1361,1). ismember(1361,5). ismember(1361,7). ismember(1361,9). ismember(1361,11). 
ismember(1362,2). ismember(1362,5). ismember(1362,7). ismember(1362,9). ismember(1362,11). 
ismember(1363,1). ismember(1363,2). ismember(1363,5). ismember(1363,7). ismember(1363,9). ismember(1363,11). 
ismember(1364,3). ismember(1364,5). ismember(1364,7). ismember(1364,9). ismember(1364,11). 
ismember(1365,1). ismember(1365,3). ismember(1365,5). ismember(1365,7). ismember(1365,9). ismember(1365,11). 
ismember(1366,2). ismember(1366,3). ismember(1366,5). ismember(1366,7). ismember(1366,9). ismember(1366,11). 
ismember(1367,1). ismember(1367,2). ismember(1367,3). ismember(1367,5). ismember(1367,7). ismember(1367,9). ismember(1367,11). 
ismember(1368,4). ismember(1368,5). ismember(1368,7). ismember(1368,9). ismember(1368,11). 
ismember(1369,1). ismember(1369,4). ismember(1369,5). ismember(1369,7). ismember(1369,9). ismember(1369,11). 
ismember(1370,2). ismember(1370,4). ismember(1370,5). ismember(1370,7). ismember(1370,9). ismember(1370,11). 
ismember(1371,1). ismember(1371,2). ismember(1371,4). ismember(1371,5). ismember(1371,7). ismember(1371,9). ismember(1371,11). 
ismember(1372,3). ismember(1372,4). ismember(1372,5). ismember(1372,7). ismember(1372,9). ismember(1372,11). 
ismember(1373,1). ismember(1373,3). ismember(1373,4). ismember(1373,5). ismember(1373,7). ismember(1373,9). ismember(1373,11). 
ismember(1374,2). ismember(1374,3). ismember(1374,4). ismember(1374,5). ismember(1374,7). ismember(1374,9). ismember(1374,11). 
ismember(1375,1). ismember(1375,2). ismember(1375,3). ismember(1375,4). ismember(1375,5). ismember(1375,7). ismember(1375,9). ismember(1375,11). 
ismember(1376,6). ismember(1376,7). ismember(1376,9). ismember(1376,11). 
ismember(1377,1). ismember(1377,6). ismember(1377,7). ismember(1377,9). ismember(1377,11). 
ismember(1378,2). ismember(1378,6). ismember(1378,7). ismember(1378,9). ismember(1378,11). 
ismember(1379,1). ismember(1379,2). ismember(1379,6). ismember(1379,7). ismember(1379,9). ismember(1379,11). 
ismember(1380,3). ismember(1380,6). ismember(1380,7). ismember(1380,9). ismember(1380,11). 
ismember(1381,1). ismember(1381,3). ismember(1381,6). ismember(1381,7). ismember(1381,9). ismember(1381,11). 
ismember(1382,2). ismember(1382,3). ismember(1382,6). ismember(1382,7). ismember(1382,9). ismember(1382,11). 
ismember(1383,1). ismember(1383,2). ismember(1383,3). ismember(1383,6). ismember(1383,7). ismember(1383,9). ismember(1383,11). 
ismember(1384,4). ismember(1384,6). ismember(1384,7). ismember(1384,9). ismember(1384,11). 
ismember(1385,1). ismember(1385,4). ismember(1385,6). ismember(1385,7). ismember(1385,9). ismember(1385,11). 
ismember(1386,2). ismember(1386,4). ismember(1386,6). ismember(1386,7). ismember(1386,9). ismember(1386,11). 
ismember(1387,1). ismember(1387,2). ismember(1387,4). ismember(1387,6). ismember(1387,7). ismember(1387,9). ismember(1387,11). 
ismember(1388,3). ismember(1388,4). ismember(1388,6). ismember(1388,7). ismember(1388,9). ismember(1388,11). 
ismember(1389,1). ismember(1389,3). ismember(1389,4). ismember(1389,6). ismember(1389,7). ismember(1389,9). ismember(1389,11). 
ismember(1390,2). ismember(1390,3). ismember(1390,4). ismember(1390,6). ismember(1390,7). ismember(1390,9). ismember(1390,11). 
ismember(1391,1). ismember(1391,2). ismember(1391,3). ismember(1391,4). ismember(1391,6). ismember(1391,7). ismember(1391,9). ismember(1391,11). 
ismember(1392,5). ismember(1392,6). ismember(1392,7). ismember(1392,9). ismember(1392,11). 
ismember(1393,1). ismember(1393,5). ismember(1393,6). ismember(1393,7). ismember(1393,9). ismember(1393,11). 
ismember(1394,2). ismember(1394,5). ismember(1394,6). ismember(1394,7). ismember(1394,9). ismember(1394,11). 
ismember(1395,1). ismember(1395,2). ismember(1395,5). ismember(1395,6). ismember(1395,7). ismember(1395,9). ismember(1395,11). 
ismember(1396,3). ismember(1396,5). ismember(1396,6). ismember(1396,7). ismember(1396,9). ismember(1396,11). 
ismember(1397,1). ismember(1397,3). ismember(1397,5). ismember(1397,6). ismember(1397,7). ismember(1397,9). ismember(1397,11). 
ismember(1398,2). ismember(1398,3). ismember(1398,5). ismember(1398,6). ismember(1398,7). ismember(1398,9). ismember(1398,11). 
ismember(1399,1). ismember(1399,2). ismember(1399,3). ismember(1399,5). ismember(1399,6). ismember(1399,7). ismember(1399,9). ismember(1399,11). 
ismember(1400,4). ismember(1400,5). ismember(1400,6). ismember(1400,7). ismember(1400,9). ismember(1400,11). 
ismember(1401,1). ismember(1401,4). ismember(1401,5). ismember(1401,6). ismember(1401,7). ismember(1401,9). ismember(1401,11). 
ismember(1402,2). ismember(1402,4). ismember(1402,5). ismember(1402,6). ismember(1402,7). ismember(1402,9). ismember(1402,11). 
ismember(1403,1). ismember(1403,2). ismember(1403,4). ismember(1403,5). ismember(1403,6). ismember(1403,7). ismember(1403,9). ismember(1403,11). 
ismember(1404,3). ismember(1404,4). ismember(1404,5). ismember(1404,6). ismember(1404,7). ismember(1404,9). ismember(1404,11). 
ismember(1405,1). ismember(1405,3). ismember(1405,4). ismember(1405,5). ismember(1405,6). ismember(1405,7). ismember(1405,9). ismember(1405,11). 
ismember(1406,2). ismember(1406,3). ismember(1406,4). ismember(1406,5). ismember(1406,6). ismember(1406,7). ismember(1406,9). ismember(1406,11). 
ismember(1407,1). ismember(1407,2). ismember(1407,3). ismember(1407,4). ismember(1407,5). ismember(1407,6). ismember(1407,7). ismember(1407,9). ismember(1407,11). 
ismember(1408,8). ismember(1408,9). ismember(1408,11). 
ismember(1409,1). ismember(1409,8). ismember(1409,9). ismember(1409,11). 
ismember(1410,2). ismember(1410,8). ismember(1410,9). ismember(1410,11). 
ismember(1411,1). ismember(1411,2). ismember(1411,8). ismember(1411,9). ismember(1411,11). 
ismember(1412,3). ismember(1412,8). ismember(1412,9). ismember(1412,11). 
ismember(1413,1). ismember(1413,3). ismember(1413,8). ismember(1413,9). ismember(1413,11). 
ismember(1414,2). ismember(1414,3). ismember(1414,8). ismember(1414,9). ismember(1414,11). 
ismember(1415,1). ismember(1415,2). ismember(1415,3). ismember(1415,8). ismember(1415,9). ismember(1415,11). 
ismember(1416,4). ismember(1416,8). ismember(1416,9). ismember(1416,11). 
ismember(1417,1). ismember(1417,4). ismember(1417,8). ismember(1417,9). ismember(1417,11). 
ismember(1418,2). ismember(1418,4). ismember(1418,8). ismember(1418,9). ismember(1418,11). 
ismember(1419,1). ismember(1419,2). ismember(1419,4). ismember(1419,8). ismember(1419,9). ismember(1419,11). 
ismember(1420,3). ismember(1420,4). ismember(1420,8). ismember(1420,9). ismember(1420,11). 
ismember(1421,1). ismember(1421,3). ismember(1421,4). ismember(1421,8). ismember(1421,9). ismember(1421,11). 
ismember(1422,2). ismember(1422,3). ismember(1422,4). ismember(1422,8). ismember(1422,9). ismember(1422,11). 
ismember(1423,1). ismember(1423,2). ismember(1423,3). ismember(1423,4). ismember(1423,8). ismember(1423,9). ismember(1423,11). 
ismember(1424,5). ismember(1424,8). ismember(1424,9). ismember(1424,11). 
ismember(1425,1). ismember(1425,5). ismember(1425,8). ismember(1425,9). ismember(1425,11). 
ismember(1426,2). ismember(1426,5). ismember(1426,8). ismember(1426,9). ismember(1426,11). 
ismember(1427,1). ismember(1427,2). ismember(1427,5). ismember(1427,8). ismember(1427,9). ismember(1427,11). 
ismember(1428,3). ismember(1428,5). ismember(1428,8). ismember(1428,9). ismember(1428,11). 
ismember(1429,1). ismember(1429,3). ismember(1429,5). ismember(1429,8). ismember(1429,9). ismember(1429,11). 
ismember(1430,2). ismember(1430,3). ismember(1430,5). ismember(1430,8). ismember(1430,9). ismember(1430,11). 
ismember(1431,1). ismember(1431,2). ismember(1431,3). ismember(1431,5). ismember(1431,8). ismember(1431,9). ismember(1431,11). 
ismember(1432,4). ismember(1432,5). ismember(1432,8). ismember(1432,9). ismember(1432,11). 
ismember(1433,1). ismember(1433,4). ismember(1433,5). ismember(1433,8). ismember(1433,9). ismember(1433,11). 
ismember(1434,2). ismember(1434,4). ismember(1434,5). ismember(1434,8). ismember(1434,9). ismember(1434,11). 
ismember(1435,1). ismember(1435,2). ismember(1435,4). ismember(1435,5). ismember(1435,8). ismember(1435,9). ismember(1435,11). 
ismember(1436,3). ismember(1436,4). ismember(1436,5). ismember(1436,8). ismember(1436,9). ismember(1436,11). 
ismember(1437,1). ismember(1437,3). ismember(1437,4). ismember(1437,5). ismember(1437,8). ismember(1437,9). ismember(1437,11). 
ismember(1438,2). ismember(1438,3). ismember(1438,4). ismember(1438,5). ismember(1438,8). ismember(1438,9). ismember(1438,11). 
ismember(1439,1). ismember(1439,2). ismember(1439,3). ismember(1439,4). ismember(1439,5). ismember(1439,8). ismember(1439,9). ismember(1439,11). 
ismember(1440,6). ismember(1440,8). ismember(1440,9). ismember(1440,11). 
ismember(1441,1). ismember(1441,6). ismember(1441,8). ismember(1441,9). ismember(1441,11). 
ismember(1442,2). ismember(1442,6). ismember(1442,8). ismember(1442,9). ismember(1442,11). 
ismember(1443,1). ismember(1443,2). ismember(1443,6). ismember(1443,8). ismember(1443,9). ismember(1443,11). 
ismember(1444,3). ismember(1444,6). ismember(1444,8). ismember(1444,9). ismember(1444,11). 
ismember(1445,1). ismember(1445,3). ismember(1445,6). ismember(1445,8). ismember(1445,9). ismember(1445,11). 
ismember(1446,2). ismember(1446,3). ismember(1446,6). ismember(1446,8). ismember(1446,9). ismember(1446,11). 
ismember(1447,1). ismember(1447,2). ismember(1447,3). ismember(1447,6). ismember(1447,8). ismember(1447,9). ismember(1447,11). 
ismember(1448,4). ismember(1448,6). ismember(1448,8). ismember(1448,9). ismember(1448,11). 
ismember(1449,1). ismember(1449,4). ismember(1449,6). ismember(1449,8). ismember(1449,9). ismember(1449,11). 
ismember(1450,2). ismember(1450,4). ismember(1450,6). ismember(1450,8). ismember(1450,9). ismember(1450,11). 
ismember(1451,1). ismember(1451,2). ismember(1451,4). ismember(1451,6). ismember(1451,8). ismember(1451,9). ismember(1451,11). 
ismember(1452,3). ismember(1452,4). ismember(1452,6). ismember(1452,8). ismember(1452,9). ismember(1452,11). 
ismember(1453,1). ismember(1453,3). ismember(1453,4). ismember(1453,6). ismember(1453,8). ismember(1453,9). ismember(1453,11). 
ismember(1454,2). ismember(1454,3). ismember(1454,4). ismember(1454,6). ismember(1454,8). ismember(1454,9). ismember(1454,11). 
ismember(1455,1). ismember(1455,2). ismember(1455,3). ismember(1455,4). ismember(1455,6). ismember(1455,8). ismember(1455,9). ismember(1455,11). 
ismember(1456,5). ismember(1456,6). ismember(1456,8). ismember(1456,9). ismember(1456,11). 
ismember(1457,1). ismember(1457,5). ismember(1457,6). ismember(1457,8). ismember(1457,9). ismember(1457,11). 
ismember(1458,2). ismember(1458,5). ismember(1458,6). ismember(1458,8). ismember(1458,9). ismember(1458,11). 
ismember(1459,1). ismember(1459,2). ismember(1459,5). ismember(1459,6). ismember(1459,8). ismember(1459,9). ismember(1459,11). 
ismember(1460,3). ismember(1460,5). ismember(1460,6). ismember(1460,8). ismember(1460,9). ismember(1460,11). 
ismember(1461,1). ismember(1461,3). ismember(1461,5). ismember(1461,6). ismember(1461,8). ismember(1461,9). ismember(1461,11). 
ismember(1462,2). ismember(1462,3). ismember(1462,5). ismember(1462,6). ismember(1462,8). ismember(1462,9). ismember(1462,11). 
ismember(1463,1). ismember(1463,2). ismember(1463,3). ismember(1463,5). ismember(1463,6). ismember(1463,8). ismember(1463,9). ismember(1463,11). 
ismember(1464,4). ismember(1464,5). ismember(1464,6). ismember(1464,8). ismember(1464,9). ismember(1464,11). 
ismember(1465,1). ismember(1465,4). ismember(1465,5). ismember(1465,6). ismember(1465,8). ismember(1465,9). ismember(1465,11). 
ismember(1466,2). ismember(1466,4). ismember(1466,5). ismember(1466,6). ismember(1466,8). ismember(1466,9). ismember(1466,11). 
ismember(1467,1). ismember(1467,2). ismember(1467,4). ismember(1467,5). ismember(1467,6). ismember(1467,8). ismember(1467,9). ismember(1467,11). 
ismember(1468,3). ismember(1468,4). ismember(1468,5). ismember(1468,6). ismember(1468,8). ismember(1468,9). ismember(1468,11). 
ismember(1469,1). ismember(1469,3). ismember(1469,4). ismember(1469,5). ismember(1469,6). ismember(1469,8). ismember(1469,9). ismember(1469,11). 
ismember(1470,2). ismember(1470,3). ismember(1470,4). ismember(1470,5). ismember(1470,6). ismember(1470,8). ismember(1470,9). ismember(1470,11). 
ismember(1471,1). ismember(1471,2). ismember(1471,3). ismember(1471,4). ismember(1471,5). ismember(1471,6). ismember(1471,8). ismember(1471,9). ismember(1471,11). 
ismember(1472,7). ismember(1472,8). ismember(1472,9). ismember(1472,11). 
ismember(1473,1). ismember(1473,7). ismember(1473,8). ismember(1473,9). ismember(1473,11). 
ismember(1474,2). ismember(1474,7). ismember(1474,8). ismember(1474,9). ismember(1474,11). 
ismember(1475,1). ismember(1475,2). ismember(1475,7). ismember(1475,8). ismember(1475,9). ismember(1475,11). 
ismember(1476,3). ismember(1476,7). ismember(1476,8). ismember(1476,9). ismember(1476,11). 
ismember(1477,1). ismember(1477,3). ismember(1477,7). ismember(1477,8). ismember(1477,9). ismember(1477,11). 
ismember(1478,2). ismember(1478,3). ismember(1478,7). ismember(1478,8). ismember(1478,9). ismember(1478,11). 
ismember(1479,1). ismember(1479,2). ismember(1479,3). ismember(1479,7). ismember(1479,8). ismember(1479,9). ismember(1479,11). 
ismember(1480,4). ismember(1480,7). ismember(1480,8). ismember(1480,9). ismember(1480,11). 
ismember(1481,1). ismember(1481,4). ismember(1481,7). ismember(1481,8). ismember(1481,9). ismember(1481,11). 
ismember(1482,2). ismember(1482,4). ismember(1482,7). ismember(1482,8). ismember(1482,9). ismember(1482,11). 
ismember(1483,1). ismember(1483,2). ismember(1483,4). ismember(1483,7). ismember(1483,8). ismember(1483,9). ismember(1483,11). 
ismember(1484,3). ismember(1484,4). ismember(1484,7). ismember(1484,8). ismember(1484,9). ismember(1484,11). 
ismember(1485,1). ismember(1485,3). ismember(1485,4). ismember(1485,7). ismember(1485,8). ismember(1485,9). ismember(1485,11). 
ismember(1486,2). ismember(1486,3). ismember(1486,4). ismember(1486,7). ismember(1486,8). ismember(1486,9). ismember(1486,11). 
ismember(1487,1). ismember(1487,2). ismember(1487,3). ismember(1487,4). ismember(1487,7). ismember(1487,8). ismember(1487,9). ismember(1487,11). 
ismember(1488,5). ismember(1488,7). ismember(1488,8). ismember(1488,9). ismember(1488,11). 
ismember(1489,1). ismember(1489,5). ismember(1489,7). ismember(1489,8). ismember(1489,9). ismember(1489,11). 
ismember(1490,2). ismember(1490,5). ismember(1490,7). ismember(1490,8). ismember(1490,9). ismember(1490,11). 
ismember(1491,1). ismember(1491,2). ismember(1491,5). ismember(1491,7). ismember(1491,8). ismember(1491,9). ismember(1491,11). 
ismember(1492,3). ismember(1492,5). ismember(1492,7). ismember(1492,8). ismember(1492,9). ismember(1492,11). 
ismember(1493,1). ismember(1493,3). ismember(1493,5). ismember(1493,7). ismember(1493,8). ismember(1493,9). ismember(1493,11). 
ismember(1494,2). ismember(1494,3). ismember(1494,5). ismember(1494,7). ismember(1494,8). ismember(1494,9). ismember(1494,11). 
ismember(1495,1). ismember(1495,2). ismember(1495,3). ismember(1495,5). ismember(1495,7). ismember(1495,8). ismember(1495,9). ismember(1495,11). 
ismember(1496,4). ismember(1496,5). ismember(1496,7). ismember(1496,8). ismember(1496,9). ismember(1496,11). 
ismember(1497,1). ismember(1497,4). ismember(1497,5). ismember(1497,7). ismember(1497,8). ismember(1497,9). ismember(1497,11). 
ismember(1498,2). ismember(1498,4). ismember(1498,5). ismember(1498,7). ismember(1498,8). ismember(1498,9). ismember(1498,11). 
ismember(1499,1). ismember(1499,2). ismember(1499,4). ismember(1499,5). ismember(1499,7). ismember(1499,8). ismember(1499,9). ismember(1499,11). 
ismember(1500,3). ismember(1500,4). ismember(1500,5). ismember(1500,7). ismember(1500,8). ismember(1500,9). ismember(1500,11). 
ismember(1501,1). ismember(1501,3). ismember(1501,4). ismember(1501,5). ismember(1501,7). ismember(1501,8). ismember(1501,9). ismember(1501,11). 
ismember(1502,2). ismember(1502,3). ismember(1502,4). ismember(1502,5). ismember(1502,7). ismember(1502,8). ismember(1502,9). ismember(1502,11). 
ismember(1503,1). ismember(1503,2). ismember(1503,3). ismember(1503,4). ismember(1503,5). ismember(1503,7). ismember(1503,8). ismember(1503,9). ismember(1503,11). 
ismember(1504,6). ismember(1504,7). ismember(1504,8). ismember(1504,9). ismember(1504,11). 
ismember(1505,1). ismember(1505,6). ismember(1505,7). ismember(1505,8). ismember(1505,9). ismember(1505,11). 
ismember(1506,2). ismember(1506,6). ismember(1506,7). ismember(1506,8). ismember(1506,9). ismember(1506,11). 
ismember(1507,1). ismember(1507,2). ismember(1507,6). ismember(1507,7). ismember(1507,8). ismember(1507,9). ismember(1507,11). 
ismember(1508,3). ismember(1508,6). ismember(1508,7). ismember(1508,8). ismember(1508,9). ismember(1508,11). 
ismember(1509,1). ismember(1509,3). ismember(1509,6). ismember(1509,7). ismember(1509,8). ismember(1509,9). ismember(1509,11). 
ismember(1510,2). ismember(1510,3). ismember(1510,6). ismember(1510,7). ismember(1510,8). ismember(1510,9). ismember(1510,11). 
ismember(1511,1). ismember(1511,2). ismember(1511,3). ismember(1511,6). ismember(1511,7). ismember(1511,8). ismember(1511,9). ismember(1511,11). 
ismember(1512,4). ismember(1512,6). ismember(1512,7). ismember(1512,8). ismember(1512,9). ismember(1512,11). 
ismember(1513,1). ismember(1513,4). ismember(1513,6). ismember(1513,7). ismember(1513,8). ismember(1513,9). ismember(1513,11). 
ismember(1514,2). ismember(1514,4). ismember(1514,6). ismember(1514,7). ismember(1514,8). ismember(1514,9). ismember(1514,11). 
ismember(1515,1). ismember(1515,2). ismember(1515,4). ismember(1515,6). ismember(1515,7). ismember(1515,8). ismember(1515,9). ismember(1515,11). 
ismember(1516,3). ismember(1516,4). ismember(1516,6). ismember(1516,7). ismember(1516,8). ismember(1516,9). ismember(1516,11). 
ismember(1517,1). ismember(1517,3). ismember(1517,4). ismember(1517,6). ismember(1517,7). ismember(1517,8). ismember(1517,9). ismember(1517,11). 
ismember(1518,2). ismember(1518,3). ismember(1518,4). ismember(1518,6). ismember(1518,7). ismember(1518,8). ismember(1518,9). ismember(1518,11). 
ismember(1519,1). ismember(1519,2). ismember(1519,3). ismember(1519,4). ismember(1519,6). ismember(1519,7). ismember(1519,8). ismember(1519,9). ismember(1519,11). 
ismember(1520,5). ismember(1520,6). ismember(1520,7). ismember(1520,8). ismember(1520,9). ismember(1520,11). 
ismember(1521,1). ismember(1521,5). ismember(1521,6). ismember(1521,7). ismember(1521,8). ismember(1521,9). ismember(1521,11). 
ismember(1522,2). ismember(1522,5). ismember(1522,6). ismember(1522,7). ismember(1522,8). ismember(1522,9). ismember(1522,11). 
ismember(1523,1). ismember(1523,2). ismember(1523,5). ismember(1523,6). ismember(1523,7). ismember(1523,8). ismember(1523,9). ismember(1523,11). 
ismember(1524,3). ismember(1524,5). ismember(1524,6). ismember(1524,7). ismember(1524,8). ismember(1524,9). ismember(1524,11). 
ismember(1525,1). ismember(1525,3). ismember(1525,5). ismember(1525,6). ismember(1525,7). ismember(1525,8). ismember(1525,9). ismember(1525,11). 
ismember(1526,2). ismember(1526,3). ismember(1526,5). ismember(1526,6). ismember(1526,7). ismember(1526,8). ismember(1526,9). ismember(1526,11). 
ismember(1527,1). ismember(1527,2). ismember(1527,3). ismember(1527,5). ismember(1527,6). ismember(1527,7). ismember(1527,8). ismember(1527,9). ismember(1527,11). 
ismember(1528,4). ismember(1528,5). ismember(1528,6). ismember(1528,7). ismember(1528,8). ismember(1528,9). ismember(1528,11). 
ismember(1529,1). ismember(1529,4). ismember(1529,5). ismember(1529,6). ismember(1529,7). ismember(1529,8). ismember(1529,9). ismember(1529,11). 
ismember(1530,2). ismember(1530,4). ismember(1530,5). ismember(1530,6). ismember(1530,7). ismember(1530,8). ismember(1530,9). ismember(1530,11). 
ismember(1531,1). ismember(1531,2). ismember(1531,4). ismember(1531,5). ismember(1531,6). ismember(1531,7). ismember(1531,8). ismember(1531,9). ismember(1531,11). 
ismember(1532,3). ismember(1532,4). ismember(1532,5). ismember(1532,6). ismember(1532,7). ismember(1532,8). ismember(1532,9). ismember(1532,11). 
ismember(1533,1). ismember(1533,3). ismember(1533,4). ismember(1533,5). ismember(1533,6). ismember(1533,7). ismember(1533,8). ismember(1533,9). ismember(1533,11). 
ismember(1534,2). ismember(1534,3). ismember(1534,4). ismember(1534,5). ismember(1534,6). ismember(1534,7). ismember(1534,8). ismember(1534,9). ismember(1534,11). 
ismember(1535,1). ismember(1535,2). ismember(1535,3). ismember(1535,4). ismember(1535,5). ismember(1535,6). ismember(1535,7). ismember(1535,8). ismember(1535,9). ismember(1535,11). 
ismember(1536,10). ismember(1536,11). 
ismember(1537,1). ismember(1537,10). ismember(1537,11). 
ismember(1538,2). ismember(1538,10). ismember(1538,11). 
ismember(1539,1). ismember(1539,2). ismember(1539,10). ismember(1539,11). 
ismember(1540,3). ismember(1540,10). ismember(1540,11). 
ismember(1541,1). ismember(1541,3). ismember(1541,10). ismember(1541,11). 
ismember(1542,2). ismember(1542,3). ismember(1542,10). ismember(1542,11). 
ismember(1543,1). ismember(1543,2). ismember(1543,3). ismember(1543,10). ismember(1543,11). 
ismember(1544,4). ismember(1544,10). ismember(1544,11). 
ismember(1545,1). ismember(1545,4). ismember(1545,10). ismember(1545,11). 
ismember(1546,2). ismember(1546,4). ismember(1546,10). ismember(1546,11). 
ismember(1547,1). ismember(1547,2). ismember(1547,4). ismember(1547,10). ismember(1547,11). 
ismember(1548,3). ismember(1548,4). ismember(1548,10). ismember(1548,11). 
ismember(1549,1). ismember(1549,3). ismember(1549,4). ismember(1549,10). ismember(1549,11). 
ismember(1550,2). ismember(1550,3). ismember(1550,4). ismember(1550,10). ismember(1550,11). 
ismember(1551,1). ismember(1551,2). ismember(1551,3). ismember(1551,4). ismember(1551,10). ismember(1551,11). 
ismember(1552,5). ismember(1552,10). ismember(1552,11). 
ismember(1553,1). ismember(1553,5). ismember(1553,10). ismember(1553,11). 
ismember(1554,2). ismember(1554,5). ismember(1554,10). ismember(1554,11). 
ismember(1555,1). ismember(1555,2). ismember(1555,5). ismember(1555,10). ismember(1555,11). 
ismember(1556,3). ismember(1556,5). ismember(1556,10). ismember(1556,11). 
ismember(1557,1). ismember(1557,3). ismember(1557,5). ismember(1557,10). ismember(1557,11). 
ismember(1558,2). ismember(1558,3). ismember(1558,5). ismember(1558,10). ismember(1558,11). 
ismember(1559,1). ismember(1559,2). ismember(1559,3). ismember(1559,5). ismember(1559,10). ismember(1559,11). 
ismember(1560,4). ismember(1560,5). ismember(1560,10). ismember(1560,11). 
ismember(1561,1). ismember(1561,4). ismember(1561,5). ismember(1561,10). ismember(1561,11). 
ismember(1562,2). ismember(1562,4). ismember(1562,5). ismember(1562,10). ismember(1562,11). 
ismember(1563,1). ismember(1563,2). ismember(1563,4). ismember(1563,5). ismember(1563,10). ismember(1563,11). 
ismember(1564,3). ismember(1564,4). ismember(1564,5). ismember(1564,10). ismember(1564,11). 
ismember(1565,1). ismember(1565,3). ismember(1565,4). ismember(1565,5). ismember(1565,10). ismember(1565,11). 
ismember(1566,2). ismember(1566,3). ismember(1566,4). ismember(1566,5). ismember(1566,10). ismember(1566,11). 
ismember(1567,1). ismember(1567,2). ismember(1567,3). ismember(1567,4). ismember(1567,5). ismember(1567,10). ismember(1567,11). 
ismember(1568,6). ismember(1568,10). ismember(1568,11). 
ismember(1569,1). ismember(1569,6). ismember(1569,10). ismember(1569,11). 
ismember(1570,2). ismember(1570,6). ismember(1570,10). ismember(1570,11). 
ismember(1571,1). ismember(1571,2). ismember(1571,6). ismember(1571,10). ismember(1571,11). 
ismember(1572,3). ismember(1572,6). ismember(1572,10). ismember(1572,11). 
ismember(1573,1). ismember(1573,3). ismember(1573,6). ismember(1573,10). ismember(1573,11). 
ismember(1574,2). ismember(1574,3). ismember(1574,6). ismember(1574,10). ismember(1574,11). 
ismember(1575,1). ismember(1575,2). ismember(1575,3). ismember(1575,6). ismember(1575,10). ismember(1575,11). 
ismember(1576,4). ismember(1576,6). ismember(1576,10). ismember(1576,11). 
ismember(1577,1). ismember(1577,4). ismember(1577,6). ismember(1577,10). ismember(1577,11). 
ismember(1578,2). ismember(1578,4). ismember(1578,6). ismember(1578,10). ismember(1578,11). 
ismember(1579,1). ismember(1579,2). ismember(1579,4). ismember(1579,6). ismember(1579,10). ismember(1579,11). 
ismember(1580,3). ismember(1580,4). ismember(1580,6). ismember(1580,10). ismember(1580,11). 
ismember(1581,1). ismember(1581,3). ismember(1581,4). ismember(1581,6). ismember(1581,10). ismember(1581,11). 
ismember(1582,2). ismember(1582,3). ismember(1582,4). ismember(1582,6). ismember(1582,10). ismember(1582,11). 
ismember(1583,1). ismember(1583,2). ismember(1583,3). ismember(1583,4). ismember(1583,6). ismember(1583,10). ismember(1583,11). 
ismember(1584,5). ismember(1584,6). ismember(1584,10). ismember(1584,11). 
ismember(1585,1). ismember(1585,5). ismember(1585,6). ismember(1585,10). ismember(1585,11). 
ismember(1586,2). ismember(1586,5). ismember(1586,6). ismember(1586,10). ismember(1586,11). 
ismember(1587,1). ismember(1587,2). ismember(1587,5). ismember(1587,6). ismember(1587,10). ismember(1587,11). 
ismember(1588,3). ismember(1588,5). ismember(1588,6). ismember(1588,10). ismember(1588,11). 
ismember(1589,1). ismember(1589,3). ismember(1589,5). ismember(1589,6). ismember(1589,10). ismember(1589,11). 
ismember(1590,2). ismember(1590,3). ismember(1590,5). ismember(1590,6). ismember(1590,10). ismember(1590,11). 
ismember(1591,1). ismember(1591,2). ismember(1591,3). ismember(1591,5). ismember(1591,6). ismember(1591,10). ismember(1591,11). 
ismember(1592,4). ismember(1592,5). ismember(1592,6). ismember(1592,10). ismember(1592,11). 
ismember(1593,1). ismember(1593,4). ismember(1593,5). ismember(1593,6). ismember(1593,10). ismember(1593,11). 
ismember(1594,2). ismember(1594,4). ismember(1594,5). ismember(1594,6). ismember(1594,10). ismember(1594,11). 
ismember(1595,1). ismember(1595,2). ismember(1595,4). ismember(1595,5). ismember(1595,6). ismember(1595,10). ismember(1595,11). 
ismember(1596,3). ismember(1596,4). ismember(1596,5). ismember(1596,6). ismember(1596,10). ismember(1596,11). 
ismember(1597,1). ismember(1597,3). ismember(1597,4). ismember(1597,5). ismember(1597,6). ismember(1597,10). ismember(1597,11). 
ismember(1598,2). ismember(1598,3). ismember(1598,4). ismember(1598,5). ismember(1598,6). ismember(1598,10). ismember(1598,11). 
ismember(1599,1). ismember(1599,2). ismember(1599,3). ismember(1599,4). ismember(1599,5). ismember(1599,6). ismember(1599,10). ismember(1599,11). 
ismember(1600,7). ismember(1600,10). ismember(1600,11). 
ismember(1601,1). ismember(1601,7). ismember(1601,10). ismember(1601,11). 
ismember(1602,2). ismember(1602,7). ismember(1602,10). ismember(1602,11). 
ismember(1603,1). ismember(1603,2). ismember(1603,7). ismember(1603,10). ismember(1603,11). 
ismember(1604,3). ismember(1604,7). ismember(1604,10). ismember(1604,11). 
ismember(1605,1). ismember(1605,3). ismember(1605,7). ismember(1605,10). ismember(1605,11). 
ismember(1606,2). ismember(1606,3). ismember(1606,7). ismember(1606,10). ismember(1606,11). 
ismember(1607,1). ismember(1607,2). ismember(1607,3). ismember(1607,7). ismember(1607,10). ismember(1607,11). 
ismember(1608,4). ismember(1608,7). ismember(1608,10). ismember(1608,11). 
ismember(1609,1). ismember(1609,4). ismember(1609,7). ismember(1609,10). ismember(1609,11). 
ismember(1610,2). ismember(1610,4). ismember(1610,7). ismember(1610,10). ismember(1610,11). 
ismember(1611,1). ismember(1611,2). ismember(1611,4). ismember(1611,7). ismember(1611,10). ismember(1611,11). 
ismember(1612,3). ismember(1612,4). ismember(1612,7). ismember(1612,10). ismember(1612,11). 
ismember(1613,1). ismember(1613,3). ismember(1613,4). ismember(1613,7). ismember(1613,10). ismember(1613,11). 
ismember(1614,2). ismember(1614,3). ismember(1614,4). ismember(1614,7). ismember(1614,10). ismember(1614,11). 
ismember(1615,1). ismember(1615,2). ismember(1615,3). ismember(1615,4). ismember(1615,7). ismember(1615,10). ismember(1615,11). 
ismember(1616,5). ismember(1616,7). ismember(1616,10). ismember(1616,11). 
ismember(1617,1). ismember(1617,5). ismember(1617,7). ismember(1617,10). ismember(1617,11). 
ismember(1618,2). ismember(1618,5). ismember(1618,7). ismember(1618,10). ismember(1618,11). 
ismember(1619,1). ismember(1619,2). ismember(1619,5). ismember(1619,7). ismember(1619,10). ismember(1619,11). 
ismember(1620,3). ismember(1620,5). ismember(1620,7). ismember(1620,10). ismember(1620,11). 
ismember(1621,1). ismember(1621,3). ismember(1621,5). ismember(1621,7). ismember(1621,10). ismember(1621,11). 
ismember(1622,2). ismember(1622,3). ismember(1622,5). ismember(1622,7). ismember(1622,10). ismember(1622,11). 
ismember(1623,1). ismember(1623,2). ismember(1623,3). ismember(1623,5). ismember(1623,7). ismember(1623,10). ismember(1623,11). 
ismember(1624,4). ismember(1624,5). ismember(1624,7). ismember(1624,10). ismember(1624,11). 
ismember(1625,1). ismember(1625,4). ismember(1625,5). ismember(1625,7). ismember(1625,10). ismember(1625,11). 
ismember(1626,2). ismember(1626,4). ismember(1626,5). ismember(1626,7). ismember(1626,10). ismember(1626,11). 
ismember(1627,1). ismember(1627,2). ismember(1627,4). ismember(1627,5). ismember(1627,7). ismember(1627,10). ismember(1627,11). 
ismember(1628,3). ismember(1628,4). ismember(1628,5). ismember(1628,7). ismember(1628,10). ismember(1628,11). 
ismember(1629,1). ismember(1629,3). ismember(1629,4). ismember(1629,5). ismember(1629,7). ismember(1629,10). ismember(1629,11). 
ismember(1630,2). ismember(1630,3). ismember(1630,4). ismember(1630,5). ismember(1630,7). ismember(1630,10). ismember(1630,11). 
ismember(1631,1). ismember(1631,2). ismember(1631,3). ismember(1631,4). ismember(1631,5). ismember(1631,7). ismember(1631,10). ismember(1631,11). 
ismember(1632,6). ismember(1632,7). ismember(1632,10). ismember(1632,11). 
ismember(1633,1). ismember(1633,6). ismember(1633,7). ismember(1633,10). ismember(1633,11). 
ismember(1634,2). ismember(1634,6). ismember(1634,7). ismember(1634,10). ismember(1634,11). 
ismember(1635,1). ismember(1635,2). ismember(1635,6). ismember(1635,7). ismember(1635,10). ismember(1635,11). 
ismember(1636,3). ismember(1636,6). ismember(1636,7). ismember(1636,10). ismember(1636,11). 
ismember(1637,1). ismember(1637,3). ismember(1637,6). ismember(1637,7). ismember(1637,10). ismember(1637,11). 
ismember(1638,2). ismember(1638,3). ismember(1638,6). ismember(1638,7). ismember(1638,10). ismember(1638,11). 
ismember(1639,1). ismember(1639,2). ismember(1639,3). ismember(1639,6). ismember(1639,7). ismember(1639,10). ismember(1639,11). 
ismember(1640,4). ismember(1640,6). ismember(1640,7). ismember(1640,10). ismember(1640,11). 
ismember(1641,1). ismember(1641,4). ismember(1641,6). ismember(1641,7). ismember(1641,10). ismember(1641,11). 
ismember(1642,2). ismember(1642,4). ismember(1642,6). ismember(1642,7). ismember(1642,10). ismember(1642,11). 
ismember(1643,1). ismember(1643,2). ismember(1643,4). ismember(1643,6). ismember(1643,7). ismember(1643,10). ismember(1643,11). 
ismember(1644,3). ismember(1644,4). ismember(1644,6). ismember(1644,7). ismember(1644,10). ismember(1644,11). 
ismember(1645,1). ismember(1645,3). ismember(1645,4). ismember(1645,6). ismember(1645,7). ismember(1645,10). ismember(1645,11). 
ismember(1646,2). ismember(1646,3). ismember(1646,4). ismember(1646,6). ismember(1646,7). ismember(1646,10). ismember(1646,11). 
ismember(1647,1). ismember(1647,2). ismember(1647,3). ismember(1647,4). ismember(1647,6). ismember(1647,7). ismember(1647,10). ismember(1647,11). 
ismember(1648,5). ismember(1648,6). ismember(1648,7). ismember(1648,10). ismember(1648,11). 
ismember(1649,1). ismember(1649,5). ismember(1649,6). ismember(1649,7). ismember(1649,10). ismember(1649,11). 
ismember(1650,2). ismember(1650,5). ismember(1650,6). ismember(1650,7). ismember(1650,10). ismember(1650,11). 
ismember(1651,1). ismember(1651,2). ismember(1651,5). ismember(1651,6). ismember(1651,7). ismember(1651,10). ismember(1651,11). 
ismember(1652,3). ismember(1652,5). ismember(1652,6). ismember(1652,7). ismember(1652,10). ismember(1652,11). 
ismember(1653,1). ismember(1653,3). ismember(1653,5). ismember(1653,6). ismember(1653,7). ismember(1653,10). ismember(1653,11). 
ismember(1654,2). ismember(1654,3). ismember(1654,5). ismember(1654,6). ismember(1654,7). ismember(1654,10). ismember(1654,11). 
ismember(1655,1). ismember(1655,2). ismember(1655,3). ismember(1655,5). ismember(1655,6). ismember(1655,7). ismember(1655,10). ismember(1655,11). 
ismember(1656,4). ismember(1656,5). ismember(1656,6). ismember(1656,7). ismember(1656,10). ismember(1656,11). 
ismember(1657,1). ismember(1657,4). ismember(1657,5). ismember(1657,6). ismember(1657,7). ismember(1657,10). ismember(1657,11). 
ismember(1658,2). ismember(1658,4). ismember(1658,5). ismember(1658,6). ismember(1658,7). ismember(1658,10). ismember(1658,11). 
ismember(1659,1). ismember(1659,2). ismember(1659,4). ismember(1659,5). ismember(1659,6). ismember(1659,7). ismember(1659,10). ismember(1659,11). 
ismember(1660,3). ismember(1660,4). ismember(1660,5). ismember(1660,6). ismember(1660,7). ismember(1660,10). ismember(1660,11). 
ismember(1661,1). ismember(1661,3). ismember(1661,4). ismember(1661,5). ismember(1661,6). ismember(1661,7). ismember(1661,10). ismember(1661,11). 
ismember(1662,2). ismember(1662,3). ismember(1662,4). ismember(1662,5). ismember(1662,6). ismember(1662,7). ismember(1662,10). ismember(1662,11). 
ismember(1663,1). ismember(1663,2). ismember(1663,3). ismember(1663,4). ismember(1663,5). ismember(1663,6). ismember(1663,7). ismember(1663,10). ismember(1663,11). 
ismember(1664,8). ismember(1664,10). ismember(1664,11). 
ismember(1665,1). ismember(1665,8). ismember(1665,10). ismember(1665,11). 
ismember(1666,2). ismember(1666,8). ismember(1666,10). ismember(1666,11). 
ismember(1667,1). ismember(1667,2). ismember(1667,8). ismember(1667,10). ismember(1667,11). 
ismember(1668,3). ismember(1668,8). ismember(1668,10). ismember(1668,11). 
ismember(1669,1). ismember(1669,3). ismember(1669,8). ismember(1669,10). ismember(1669,11). 
ismember(1670,2). ismember(1670,3). ismember(1670,8). ismember(1670,10). ismember(1670,11). 
ismember(1671,1). ismember(1671,2). ismember(1671,3). ismember(1671,8). ismember(1671,10). ismember(1671,11). 
ismember(1672,4). ismember(1672,8). ismember(1672,10). ismember(1672,11). 
ismember(1673,1). ismember(1673,4). ismember(1673,8). ismember(1673,10). ismember(1673,11). 
ismember(1674,2). ismember(1674,4). ismember(1674,8). ismember(1674,10). ismember(1674,11). 
ismember(1675,1). ismember(1675,2). ismember(1675,4). ismember(1675,8). ismember(1675,10). ismember(1675,11). 
ismember(1676,3). ismember(1676,4). ismember(1676,8). ismember(1676,10). ismember(1676,11). 
ismember(1677,1). ismember(1677,3). ismember(1677,4). ismember(1677,8). ismember(1677,10). ismember(1677,11). 
ismember(1678,2). ismember(1678,3). ismember(1678,4). ismember(1678,8). ismember(1678,10). ismember(1678,11). 
ismember(1679,1). ismember(1679,2). ismember(1679,3). ismember(1679,4). ismember(1679,8). ismember(1679,10). ismember(1679,11). 
ismember(1680,5). ismember(1680,8). ismember(1680,10). ismember(1680,11). 
ismember(1681,1). ismember(1681,5). ismember(1681,8). ismember(1681,10). ismember(1681,11). 
ismember(1682,2). ismember(1682,5). ismember(1682,8). ismember(1682,10). ismember(1682,11). 
ismember(1683,1). ismember(1683,2). ismember(1683,5). ismember(1683,8). ismember(1683,10). ismember(1683,11). 
ismember(1684,3). ismember(1684,5). ismember(1684,8). ismember(1684,10). ismember(1684,11). 
ismember(1685,1). ismember(1685,3). ismember(1685,5). ismember(1685,8). ismember(1685,10). ismember(1685,11). 
ismember(1686,2). ismember(1686,3). ismember(1686,5). ismember(1686,8). ismember(1686,10). ismember(1686,11). 
ismember(1687,1). ismember(1687,2). ismember(1687,3). ismember(1687,5). ismember(1687,8). ismember(1687,10). ismember(1687,11). 
ismember(1688,4). ismember(1688,5). ismember(1688,8). ismember(1688,10). ismember(1688,11). 
ismember(1689,1). ismember(1689,4). ismember(1689,5). ismember(1689,8). ismember(1689,10). ismember(1689,11). 
ismember(1690,2). ismember(1690,4). ismember(1690,5). ismember(1690,8). ismember(1690,10). ismember(1690,11). 
ismember(1691,1). ismember(1691,2). ismember(1691,4). ismember(1691,5). ismember(1691,8). ismember(1691,10). ismember(1691,11). 
ismember(1692,3). ismember(1692,4). ismember(1692,5). ismember(1692,8). ismember(1692,10). ismember(1692,11). 
ismember(1693,1). ismember(1693,3). ismember(1693,4). ismember(1693,5). ismember(1693,8). ismember(1693,10). ismember(1693,11). 
ismember(1694,2). ismember(1694,3). ismember(1694,4). ismember(1694,5). ismember(1694,8). ismember(1694,10). ismember(1694,11). 
ismember(1695,1). ismember(1695,2). ismember(1695,3). ismember(1695,4). ismember(1695,5). ismember(1695,8). ismember(1695,10). ismember(1695,11). 
ismember(1696,6). ismember(1696,8). ismember(1696,10). ismember(1696,11). 
ismember(1697,1). ismember(1697,6). ismember(1697,8). ismember(1697,10). ismember(1697,11). 
ismember(1698,2). ismember(1698,6). ismember(1698,8). ismember(1698,10). ismember(1698,11). 
ismember(1699,1). ismember(1699,2). ismember(1699,6). ismember(1699,8). ismember(1699,10). ismember(1699,11). 
ismember(1700,3). ismember(1700,6). ismember(1700,8). ismember(1700,10). ismember(1700,11). 
ismember(1701,1). ismember(1701,3). ismember(1701,6). ismember(1701,8). ismember(1701,10). ismember(1701,11). 
ismember(1702,2). ismember(1702,3). ismember(1702,6). ismember(1702,8). ismember(1702,10). ismember(1702,11). 
ismember(1703,1). ismember(1703,2). ismember(1703,3). ismember(1703,6). ismember(1703,8). ismember(1703,10). ismember(1703,11). 
ismember(1704,4). ismember(1704,6). ismember(1704,8). ismember(1704,10). ismember(1704,11). 
ismember(1705,1). ismember(1705,4). ismember(1705,6). ismember(1705,8). ismember(1705,10). ismember(1705,11). 
ismember(1706,2). ismember(1706,4). ismember(1706,6). ismember(1706,8). ismember(1706,10). ismember(1706,11). 
ismember(1707,1). ismember(1707,2). ismember(1707,4). ismember(1707,6). ismember(1707,8). ismember(1707,10). ismember(1707,11). 
ismember(1708,3). ismember(1708,4). ismember(1708,6). ismember(1708,8). ismember(1708,10). ismember(1708,11). 
ismember(1709,1). ismember(1709,3). ismember(1709,4). ismember(1709,6). ismember(1709,8). ismember(1709,10). ismember(1709,11). 
ismember(1710,2). ismember(1710,3). ismember(1710,4). ismember(1710,6). ismember(1710,8). ismember(1710,10). ismember(1710,11). 
ismember(1711,1). ismember(1711,2). ismember(1711,3). ismember(1711,4). ismember(1711,6). ismember(1711,8). ismember(1711,10). ismember(1711,11). 
ismember(1712,5). ismember(1712,6). ismember(1712,8). ismember(1712,10). ismember(1712,11). 
ismember(1713,1). ismember(1713,5). ismember(1713,6). ismember(1713,8). ismember(1713,10). ismember(1713,11). 
ismember(1714,2). ismember(1714,5). ismember(1714,6). ismember(1714,8). ismember(1714,10). ismember(1714,11). 
ismember(1715,1). ismember(1715,2). ismember(1715,5). ismember(1715,6). ismember(1715,8). ismember(1715,10). ismember(1715,11). 
ismember(1716,3). ismember(1716,5). ismember(1716,6). ismember(1716,8). ismember(1716,10). ismember(1716,11). 
ismember(1717,1). ismember(1717,3). ismember(1717,5). ismember(1717,6). ismember(1717,8). ismember(1717,10). ismember(1717,11). 
ismember(1718,2). ismember(1718,3). ismember(1718,5). ismember(1718,6). ismember(1718,8). ismember(1718,10). ismember(1718,11). 
ismember(1719,1). ismember(1719,2). ismember(1719,3). ismember(1719,5). ismember(1719,6). ismember(1719,8). ismember(1719,10). ismember(1719,11). 
ismember(1720,4). ismember(1720,5). ismember(1720,6). ismember(1720,8). ismember(1720,10). ismember(1720,11). 
ismember(1721,1). ismember(1721,4). ismember(1721,5). ismember(1721,6). ismember(1721,8). ismember(1721,10). ismember(1721,11). 
ismember(1722,2). ismember(1722,4). ismember(1722,5). ismember(1722,6). ismember(1722,8). ismember(1722,10). ismember(1722,11). 
ismember(1723,1). ismember(1723,2). ismember(1723,4). ismember(1723,5). ismember(1723,6). ismember(1723,8). ismember(1723,10). ismember(1723,11). 
ismember(1724,3). ismember(1724,4). ismember(1724,5). ismember(1724,6). ismember(1724,8). ismember(1724,10). ismember(1724,11). 
ismember(1725,1). ismember(1725,3). ismember(1725,4). ismember(1725,5). ismember(1725,6). ismember(1725,8). ismember(1725,10). ismember(1725,11). 
ismember(1726,2). ismember(1726,3). ismember(1726,4). ismember(1726,5). ismember(1726,6). ismember(1726,8). ismember(1726,10). ismember(1726,11). 
ismember(1727,1). ismember(1727,2). ismember(1727,3). ismember(1727,4). ismember(1727,5). ismember(1727,6). ismember(1727,8). ismember(1727,10). ismember(1727,11). 
ismember(1728,7). ismember(1728,8). ismember(1728,10). ismember(1728,11). 
ismember(1729,1). ismember(1729,7). ismember(1729,8). ismember(1729,10). ismember(1729,11). 
ismember(1730,2). ismember(1730,7). ismember(1730,8). ismember(1730,10). ismember(1730,11). 
ismember(1731,1). ismember(1731,2). ismember(1731,7). ismember(1731,8). ismember(1731,10). ismember(1731,11). 
ismember(1732,3). ismember(1732,7). ismember(1732,8). ismember(1732,10). ismember(1732,11). 
ismember(1733,1). ismember(1733,3). ismember(1733,7). ismember(1733,8). ismember(1733,10). ismember(1733,11). 
ismember(1734,2). ismember(1734,3). ismember(1734,7). ismember(1734,8). ismember(1734,10). ismember(1734,11). 
ismember(1735,1). ismember(1735,2). ismember(1735,3). ismember(1735,7). ismember(1735,8). ismember(1735,10). ismember(1735,11). 
ismember(1736,4). ismember(1736,7). ismember(1736,8). ismember(1736,10). ismember(1736,11). 
ismember(1737,1). ismember(1737,4). ismember(1737,7). ismember(1737,8). ismember(1737,10). ismember(1737,11). 
ismember(1738,2). ismember(1738,4). ismember(1738,7). ismember(1738,8). ismember(1738,10). ismember(1738,11). 
ismember(1739,1). ismember(1739,2). ismember(1739,4). ismember(1739,7). ismember(1739,8). ismember(1739,10). ismember(1739,11). 
ismember(1740,3). ismember(1740,4). ismember(1740,7). ismember(1740,8). ismember(1740,10). ismember(1740,11). 
ismember(1741,1). ismember(1741,3). ismember(1741,4). ismember(1741,7). ismember(1741,8). ismember(1741,10). ismember(1741,11). 
ismember(1742,2). ismember(1742,3). ismember(1742,4). ismember(1742,7). ismember(1742,8). ismember(1742,10). ismember(1742,11). 
ismember(1743,1). ismember(1743,2). ismember(1743,3). ismember(1743,4). ismember(1743,7). ismember(1743,8). ismember(1743,10). ismember(1743,11). 
ismember(1744,5). ismember(1744,7). ismember(1744,8). ismember(1744,10). ismember(1744,11). 
ismember(1745,1). ismember(1745,5). ismember(1745,7). ismember(1745,8). ismember(1745,10). ismember(1745,11). 
ismember(1746,2). ismember(1746,5). ismember(1746,7). ismember(1746,8). ismember(1746,10). ismember(1746,11). 
ismember(1747,1). ismember(1747,2). ismember(1747,5). ismember(1747,7). ismember(1747,8). ismember(1747,10). ismember(1747,11). 
ismember(1748,3). ismember(1748,5). ismember(1748,7). ismember(1748,8). ismember(1748,10). ismember(1748,11). 
ismember(1749,1). ismember(1749,3). ismember(1749,5). ismember(1749,7). ismember(1749,8). ismember(1749,10). ismember(1749,11). 
ismember(1750,2). ismember(1750,3). ismember(1750,5). ismember(1750,7). ismember(1750,8). ismember(1750,10). ismember(1750,11). 
ismember(1751,1). ismember(1751,2). ismember(1751,3). ismember(1751,5). ismember(1751,7). ismember(1751,8). ismember(1751,10). ismember(1751,11). 
ismember(1752,4). ismember(1752,5). ismember(1752,7). ismember(1752,8). ismember(1752,10). ismember(1752,11). 
ismember(1753,1). ismember(1753,4). ismember(1753,5). ismember(1753,7). ismember(1753,8). ismember(1753,10). ismember(1753,11). 
ismember(1754,2). ismember(1754,4). ismember(1754,5). ismember(1754,7). ismember(1754,8). ismember(1754,10). ismember(1754,11). 
ismember(1755,1). ismember(1755,2). ismember(1755,4). ismember(1755,5). ismember(1755,7). ismember(1755,8). ismember(1755,10). ismember(1755,11). 
ismember(1756,3). ismember(1756,4). ismember(1756,5). ismember(1756,7). ismember(1756,8). ismember(1756,10). ismember(1756,11). 
ismember(1757,1). ismember(1757,3). ismember(1757,4). ismember(1757,5). ismember(1757,7). ismember(1757,8). ismember(1757,10). ismember(1757,11). 
ismember(1758,2). ismember(1758,3). ismember(1758,4). ismember(1758,5). ismember(1758,7). ismember(1758,8). ismember(1758,10). ismember(1758,11). 
ismember(1759,1). ismember(1759,2). ismember(1759,3). ismember(1759,4). ismember(1759,5). ismember(1759,7). ismember(1759,8). ismember(1759,10). ismember(1759,11). 
ismember(1760,6). ismember(1760,7). ismember(1760,8). ismember(1760,10). ismember(1760,11). 
ismember(1761,1). ismember(1761,6). ismember(1761,7). ismember(1761,8). ismember(1761,10). ismember(1761,11). 
ismember(1762,2). ismember(1762,6). ismember(1762,7). ismember(1762,8). ismember(1762,10). ismember(1762,11). 
ismember(1763,1). ismember(1763,2). ismember(1763,6). ismember(1763,7). ismember(1763,8). ismember(1763,10). ismember(1763,11). 
ismember(1764,3). ismember(1764,6). ismember(1764,7). ismember(1764,8). ismember(1764,10). ismember(1764,11). 
ismember(1765,1). ismember(1765,3). ismember(1765,6). ismember(1765,7). ismember(1765,8). ismember(1765,10). ismember(1765,11). 
ismember(1766,2). ismember(1766,3). ismember(1766,6). ismember(1766,7). ismember(1766,8). ismember(1766,10). ismember(1766,11). 
ismember(1767,1). ismember(1767,2). ismember(1767,3). ismember(1767,6). ismember(1767,7). ismember(1767,8). ismember(1767,10). ismember(1767,11). 
ismember(1768,4). ismember(1768,6). ismember(1768,7). ismember(1768,8). ismember(1768,10). ismember(1768,11). 
ismember(1769,1). ismember(1769,4). ismember(1769,6). ismember(1769,7). ismember(1769,8). ismember(1769,10). ismember(1769,11). 
ismember(1770,2). ismember(1770,4). ismember(1770,6). ismember(1770,7). ismember(1770,8). ismember(1770,10). ismember(1770,11). 
ismember(1771,1). ismember(1771,2). ismember(1771,4). ismember(1771,6). ismember(1771,7). ismember(1771,8). ismember(1771,10). ismember(1771,11). 
ismember(1772,3). ismember(1772,4). ismember(1772,6). ismember(1772,7). ismember(1772,8). ismember(1772,10). ismember(1772,11). 
ismember(1773,1). ismember(1773,3). ismember(1773,4). ismember(1773,6). ismember(1773,7). ismember(1773,8). ismember(1773,10). ismember(1773,11). 
ismember(1774,2). ismember(1774,3). ismember(1774,4). ismember(1774,6). ismember(1774,7). ismember(1774,8). ismember(1774,10). ismember(1774,11). 
ismember(1775,1). ismember(1775,2). ismember(1775,3). ismember(1775,4). ismember(1775,6). ismember(1775,7). ismember(1775,8). ismember(1775,10). ismember(1775,11). 
ismember(1776,5). ismember(1776,6). ismember(1776,7). ismember(1776,8). ismember(1776,10). ismember(1776,11). 
ismember(1777,1). ismember(1777,5). ismember(1777,6). ismember(1777,7). ismember(1777,8). ismember(1777,10). ismember(1777,11). 
ismember(1778,2). ismember(1778,5). ismember(1778,6). ismember(1778,7). ismember(1778,8). ismember(1778,10). ismember(1778,11). 
ismember(1779,1). ismember(1779,2). ismember(1779,5). ismember(1779,6). ismember(1779,7). ismember(1779,8). ismember(1779,10). ismember(1779,11). 
ismember(1780,3). ismember(1780,5). ismember(1780,6). ismember(1780,7). ismember(1780,8). ismember(1780,10). ismember(1780,11). 
ismember(1781,1). ismember(1781,3). ismember(1781,5). ismember(1781,6). ismember(1781,7). ismember(1781,8). ismember(1781,10). ismember(1781,11). 
ismember(1782,2). ismember(1782,3). ismember(1782,5). ismember(1782,6). ismember(1782,7). ismember(1782,8). ismember(1782,10). ismember(1782,11). 
ismember(1783,1). ismember(1783,2). ismember(1783,3). ismember(1783,5). ismember(1783,6). ismember(1783,7). ismember(1783,8). ismember(1783,10). ismember(1783,11). 
ismember(1784,4). ismember(1784,5). ismember(1784,6). ismember(1784,7). ismember(1784,8). ismember(1784,10). ismember(1784,11). 
ismember(1785,1). ismember(1785,4). ismember(1785,5). ismember(1785,6). ismember(1785,7). ismember(1785,8). ismember(1785,10). ismember(1785,11). 
ismember(1786,2). ismember(1786,4). ismember(1786,5). ismember(1786,6). ismember(1786,7). ismember(1786,8). ismember(1786,10). ismember(1786,11). 
ismember(1787,1). ismember(1787,2). ismember(1787,4). ismember(1787,5). ismember(1787,6). ismember(1787,7). ismember(1787,8). ismember(1787,10). ismember(1787,11). 
ismember(1788,3). ismember(1788,4). ismember(1788,5). ismember(1788,6). ismember(1788,7). ismember(1788,8). ismember(1788,10). ismember(1788,11). 
ismember(1789,1). ismember(1789,3). ismember(1789,4). ismember(1789,5). ismember(1789,6). ismember(1789,7). ismember(1789,8). ismember(1789,10). ismember(1789,11). 
ismember(1790,2). ismember(1790,3). ismember(1790,4). ismember(1790,5). ismember(1790,6). ismember(1790,7). ismember(1790,8). ismember(1790,10). ismember(1790,11). 
ismember(1791,1). ismember(1791,2). ismember(1791,3). ismember(1791,4). ismember(1791,5). ismember(1791,6). ismember(1791,7). ismember(1791,8). ismember(1791,10). ismember(1791,11). 
ismember(1792,9). ismember(1792,10). ismember(1792,11). 
ismember(1793,1). ismember(1793,9). ismember(1793,10). ismember(1793,11). 
ismember(1794,2). ismember(1794,9). ismember(1794,10). ismember(1794,11). 
ismember(1795,1). ismember(1795,2). ismember(1795,9). ismember(1795,10). ismember(1795,11). 
ismember(1796,3). ismember(1796,9). ismember(1796,10). ismember(1796,11). 
ismember(1797,1). ismember(1797,3). ismember(1797,9). ismember(1797,10). ismember(1797,11). 
ismember(1798,2). ismember(1798,3). ismember(1798,9). ismember(1798,10). ismember(1798,11). 
ismember(1799,1). ismember(1799,2). ismember(1799,3). ismember(1799,9). ismember(1799,10). ismember(1799,11). 
ismember(1800,4). ismember(1800,9). ismember(1800,10). ismember(1800,11). 
ismember(1801,1). ismember(1801,4). ismember(1801,9). ismember(1801,10). ismember(1801,11). 
ismember(1802,2). ismember(1802,4). ismember(1802,9). ismember(1802,10). ismember(1802,11). 
ismember(1803,1). ismember(1803,2). ismember(1803,4). ismember(1803,9). ismember(1803,10). ismember(1803,11). 
ismember(1804,3). ismember(1804,4). ismember(1804,9). ismember(1804,10). ismember(1804,11). 
ismember(1805,1). ismember(1805,3). ismember(1805,4). ismember(1805,9). ismember(1805,10). ismember(1805,11). 
ismember(1806,2). ismember(1806,3). ismember(1806,4). ismember(1806,9). ismember(1806,10). ismember(1806,11). 
ismember(1807,1). ismember(1807,2). ismember(1807,3). ismember(1807,4). ismember(1807,9). ismember(1807,10). ismember(1807,11). 
ismember(1808,5). ismember(1808,9). ismember(1808,10). ismember(1808,11). 
ismember(1809,1). ismember(1809,5). ismember(1809,9). ismember(1809,10). ismember(1809,11). 
ismember(1810,2). ismember(1810,5). ismember(1810,9). ismember(1810,10). ismember(1810,11). 
ismember(1811,1). ismember(1811,2). ismember(1811,5). ismember(1811,9). ismember(1811,10). ismember(1811,11). 
ismember(1812,3). ismember(1812,5). ismember(1812,9). ismember(1812,10). ismember(1812,11). 
ismember(1813,1). ismember(1813,3). ismember(1813,5). ismember(1813,9). ismember(1813,10). ismember(1813,11). 
ismember(1814,2). ismember(1814,3). ismember(1814,5). ismember(1814,9). ismember(1814,10). ismember(1814,11). 
ismember(1815,1). ismember(1815,2). ismember(1815,3). ismember(1815,5). ismember(1815,9). ismember(1815,10). ismember(1815,11). 
ismember(1816,4). ismember(1816,5). ismember(1816,9). ismember(1816,10). ismember(1816,11). 
ismember(1817,1). ismember(1817,4). ismember(1817,5). ismember(1817,9). ismember(1817,10). ismember(1817,11). 
ismember(1818,2). ismember(1818,4). ismember(1818,5). ismember(1818,9). ismember(1818,10). ismember(1818,11). 
ismember(1819,1). ismember(1819,2). ismember(1819,4). ismember(1819,5). ismember(1819,9). ismember(1819,10). ismember(1819,11). 
ismember(1820,3). ismember(1820,4). ismember(1820,5). ismember(1820,9). ismember(1820,10). ismember(1820,11). 
ismember(1821,1). ismember(1821,3). ismember(1821,4). ismember(1821,5). ismember(1821,9). ismember(1821,10). ismember(1821,11). 
ismember(1822,2). ismember(1822,3). ismember(1822,4). ismember(1822,5). ismember(1822,9). ismember(1822,10). ismember(1822,11). 
ismember(1823,1). ismember(1823,2). ismember(1823,3). ismember(1823,4). ismember(1823,5). ismember(1823,9). ismember(1823,10). ismember(1823,11). 
ismember(1824,6). ismember(1824,9). ismember(1824,10). ismember(1824,11). 
ismember(1825,1). ismember(1825,6). ismember(1825,9). ismember(1825,10). ismember(1825,11). 
ismember(1826,2). ismember(1826,6). ismember(1826,9). ismember(1826,10). ismember(1826,11). 
ismember(1827,1). ismember(1827,2). ismember(1827,6). ismember(1827,9). ismember(1827,10). ismember(1827,11). 
ismember(1828,3). ismember(1828,6). ismember(1828,9). ismember(1828,10). ismember(1828,11). 
ismember(1829,1). ismember(1829,3). ismember(1829,6). ismember(1829,9). ismember(1829,10). ismember(1829,11). 
ismember(1830,2). ismember(1830,3). ismember(1830,6). ismember(1830,9). ismember(1830,10). ismember(1830,11). 
ismember(1831,1). ismember(1831,2). ismember(1831,3). ismember(1831,6). ismember(1831,9). ismember(1831,10). ismember(1831,11). 
ismember(1832,4). ismember(1832,6). ismember(1832,9). ismember(1832,10). ismember(1832,11). 
ismember(1833,1). ismember(1833,4). ismember(1833,6). ismember(1833,9). ismember(1833,10). ismember(1833,11). 
ismember(1834,2). ismember(1834,4). ismember(1834,6). ismember(1834,9). ismember(1834,10). ismember(1834,11). 
ismember(1835,1). ismember(1835,2). ismember(1835,4). ismember(1835,6). ismember(1835,9). ismember(1835,10). ismember(1835,11). 
ismember(1836,3). ismember(1836,4). ismember(1836,6). ismember(1836,9). ismember(1836,10). ismember(1836,11). 
ismember(1837,1). ismember(1837,3). ismember(1837,4). ismember(1837,6). ismember(1837,9). ismember(1837,10). ismember(1837,11). 
ismember(1838,2). ismember(1838,3). ismember(1838,4). ismember(1838,6). ismember(1838,9). ismember(1838,10). ismember(1838,11). 
ismember(1839,1). ismember(1839,2). ismember(1839,3). ismember(1839,4). ismember(1839,6). ismember(1839,9). ismember(1839,10). ismember(1839,11). 
ismember(1840,5). ismember(1840,6). ismember(1840,9). ismember(1840,10). ismember(1840,11). 
ismember(1841,1). ismember(1841,5). ismember(1841,6). ismember(1841,9). ismember(1841,10). ismember(1841,11). 
ismember(1842,2). ismember(1842,5). ismember(1842,6). ismember(1842,9). ismember(1842,10). ismember(1842,11). 
ismember(1843,1). ismember(1843,2). ismember(1843,5). ismember(1843,6). ismember(1843,9). ismember(1843,10). ismember(1843,11). 
ismember(1844,3). ismember(1844,5). ismember(1844,6). ismember(1844,9). ismember(1844,10). ismember(1844,11). 
ismember(1845,1). ismember(1845,3). ismember(1845,5). ismember(1845,6). ismember(1845,9). ismember(1845,10). ismember(1845,11). 
ismember(1846,2). ismember(1846,3). ismember(1846,5). ismember(1846,6). ismember(1846,9). ismember(1846,10). ismember(1846,11). 
ismember(1847,1). ismember(1847,2). ismember(1847,3). ismember(1847,5). ismember(1847,6). ismember(1847,9). ismember(1847,10). ismember(1847,11). 
ismember(1848,4). ismember(1848,5). ismember(1848,6). ismember(1848,9). ismember(1848,10). ismember(1848,11). 
ismember(1849,1). ismember(1849,4). ismember(1849,5). ismember(1849,6). ismember(1849,9). ismember(1849,10). ismember(1849,11). 
ismember(1850,2). ismember(1850,4). ismember(1850,5). ismember(1850,6). ismember(1850,9). ismember(1850,10). ismember(1850,11). 
ismember(1851,1). ismember(1851,2). ismember(1851,4). ismember(1851,5). ismember(1851,6). ismember(1851,9). ismember(1851,10). ismember(1851,11). 
ismember(1852,3). ismember(1852,4). ismember(1852,5). ismember(1852,6). ismember(1852,9). ismember(1852,10). ismember(1852,11). 
ismember(1853,1). ismember(1853,3). ismember(1853,4). ismember(1853,5). ismember(1853,6). ismember(1853,9). ismember(1853,10). ismember(1853,11). 
ismember(1854,2). ismember(1854,3). ismember(1854,4). ismember(1854,5). ismember(1854,6). ismember(1854,9). ismember(1854,10). ismember(1854,11). 
ismember(1855,1). ismember(1855,2). ismember(1855,3). ismember(1855,4). ismember(1855,5). ismember(1855,6). ismember(1855,9). ismember(1855,10). ismember(1855,11). 
ismember(1856,7). ismember(1856,9). ismember(1856,10). ismember(1856,11). 
ismember(1857,1). ismember(1857,7). ismember(1857,9). ismember(1857,10). ismember(1857,11). 
ismember(1858,2). ismember(1858,7). ismember(1858,9). ismember(1858,10). ismember(1858,11). 
ismember(1859,1). ismember(1859,2). ismember(1859,7). ismember(1859,9). ismember(1859,10). ismember(1859,11). 
ismember(1860,3). ismember(1860,7). ismember(1860,9). ismember(1860,10). ismember(1860,11). 
ismember(1861,1). ismember(1861,3). ismember(1861,7). ismember(1861,9). ismember(1861,10). ismember(1861,11). 
ismember(1862,2). ismember(1862,3). ismember(1862,7). ismember(1862,9). ismember(1862,10). ismember(1862,11). 
ismember(1863,1). ismember(1863,2). ismember(1863,3). ismember(1863,7). ismember(1863,9). ismember(1863,10). ismember(1863,11). 
ismember(1864,4). ismember(1864,7). ismember(1864,9). ismember(1864,10). ismember(1864,11). 
ismember(1865,1). ismember(1865,4). ismember(1865,7). ismember(1865,9). ismember(1865,10). ismember(1865,11). 
ismember(1866,2). ismember(1866,4). ismember(1866,7). ismember(1866,9). ismember(1866,10). ismember(1866,11). 
ismember(1867,1). ismember(1867,2). ismember(1867,4). ismember(1867,7). ismember(1867,9). ismember(1867,10). ismember(1867,11). 
ismember(1868,3). ismember(1868,4). ismember(1868,7). ismember(1868,9). ismember(1868,10). ismember(1868,11). 
ismember(1869,1). ismember(1869,3). ismember(1869,4). ismember(1869,7). ismember(1869,9). ismember(1869,10). ismember(1869,11). 
ismember(1870,2). ismember(1870,3). ismember(1870,4). ismember(1870,7). ismember(1870,9). ismember(1870,10). ismember(1870,11). 
ismember(1871,1). ismember(1871,2). ismember(1871,3). ismember(1871,4). ismember(1871,7). ismember(1871,9). ismember(1871,10). ismember(1871,11). 
ismember(1872,5). ismember(1872,7). ismember(1872,9). ismember(1872,10). ismember(1872,11). 
ismember(1873,1). ismember(1873,5). ismember(1873,7). ismember(1873,9). ismember(1873,10). ismember(1873,11). 
ismember(1874,2). ismember(1874,5). ismember(1874,7). ismember(1874,9). ismember(1874,10). ismember(1874,11). 
ismember(1875,1). ismember(1875,2). ismember(1875,5). ismember(1875,7). ismember(1875,9). ismember(1875,10). ismember(1875,11). 
ismember(1876,3). ismember(1876,5). ismember(1876,7). ismember(1876,9). ismember(1876,10). ismember(1876,11). 
ismember(1877,1). ismember(1877,3). ismember(1877,5). ismember(1877,7). ismember(1877,9). ismember(1877,10). ismember(1877,11). 
ismember(1878,2). ismember(1878,3). ismember(1878,5). ismember(1878,7). ismember(1878,9). ismember(1878,10). ismember(1878,11). 
ismember(1879,1). ismember(1879,2). ismember(1879,3). ismember(1879,5). ismember(1879,7). ismember(1879,9). ismember(1879,10). ismember(1879,11). 
ismember(1880,4). ismember(1880,5). ismember(1880,7). ismember(1880,9). ismember(1880,10). ismember(1880,11). 
ismember(1881,1). ismember(1881,4). ismember(1881,5). ismember(1881,7). ismember(1881,9). ismember(1881,10). ismember(1881,11). 
ismember(1882,2). ismember(1882,4). ismember(1882,5). ismember(1882,7). ismember(1882,9). ismember(1882,10). ismember(1882,11). 
ismember(1883,1). ismember(1883,2). ismember(1883,4). ismember(1883,5). ismember(1883,7). ismember(1883,9). ismember(1883,10). ismember(1883,11). 
ismember(1884,3). ismember(1884,4). ismember(1884,5). ismember(1884,7). ismember(1884,9). ismember(1884,10). ismember(1884,11). 
ismember(1885,1). ismember(1885,3). ismember(1885,4). ismember(1885,5). ismember(1885,7). ismember(1885,9). ismember(1885,10). ismember(1885,11). 
ismember(1886,2). ismember(1886,3). ismember(1886,4). ismember(1886,5). ismember(1886,7). ismember(1886,9). ismember(1886,10). ismember(1886,11). 
ismember(1887,1). ismember(1887,2). ismember(1887,3). ismember(1887,4). ismember(1887,5). ismember(1887,7). ismember(1887,9). ismember(1887,10). ismember(1887,11). 
ismember(1888,6). ismember(1888,7). ismember(1888,9). ismember(1888,10). ismember(1888,11). 
ismember(1889,1). ismember(1889,6). ismember(1889,7). ismember(1889,9). ismember(1889,10). ismember(1889,11). 
ismember(1890,2). ismember(1890,6). ismember(1890,7). ismember(1890,9). ismember(1890,10). ismember(1890,11). 
ismember(1891,1). ismember(1891,2). ismember(1891,6). ismember(1891,7). ismember(1891,9). ismember(1891,10). ismember(1891,11). 
ismember(1892,3). ismember(1892,6). ismember(1892,7). ismember(1892,9). ismember(1892,10). ismember(1892,11). 
ismember(1893,1). ismember(1893,3). ismember(1893,6). ismember(1893,7). ismember(1893,9). ismember(1893,10). ismember(1893,11). 
ismember(1894,2). ismember(1894,3). ismember(1894,6). ismember(1894,7). ismember(1894,9). ismember(1894,10). ismember(1894,11). 
ismember(1895,1). ismember(1895,2). ismember(1895,3). ismember(1895,6). ismember(1895,7). ismember(1895,9). ismember(1895,10). ismember(1895,11). 
ismember(1896,4). ismember(1896,6). ismember(1896,7). ismember(1896,9). ismember(1896,10). ismember(1896,11). 
ismember(1897,1). ismember(1897,4). ismember(1897,6). ismember(1897,7). ismember(1897,9). ismember(1897,10). ismember(1897,11). 
ismember(1898,2). ismember(1898,4). ismember(1898,6). ismember(1898,7). ismember(1898,9). ismember(1898,10). ismember(1898,11). 
ismember(1899,1). ismember(1899,2). ismember(1899,4). ismember(1899,6). ismember(1899,7). ismember(1899,9). ismember(1899,10). ismember(1899,11). 
ismember(1900,3). ismember(1900,4). ismember(1900,6). ismember(1900,7). ismember(1900,9). ismember(1900,10). ismember(1900,11). 
ismember(1901,1). ismember(1901,3). ismember(1901,4). ismember(1901,6). ismember(1901,7). ismember(1901,9). ismember(1901,10). ismember(1901,11). 
ismember(1902,2). ismember(1902,3). ismember(1902,4). ismember(1902,6). ismember(1902,7). ismember(1902,9). ismember(1902,10). ismember(1902,11). 
ismember(1903,1). ismember(1903,2). ismember(1903,3). ismember(1903,4). ismember(1903,6). ismember(1903,7). ismember(1903,9). ismember(1903,10). ismember(1903,11). 
ismember(1904,5). ismember(1904,6). ismember(1904,7). ismember(1904,9). ismember(1904,10). ismember(1904,11). 
ismember(1905,1). ismember(1905,5). ismember(1905,6). ismember(1905,7). ismember(1905,9). ismember(1905,10). ismember(1905,11). 
ismember(1906,2). ismember(1906,5). ismember(1906,6). ismember(1906,7). ismember(1906,9). ismember(1906,10). ismember(1906,11). 
ismember(1907,1). ismember(1907,2). ismember(1907,5). ismember(1907,6). ismember(1907,7). ismember(1907,9). ismember(1907,10). ismember(1907,11). 
ismember(1908,3). ismember(1908,5). ismember(1908,6). ismember(1908,7). ismember(1908,9). ismember(1908,10). ismember(1908,11). 
ismember(1909,1). ismember(1909,3). ismember(1909,5). ismember(1909,6). ismember(1909,7). ismember(1909,9). ismember(1909,10). ismember(1909,11). 
ismember(1910,2). ismember(1910,3). ismember(1910,5). ismember(1910,6). ismember(1910,7). ismember(1910,9). ismember(1910,10). ismember(1910,11). 
ismember(1911,1). ismember(1911,2). ismember(1911,3). ismember(1911,5). ismember(1911,6). ismember(1911,7). ismember(1911,9). ismember(1911,10). ismember(1911,11). 
ismember(1912,4). ismember(1912,5). ismember(1912,6). ismember(1912,7). ismember(1912,9). ismember(1912,10). ismember(1912,11). 
ismember(1913,1). ismember(1913,4). ismember(1913,5). ismember(1913,6). ismember(1913,7). ismember(1913,9). ismember(1913,10). ismember(1913,11). 
ismember(1914,2). ismember(1914,4). ismember(1914,5). ismember(1914,6). ismember(1914,7). ismember(1914,9). ismember(1914,10). ismember(1914,11). 
ismember(1915,1). ismember(1915,2). ismember(1915,4). ismember(1915,5). ismember(1915,6). ismember(1915,7). ismember(1915,9). ismember(1915,10). ismember(1915,11). 
ismember(1916,3). ismember(1916,4). ismember(1916,5). ismember(1916,6). ismember(1916,7). ismember(1916,9). ismember(1916,10). ismember(1916,11). 
ismember(1917,1). ismember(1917,3). ismember(1917,4). ismember(1917,5). ismember(1917,6). ismember(1917,7). ismember(1917,9). ismember(1917,10). ismember(1917,11). 
ismember(1918,2). ismember(1918,3). ismember(1918,4). ismember(1918,5). ismember(1918,6). ismember(1918,7). ismember(1918,9). ismember(1918,10). ismember(1918,11). 
ismember(1919,1). ismember(1919,2). ismember(1919,3). ismember(1919,4). ismember(1919,5). ismember(1919,6). ismember(1919,7). ismember(1919,9). ismember(1919,10). ismember(1919,11). 
ismember(1920,8). ismember(1920,9). ismember(1920,10). ismember(1920,11). 
ismember(1921,1). ismember(1921,8). ismember(1921,9). ismember(1921,10). ismember(1921,11). 
ismember(1922,2). ismember(1922,8). ismember(1922,9). ismember(1922,10). ismember(1922,11). 
ismember(1923,1). ismember(1923,2). ismember(1923,8). ismember(1923,9). ismember(1923,10). ismember(1923,11). 
ismember(1924,3). ismember(1924,8). ismember(1924,9). ismember(1924,10). ismember(1924,11). 
ismember(1925,1). ismember(1925,3). ismember(1925,8). ismember(1925,9). ismember(1925,10). ismember(1925,11). 
ismember(1926,2). ismember(1926,3). ismember(1926,8). ismember(1926,9). ismember(1926,10). ismember(1926,11). 
ismember(1927,1). ismember(1927,2). ismember(1927,3). ismember(1927,8). ismember(1927,9). ismember(1927,10). ismember(1927,11). 
ismember(1928,4). ismember(1928,8). ismember(1928,9). ismember(1928,10). ismember(1928,11). 
ismember(1929,1). ismember(1929,4). ismember(1929,8). ismember(1929,9). ismember(1929,10). ismember(1929,11). 
ismember(1930,2). ismember(1930,4). ismember(1930,8). ismember(1930,9). ismember(1930,10). ismember(1930,11). 
ismember(1931,1). ismember(1931,2). ismember(1931,4). ismember(1931,8). ismember(1931,9). ismember(1931,10). ismember(1931,11). 
ismember(1932,3). ismember(1932,4). ismember(1932,8). ismember(1932,9). ismember(1932,10). ismember(1932,11). 
ismember(1933,1). ismember(1933,3). ismember(1933,4). ismember(1933,8). ismember(1933,9). ismember(1933,10). ismember(1933,11). 
ismember(1934,2). ismember(1934,3). ismember(1934,4). ismember(1934,8). ismember(1934,9). ismember(1934,10). ismember(1934,11). 
ismember(1935,1). ismember(1935,2). ismember(1935,3). ismember(1935,4). ismember(1935,8). ismember(1935,9). ismember(1935,10). ismember(1935,11). 
ismember(1936,5). ismember(1936,8). ismember(1936,9). ismember(1936,10). ismember(1936,11). 
ismember(1937,1). ismember(1937,5). ismember(1937,8). ismember(1937,9). ismember(1937,10). ismember(1937,11). 
ismember(1938,2). ismember(1938,5). ismember(1938,8). ismember(1938,9). ismember(1938,10). ismember(1938,11). 
ismember(1939,1). ismember(1939,2). ismember(1939,5). ismember(1939,8). ismember(1939,9). ismember(1939,10). ismember(1939,11). 
ismember(1940,3). ismember(1940,5). ismember(1940,8). ismember(1940,9). ismember(1940,10). ismember(1940,11). 
ismember(1941,1). ismember(1941,3). ismember(1941,5). ismember(1941,8). ismember(1941,9). ismember(1941,10). ismember(1941,11). 
ismember(1942,2). ismember(1942,3). ismember(1942,5). ismember(1942,8). ismember(1942,9). ismember(1942,10). ismember(1942,11). 
ismember(1943,1). ismember(1943,2). ismember(1943,3). ismember(1943,5). ismember(1943,8). ismember(1943,9). ismember(1943,10). ismember(1943,11). 
ismember(1944,4). ismember(1944,5). ismember(1944,8). ismember(1944,9). ismember(1944,10). ismember(1944,11). 
ismember(1945,1). ismember(1945,4). ismember(1945,5). ismember(1945,8). ismember(1945,9). ismember(1945,10). ismember(1945,11). 
ismember(1946,2). ismember(1946,4). ismember(1946,5). ismember(1946,8). ismember(1946,9). ismember(1946,10). ismember(1946,11). 
ismember(1947,1). ismember(1947,2). ismember(1947,4). ismember(1947,5). ismember(1947,8). ismember(1947,9). ismember(1947,10). ismember(1947,11). 
ismember(1948,3). ismember(1948,4). ismember(1948,5). ismember(1948,8). ismember(1948,9). ismember(1948,10). ismember(1948,11). 
ismember(1949,1). ismember(1949,3). ismember(1949,4). ismember(1949,5). ismember(1949,8). ismember(1949,9). ismember(1949,10). ismember(1949,11). 
ismember(1950,2). ismember(1950,3). ismember(1950,4). ismember(1950,5). ismember(1950,8). ismember(1950,9). ismember(1950,10). ismember(1950,11). 
ismember(1951,1). ismember(1951,2). ismember(1951,3). ismember(1951,4). ismember(1951,5). ismember(1951,8). ismember(1951,9). ismember(1951,10). ismember(1951,11). 
ismember(1952,6). ismember(1952,8). ismember(1952,9). ismember(1952,10). ismember(1952,11). 
ismember(1953,1). ismember(1953,6). ismember(1953,8). ismember(1953,9). ismember(1953,10). ismember(1953,11). 
ismember(1954,2). ismember(1954,6). ismember(1954,8). ismember(1954,9). ismember(1954,10). ismember(1954,11). 
ismember(1955,1). ismember(1955,2). ismember(1955,6). ismember(1955,8). ismember(1955,9). ismember(1955,10). ismember(1955,11). 
ismember(1956,3). ismember(1956,6). ismember(1956,8). ismember(1956,9). ismember(1956,10). ismember(1956,11). 
ismember(1957,1). ismember(1957,3). ismember(1957,6). ismember(1957,8). ismember(1957,9). ismember(1957,10). ismember(1957,11). 
ismember(1958,2). ismember(1958,3). ismember(1958,6). ismember(1958,8). ismember(1958,9). ismember(1958,10). ismember(1958,11). 
ismember(1959,1). ismember(1959,2). ismember(1959,3). ismember(1959,6). ismember(1959,8). ismember(1959,9). ismember(1959,10). ismember(1959,11). 
ismember(1960,4). ismember(1960,6). ismember(1960,8). ismember(1960,9). ismember(1960,10). ismember(1960,11). 
ismember(1961,1). ismember(1961,4). ismember(1961,6). ismember(1961,8). ismember(1961,9). ismember(1961,10). ismember(1961,11). 
ismember(1962,2). ismember(1962,4). ismember(1962,6). ismember(1962,8). ismember(1962,9). ismember(1962,10). ismember(1962,11). 
ismember(1963,1). ismember(1963,2). ismember(1963,4). ismember(1963,6). ismember(1963,8). ismember(1963,9). ismember(1963,10). ismember(1963,11). 
ismember(1964,3). ismember(1964,4). ismember(1964,6). ismember(1964,8). ismember(1964,9). ismember(1964,10). ismember(1964,11). 
ismember(1965,1). ismember(1965,3). ismember(1965,4). ismember(1965,6). ismember(1965,8). ismember(1965,9). ismember(1965,10). ismember(1965,11). 
ismember(1966,2). ismember(1966,3). ismember(1966,4). ismember(1966,6). ismember(1966,8). ismember(1966,9). ismember(1966,10). ismember(1966,11). 
ismember(1967,1). ismember(1967,2). ismember(1967,3). ismember(1967,4). ismember(1967,6). ismember(1967,8). ismember(1967,9). ismember(1967,10). ismember(1967,11). 
ismember(1968,5). ismember(1968,6). ismember(1968,8). ismember(1968,9). ismember(1968,10). ismember(1968,11). 
ismember(1969,1). ismember(1969,5). ismember(1969,6). ismember(1969,8). ismember(1969,9). ismember(1969,10). ismember(1969,11). 
ismember(1970,2). ismember(1970,5). ismember(1970,6). ismember(1970,8). ismember(1970,9). ismember(1970,10). ismember(1970,11). 
ismember(1971,1). ismember(1971,2). ismember(1971,5). ismember(1971,6). ismember(1971,8). ismember(1971,9). ismember(1971,10). ismember(1971,11). 
ismember(1972,3). ismember(1972,5). ismember(1972,6). ismember(1972,8). ismember(1972,9). ismember(1972,10). ismember(1972,11). 
ismember(1973,1). ismember(1973,3). ismember(1973,5). ismember(1973,6). ismember(1973,8). ismember(1973,9). ismember(1973,10). ismember(1973,11). 
ismember(1974,2). ismember(1974,3). ismember(1974,5). ismember(1974,6). ismember(1974,8). ismember(1974,9). ismember(1974,10). ismember(1974,11). 
ismember(1975,1). ismember(1975,2). ismember(1975,3). ismember(1975,5). ismember(1975,6). ismember(1975,8). ismember(1975,9). ismember(1975,10). ismember(1975,11). 
ismember(1976,4). ismember(1976,5). ismember(1976,6). ismember(1976,8). ismember(1976,9). ismember(1976,10). ismember(1976,11). 
ismember(1977,1). ismember(1977,4). ismember(1977,5). ismember(1977,6). ismember(1977,8). ismember(1977,9). ismember(1977,10). ismember(1977,11). 
ismember(1978,2). ismember(1978,4). ismember(1978,5). ismember(1978,6). ismember(1978,8). ismember(1978,9). ismember(1978,10). ismember(1978,11). 
ismember(1979,1). ismember(1979,2). ismember(1979,4). ismember(1979,5). ismember(1979,6). ismember(1979,8). ismember(1979,9). ismember(1979,10). ismember(1979,11). 
ismember(1980,3). ismember(1980,4). ismember(1980,5). ismember(1980,6). ismember(1980,8). ismember(1980,9). ismember(1980,10). ismember(1980,11). 
ismember(1981,1). ismember(1981,3). ismember(1981,4). ismember(1981,5). ismember(1981,6). ismember(1981,8). ismember(1981,9). ismember(1981,10). ismember(1981,11). 
ismember(1982,2). ismember(1982,3). ismember(1982,4). ismember(1982,5). ismember(1982,6). ismember(1982,8). ismember(1982,9). ismember(1982,10). ismember(1982,11). 
ismember(1983,1). ismember(1983,2). ismember(1983,3). ismember(1983,4). ismember(1983,5). ismember(1983,6). ismember(1983,8). ismember(1983,9). ismember(1983,10). ismember(1983,11). 
ismember(1984,7). ismember(1984,8). ismember(1984,9). ismember(1984,10). ismember(1984,11). 
ismember(1985,1). ismember(1985,7). ismember(1985,8). ismember(1985,9). ismember(1985,10). ismember(1985,11). 
ismember(1986,2). ismember(1986,7). ismember(1986,8). ismember(1986,9). ismember(1986,10). ismember(1986,11). 
ismember(1987,1). ismember(1987,2). ismember(1987,7). ismember(1987,8). ismember(1987,9). ismember(1987,10). ismember(1987,11). 
ismember(1988,3). ismember(1988,7). ismember(1988,8). ismember(1988,9). ismember(1988,10). ismember(1988,11). 
ismember(1989,1). ismember(1989,3). ismember(1989,7). ismember(1989,8). ismember(1989,9). ismember(1989,10). ismember(1989,11). 
ismember(1990,2). ismember(1990,3). ismember(1990,7). ismember(1990,8). ismember(1990,9). ismember(1990,10). ismember(1990,11). 
ismember(1991,1). ismember(1991,2). ismember(1991,3). ismember(1991,7). ismember(1991,8). ismember(1991,9). ismember(1991,10). ismember(1991,11). 
ismember(1992,4). ismember(1992,7). ismember(1992,8). ismember(1992,9). ismember(1992,10). ismember(1992,11). 
ismember(1993,1). ismember(1993,4). ismember(1993,7). ismember(1993,8). ismember(1993,9). ismember(1993,10). ismember(1993,11). 
ismember(1994,2). ismember(1994,4). ismember(1994,7). ismember(1994,8). ismember(1994,9). ismember(1994,10). ismember(1994,11). 
ismember(1995,1). ismember(1995,2). ismember(1995,4). ismember(1995,7). ismember(1995,8). ismember(1995,9). ismember(1995,10). ismember(1995,11). 
ismember(1996,3). ismember(1996,4). ismember(1996,7). ismember(1996,8). ismember(1996,9). ismember(1996,10). ismember(1996,11). 
ismember(1997,1). ismember(1997,3). ismember(1997,4). ismember(1997,7). ismember(1997,8). ismember(1997,9). ismember(1997,10). ismember(1997,11). 
ismember(1998,2). ismember(1998,3). ismember(1998,4). ismember(1998,7). ismember(1998,8). ismember(1998,9). ismember(1998,10). ismember(1998,11). 
ismember(1999,1). ismember(1999,2). ismember(1999,3). ismember(1999,4). ismember(1999,7). ismember(1999,8). ismember(1999,9). ismember(1999,10). ismember(1999,11). 
ismember(2000,5). ismember(2000,7). ismember(2000,8). ismember(2000,9). ismember(2000,10). ismember(2000,11). 
ismember(2001,1). ismember(2001,5). ismember(2001,7). ismember(2001,8). ismember(2001,9). ismember(2001,10). ismember(2001,11). 
ismember(2002,2). ismember(2002,5). ismember(2002,7). ismember(2002,8). ismember(2002,9). ismember(2002,10). ismember(2002,11). 
ismember(2003,1). ismember(2003,2). ismember(2003,5). ismember(2003,7). ismember(2003,8). ismember(2003,9). ismember(2003,10). ismember(2003,11). 
ismember(2004,3). ismember(2004,5). ismember(2004,7). ismember(2004,8). ismember(2004,9). ismember(2004,10). ismember(2004,11). 
ismember(2005,1). ismember(2005,3). ismember(2005,5). ismember(2005,7). ismember(2005,8). ismember(2005,9). ismember(2005,10). ismember(2005,11). 
ismember(2006,2). ismember(2006,3). ismember(2006,5). ismember(2006,7). ismember(2006,8). ismember(2006,9). ismember(2006,10). ismember(2006,11). 
ismember(2007,1). ismember(2007,2). ismember(2007,3). ismember(2007,5). ismember(2007,7). ismember(2007,8). ismember(2007,9). ismember(2007,10). ismember(2007,11). 
ismember(2008,4). ismember(2008,5). ismember(2008,7). ismember(2008,8). ismember(2008,9). ismember(2008,10). ismember(2008,11). 
ismember(2009,1). ismember(2009,4). ismember(2009,5). ismember(2009,7). ismember(2009,8). ismember(2009,9). ismember(2009,10). ismember(2009,11). 
ismember(2010,2). ismember(2010,4). ismember(2010,5). ismember(2010,7). ismember(2010,8). ismember(2010,9). ismember(2010,10). ismember(2010,11). 
ismember(2011,1). ismember(2011,2). ismember(2011,4). ismember(2011,5). ismember(2011,7). ismember(2011,8). ismember(2011,9). ismember(2011,10). ismember(2011,11). 
ismember(2012,3). ismember(2012,4). ismember(2012,5). ismember(2012,7). ismember(2012,8). ismember(2012,9). ismember(2012,10). ismember(2012,11). 
ismember(2013,1). ismember(2013,3). ismember(2013,4). ismember(2013,5). ismember(2013,7). ismember(2013,8). ismember(2013,9). ismember(2013,10). ismember(2013,11). 
ismember(2014,2). ismember(2014,3). ismember(2014,4). ismember(2014,5). ismember(2014,7). ismember(2014,8). ismember(2014,9). ismember(2014,10). ismember(2014,11). 
ismember(2015,1). ismember(2015,2). ismember(2015,3). ismember(2015,4). ismember(2015,5). ismember(2015,7). ismember(2015,8). ismember(2015,9). ismember(2015,10). ismember(2015,11). 
ismember(2016,6). ismember(2016,7). ismember(2016,8). ismember(2016,9). ismember(2016,10). ismember(2016,11). 
ismember(2017,1). ismember(2017,6). ismember(2017,7). ismember(2017,8). ismember(2017,9). ismember(2017,10). ismember(2017,11). 
ismember(2018,2). ismember(2018,6). ismember(2018,7). ismember(2018,8). ismember(2018,9). ismember(2018,10). ismember(2018,11). 
ismember(2019,1). ismember(2019,2). ismember(2019,6). ismember(2019,7). ismember(2019,8). ismember(2019,9). ismember(2019,10). ismember(2019,11). 
ismember(2020,3). ismember(2020,6). ismember(2020,7). ismember(2020,8). ismember(2020,9). ismember(2020,10). ismember(2020,11). 
ismember(2021,1). ismember(2021,3). ismember(2021,6). ismember(2021,7). ismember(2021,8). ismember(2021,9). ismember(2021,10). ismember(2021,11). 
ismember(2022,2). ismember(2022,3). ismember(2022,6). ismember(2022,7). ismember(2022,8). ismember(2022,9). ismember(2022,10). ismember(2022,11). 
ismember(2023,1). ismember(2023,2). ismember(2023,3). ismember(2023,6). ismember(2023,7). ismember(2023,8). ismember(2023,9). ismember(2023,10). ismember(2023,11). 
ismember(2024,4). ismember(2024,6). ismember(2024,7). ismember(2024,8). ismember(2024,9). ismember(2024,10). ismember(2024,11). 
ismember(2025,1). ismember(2025,4). ismember(2025,6). ismember(2025,7). ismember(2025,8). ismember(2025,9). ismember(2025,10). ismember(2025,11). 
ismember(2026,2). ismember(2026,4). ismember(2026,6). ismember(2026,7). ismember(2026,8). ismember(2026,9). ismember(2026,10). ismember(2026,11). 
ismember(2027,1). ismember(2027,2). ismember(2027,4). ismember(2027,6). ismember(2027,7). ismember(2027,8). ismember(2027,9). ismember(2027,10). ismember(2027,11). 
ismember(2028,3). ismember(2028,4). ismember(2028,6). ismember(2028,7). ismember(2028,8). ismember(2028,9). ismember(2028,10). ismember(2028,11). 
ismember(2029,1). ismember(2029,3). ismember(2029,4). ismember(2029,6). ismember(2029,7). ismember(2029,8). ismember(2029,9). ismember(2029,10). ismember(2029,11). 
ismember(2030,2). ismember(2030,3). ismember(2030,4). ismember(2030,6). ismember(2030,7). ismember(2030,8). ismember(2030,9). ismember(2030,10). ismember(2030,11). 
ismember(2031,1). ismember(2031,2). ismember(2031,3). ismember(2031,4). ismember(2031,6). ismember(2031,7). ismember(2031,8). ismember(2031,9). ismember(2031,10). ismember(2031,11). 
ismember(2032,5). ismember(2032,6). ismember(2032,7). ismember(2032,8). ismember(2032,9). ismember(2032,10). ismember(2032,11). 
ismember(2033,1). ismember(2033,5). ismember(2033,6). ismember(2033,7). ismember(2033,8). ismember(2033,9). ismember(2033,10). ismember(2033,11). 
ismember(2034,2). ismember(2034,5). ismember(2034,6). ismember(2034,7). ismember(2034,8). ismember(2034,9). ismember(2034,10). ismember(2034,11). 
ismember(2035,1). ismember(2035,2). ismember(2035,5). ismember(2035,6). ismember(2035,7). ismember(2035,8). ismember(2035,9). ismember(2035,10). ismember(2035,11). 
ismember(2036,3). ismember(2036,5). ismember(2036,6). ismember(2036,7). ismember(2036,8). ismember(2036,9). ismember(2036,10). ismember(2036,11). 
ismember(2037,1). ismember(2037,3). ismember(2037,5). ismember(2037,6). ismember(2037,7). ismember(2037,8). ismember(2037,9). ismember(2037,10). ismember(2037,11). 
ismember(2038,2). ismember(2038,3). ismember(2038,5). ismember(2038,6). ismember(2038,7). ismember(2038,8). ismember(2038,9). ismember(2038,10). ismember(2038,11). 
ismember(2039,1). ismember(2039,2). ismember(2039,3). ismember(2039,5). ismember(2039,6). ismember(2039,7). ismember(2039,8). ismember(2039,9). ismember(2039,10). ismember(2039,11). 
ismember(2040,4). ismember(2040,5). ismember(2040,6). ismember(2040,7). ismember(2040,8). ismember(2040,9). ismember(2040,10). ismember(2040,11). 
ismember(2041,1). ismember(2041,4). ismember(2041,5). ismember(2041,6). ismember(2041,7). ismember(2041,8). ismember(2041,9). ismember(2041,10). ismember(2041,11). 
ismember(2042,2). ismember(2042,4). ismember(2042,5). ismember(2042,6). ismember(2042,7). ismember(2042,8). ismember(2042,9). ismember(2042,10). ismember(2042,11). 
ismember(2043,1). ismember(2043,2). ismember(2043,4). ismember(2043,5). ismember(2043,6). ismember(2043,7). ismember(2043,8). ismember(2043,9). ismember(2043,10). ismember(2043,11). 
ismember(2044,3). ismember(2044,4). ismember(2044,5). ismember(2044,6). ismember(2044,7). ismember(2044,8). ismember(2044,9). ismember(2044,10). ismember(2044,11). 
ismember(2045,1). ismember(2045,3). ismember(2045,4). ismember(2045,5). ismember(2045,6). ismember(2045,7). ismember(2045,8). ismember(2045,9). ismember(2045,10). ismember(2045,11). 
ismember(2046,2). ismember(2046,3). ismember(2046,4). ismember(2046,5). ismember(2046,6). ismember(2046,7). ismember(2046,8). ismember(2046,9). ismember(2046,10). ismember(2046,11). 
ismember(2047,1). ismember(2047,2). ismember(2047,3). ismember(2047,4). ismember(2047,5). ismember(2047,6). ismember(2047,7). ismember(2047,8). ismember(2047,9). ismember(2047,10). ismember(2047,11). 
ismember(2048,12). 
ismember(2049,1). ismember(2049,12). 
ismember(2050,2). ismember(2050,12). 
ismember(2051,1). ismember(2051,2). ismember(2051,12). 
ismember(2052,3). ismember(2052,12). 
ismember(2053,1). ismember(2053,3). ismember(2053,12). 
ismember(2054,2). ismember(2054,3). ismember(2054,12). 
ismember(2055,1). ismember(2055,2). ismember(2055,3). ismember(2055,12). 
ismember(2056,4). ismember(2056,12). 
ismember(2057,1). ismember(2057,4). ismember(2057,12). 
ismember(2058,2). ismember(2058,4). ismember(2058,12). 
ismember(2059,1). ismember(2059,2). ismember(2059,4). ismember(2059,12). 
ismember(2060,3). ismember(2060,4). ismember(2060,12). 
ismember(2061,1). ismember(2061,3). ismember(2061,4). ismember(2061,12). 
ismember(2062,2). ismember(2062,3). ismember(2062,4). ismember(2062,12). 
ismember(2063,1). ismember(2063,2). ismember(2063,3). ismember(2063,4). ismember(2063,12). 
ismember(2064,5). ismember(2064,12). 
ismember(2065,1). ismember(2065,5). ismember(2065,12). 
ismember(2066,2). ismember(2066,5). ismember(2066,12). 
ismember(2067,1). ismember(2067,2). ismember(2067,5). ismember(2067,12). 
ismember(2068,3). ismember(2068,5). ismember(2068,12). 
ismember(2069,1). ismember(2069,3). ismember(2069,5). ismember(2069,12). 
ismember(2070,2). ismember(2070,3). ismember(2070,5). ismember(2070,12). 
ismember(2071,1). ismember(2071,2). ismember(2071,3). ismember(2071,5). ismember(2071,12). 
ismember(2072,4). ismember(2072,5). ismember(2072,12). 
ismember(2073,1). ismember(2073,4). ismember(2073,5). ismember(2073,12). 
ismember(2074,2). ismember(2074,4). ismember(2074,5). ismember(2074,12). 
ismember(2075,1). ismember(2075,2). ismember(2075,4). ismember(2075,5). ismember(2075,12). 
ismember(2076,3). ismember(2076,4). ismember(2076,5). ismember(2076,12). 
ismember(2077,1). ismember(2077,3). ismember(2077,4). ismember(2077,5). ismember(2077,12). 
ismember(2078,2). ismember(2078,3). ismember(2078,4). ismember(2078,5). ismember(2078,12). 
ismember(2079,1). ismember(2079,2). ismember(2079,3). ismember(2079,4). ismember(2079,5). ismember(2079,12). 
ismember(2080,6). ismember(2080,12). 
ismember(2081,1). ismember(2081,6). ismember(2081,12). 
ismember(2082,2). ismember(2082,6). ismember(2082,12). 
ismember(2083,1). ismember(2083,2). ismember(2083,6). ismember(2083,12). 
ismember(2084,3). ismember(2084,6). ismember(2084,12). 
ismember(2085,1). ismember(2085,3). ismember(2085,6). ismember(2085,12). 
ismember(2086,2). ismember(2086,3). ismember(2086,6). ismember(2086,12). 
ismember(2087,1). ismember(2087,2). ismember(2087,3). ismember(2087,6). ismember(2087,12). 
ismember(2088,4). ismember(2088,6). ismember(2088,12). 
ismember(2089,1). ismember(2089,4). ismember(2089,6). ismember(2089,12). 
ismember(2090,2). ismember(2090,4). ismember(2090,6). ismember(2090,12). 
ismember(2091,1). ismember(2091,2). ismember(2091,4). ismember(2091,6). ismember(2091,12). 
ismember(2092,3). ismember(2092,4). ismember(2092,6). ismember(2092,12). 
ismember(2093,1). ismember(2093,3). ismember(2093,4). ismember(2093,6). ismember(2093,12). 
ismember(2094,2). ismember(2094,3). ismember(2094,4). ismember(2094,6). ismember(2094,12). 
ismember(2095,1). ismember(2095,2). ismember(2095,3). ismember(2095,4). ismember(2095,6). ismember(2095,12). 
ismember(2096,5). ismember(2096,6). ismember(2096,12). 
ismember(2097,1). ismember(2097,5). ismember(2097,6). ismember(2097,12). 
ismember(2098,2). ismember(2098,5). ismember(2098,6). ismember(2098,12). 
ismember(2099,1). ismember(2099,2). ismember(2099,5). ismember(2099,6). ismember(2099,12). 
ismember(2100,3). ismember(2100,5). ismember(2100,6). ismember(2100,12). 
ismember(2101,1). ismember(2101,3). ismember(2101,5). ismember(2101,6). ismember(2101,12). 
ismember(2102,2). ismember(2102,3). ismember(2102,5). ismember(2102,6). ismember(2102,12). 
ismember(2103,1). ismember(2103,2). ismember(2103,3). ismember(2103,5). ismember(2103,6). ismember(2103,12). 
ismember(2104,4). ismember(2104,5). ismember(2104,6). ismember(2104,12). 
ismember(2105,1). ismember(2105,4). ismember(2105,5). ismember(2105,6). ismember(2105,12). 
ismember(2106,2). ismember(2106,4). ismember(2106,5). ismember(2106,6). ismember(2106,12). 
ismember(2107,1). ismember(2107,2). ismember(2107,4). ismember(2107,5). ismember(2107,6). ismember(2107,12). 
ismember(2108,3). ismember(2108,4). ismember(2108,5). ismember(2108,6). ismember(2108,12). 
ismember(2109,1). ismember(2109,3). ismember(2109,4). ismember(2109,5). ismember(2109,6). ismember(2109,12). 
ismember(2110,2). ismember(2110,3). ismember(2110,4). ismember(2110,5). ismember(2110,6). ismember(2110,12). 
ismember(2111,1). ismember(2111,2). ismember(2111,3). ismember(2111,4). ismember(2111,5). ismember(2111,6). ismember(2111,12). 
ismember(2112,7). ismember(2112,12). 
ismember(2113,1). ismember(2113,7). ismember(2113,12). 
ismember(2114,2). ismember(2114,7). ismember(2114,12). 
ismember(2115,1). ismember(2115,2). ismember(2115,7). ismember(2115,12). 
ismember(2116,3). ismember(2116,7). ismember(2116,12). 
ismember(2117,1). ismember(2117,3). ismember(2117,7). ismember(2117,12). 
ismember(2118,2). ismember(2118,3). ismember(2118,7). ismember(2118,12). 
ismember(2119,1). ismember(2119,2). ismember(2119,3). ismember(2119,7). ismember(2119,12). 
ismember(2120,4). ismember(2120,7). ismember(2120,12). 
ismember(2121,1). ismember(2121,4). ismember(2121,7). ismember(2121,12). 
ismember(2122,2). ismember(2122,4). ismember(2122,7). ismember(2122,12). 
ismember(2123,1). ismember(2123,2). ismember(2123,4). ismember(2123,7). ismember(2123,12). 
ismember(2124,3). ismember(2124,4). ismember(2124,7). ismember(2124,12). 
ismember(2125,1). ismember(2125,3). ismember(2125,4). ismember(2125,7). ismember(2125,12). 
ismember(2126,2). ismember(2126,3). ismember(2126,4). ismember(2126,7). ismember(2126,12). 
ismember(2127,1). ismember(2127,2). ismember(2127,3). ismember(2127,4). ismember(2127,7). ismember(2127,12). 
ismember(2128,5). ismember(2128,7). ismember(2128,12). 
ismember(2129,1). ismember(2129,5). ismember(2129,7). ismember(2129,12). 
ismember(2130,2). ismember(2130,5). ismember(2130,7). ismember(2130,12). 
ismember(2131,1). ismember(2131,2). ismember(2131,5). ismember(2131,7). ismember(2131,12). 
ismember(2132,3). ismember(2132,5). ismember(2132,7). ismember(2132,12). 
ismember(2133,1). ismember(2133,3). ismember(2133,5). ismember(2133,7). ismember(2133,12). 
ismember(2134,2). ismember(2134,3). ismember(2134,5). ismember(2134,7). ismember(2134,12). 
ismember(2135,1). ismember(2135,2). ismember(2135,3). ismember(2135,5). ismember(2135,7). ismember(2135,12). 
ismember(2136,4). ismember(2136,5). ismember(2136,7). ismember(2136,12). 
ismember(2137,1). ismember(2137,4). ismember(2137,5). ismember(2137,7). ismember(2137,12). 
ismember(2138,2). ismember(2138,4). ismember(2138,5). ismember(2138,7). ismember(2138,12). 
ismember(2139,1). ismember(2139,2). ismember(2139,4). ismember(2139,5). ismember(2139,7). ismember(2139,12). 
ismember(2140,3). ismember(2140,4). ismember(2140,5). ismember(2140,7). ismember(2140,12). 
ismember(2141,1). ismember(2141,3). ismember(2141,4). ismember(2141,5). ismember(2141,7). ismember(2141,12). 
ismember(2142,2). ismember(2142,3). ismember(2142,4). ismember(2142,5). ismember(2142,7). ismember(2142,12). 
ismember(2143,1). ismember(2143,2). ismember(2143,3). ismember(2143,4). ismember(2143,5). ismember(2143,7). ismember(2143,12). 
ismember(2144,6). ismember(2144,7). ismember(2144,12). 
ismember(2145,1). ismember(2145,6). ismember(2145,7). ismember(2145,12). 
ismember(2146,2). ismember(2146,6). ismember(2146,7). ismember(2146,12). 
ismember(2147,1). ismember(2147,2). ismember(2147,6). ismember(2147,7). ismember(2147,12). 
ismember(2148,3). ismember(2148,6). ismember(2148,7). ismember(2148,12). 
ismember(2149,1). ismember(2149,3). ismember(2149,6). ismember(2149,7). ismember(2149,12). 
ismember(2150,2). ismember(2150,3). ismember(2150,6). ismember(2150,7). ismember(2150,12). 
ismember(2151,1). ismember(2151,2). ismember(2151,3). ismember(2151,6). ismember(2151,7). ismember(2151,12). 
ismember(2152,4). ismember(2152,6). ismember(2152,7). ismember(2152,12). 
ismember(2153,1). ismember(2153,4). ismember(2153,6). ismember(2153,7). ismember(2153,12). 
ismember(2154,2). ismember(2154,4). ismember(2154,6). ismember(2154,7). ismember(2154,12). 
ismember(2155,1). ismember(2155,2). ismember(2155,4). ismember(2155,6). ismember(2155,7). ismember(2155,12). 
ismember(2156,3). ismember(2156,4). ismember(2156,6). ismember(2156,7). ismember(2156,12). 
ismember(2157,1). ismember(2157,3). ismember(2157,4). ismember(2157,6). ismember(2157,7). ismember(2157,12). 
ismember(2158,2). ismember(2158,3). ismember(2158,4). ismember(2158,6). ismember(2158,7). ismember(2158,12). 
ismember(2159,1). ismember(2159,2). ismember(2159,3). ismember(2159,4). ismember(2159,6). ismember(2159,7). ismember(2159,12). 
ismember(2160,5). ismember(2160,6). ismember(2160,7). ismember(2160,12). 
ismember(2161,1). ismember(2161,5). ismember(2161,6). ismember(2161,7). ismember(2161,12). 
ismember(2162,2). ismember(2162,5). ismember(2162,6). ismember(2162,7). ismember(2162,12). 
ismember(2163,1). ismember(2163,2). ismember(2163,5). ismember(2163,6). ismember(2163,7). ismember(2163,12). 
ismember(2164,3). ismember(2164,5). ismember(2164,6). ismember(2164,7). ismember(2164,12). 
ismember(2165,1). ismember(2165,3). ismember(2165,5). ismember(2165,6). ismember(2165,7). ismember(2165,12). 
ismember(2166,2). ismember(2166,3). ismember(2166,5). ismember(2166,6). ismember(2166,7). ismember(2166,12). 
ismember(2167,1). ismember(2167,2). ismember(2167,3). ismember(2167,5). ismember(2167,6). ismember(2167,7). ismember(2167,12). 
ismember(2168,4). ismember(2168,5). ismember(2168,6). ismember(2168,7). ismember(2168,12). 
ismember(2169,1). ismember(2169,4). ismember(2169,5). ismember(2169,6). ismember(2169,7). ismember(2169,12). 
ismember(2170,2). ismember(2170,4). ismember(2170,5). ismember(2170,6). ismember(2170,7). ismember(2170,12). 
ismember(2171,1). ismember(2171,2). ismember(2171,4). ismember(2171,5). ismember(2171,6). ismember(2171,7). ismember(2171,12). 
ismember(2172,3). ismember(2172,4). ismember(2172,5). ismember(2172,6). ismember(2172,7). ismember(2172,12). 
ismember(2173,1). ismember(2173,3). ismember(2173,4). ismember(2173,5). ismember(2173,6). ismember(2173,7). ismember(2173,12). 
ismember(2174,2). ismember(2174,3). ismember(2174,4). ismember(2174,5). ismember(2174,6). ismember(2174,7). ismember(2174,12). 
ismember(2175,1). ismember(2175,2). ismember(2175,3). ismember(2175,4). ismember(2175,5). ismember(2175,6). ismember(2175,7). ismember(2175,12). 
ismember(2176,8). ismember(2176,12). 
ismember(2177,1). ismember(2177,8). ismember(2177,12). 
ismember(2178,2). ismember(2178,8). ismember(2178,12). 
ismember(2179,1). ismember(2179,2). ismember(2179,8). ismember(2179,12). 
ismember(2180,3). ismember(2180,8). ismember(2180,12). 
ismember(2181,1). ismember(2181,3). ismember(2181,8). ismember(2181,12). 
ismember(2182,2). ismember(2182,3). ismember(2182,8). ismember(2182,12). 
ismember(2183,1). ismember(2183,2). ismember(2183,3). ismember(2183,8). ismember(2183,12). 
ismember(2184,4). ismember(2184,8). ismember(2184,12). 
ismember(2185,1). ismember(2185,4). ismember(2185,8). ismember(2185,12). 
ismember(2186,2). ismember(2186,4). ismember(2186,8). ismember(2186,12). 
ismember(2187,1). ismember(2187,2). ismember(2187,4). ismember(2187,8). ismember(2187,12). 
ismember(2188,3). ismember(2188,4). ismember(2188,8). ismember(2188,12). 
ismember(2189,1). ismember(2189,3). ismember(2189,4). ismember(2189,8). ismember(2189,12). 
ismember(2190,2). ismember(2190,3). ismember(2190,4). ismember(2190,8). ismember(2190,12). 
ismember(2191,1). ismember(2191,2). ismember(2191,3). ismember(2191,4). ismember(2191,8). ismember(2191,12). 
ismember(2192,5). ismember(2192,8). ismember(2192,12). 
ismember(2193,1). ismember(2193,5). ismember(2193,8). ismember(2193,12). 
ismember(2194,2). ismember(2194,5). ismember(2194,8). ismember(2194,12). 
ismember(2195,1). ismember(2195,2). ismember(2195,5). ismember(2195,8). ismember(2195,12). 
ismember(2196,3). ismember(2196,5). ismember(2196,8). ismember(2196,12). 
ismember(2197,1). ismember(2197,3). ismember(2197,5). ismember(2197,8). ismember(2197,12). 
ismember(2198,2). ismember(2198,3). ismember(2198,5). ismember(2198,8). ismember(2198,12). 
ismember(2199,1). ismember(2199,2). ismember(2199,3). ismember(2199,5). ismember(2199,8). ismember(2199,12). 
ismember(2200,4). ismember(2200,5). ismember(2200,8). ismember(2200,12). 
ismember(2201,1). ismember(2201,4). ismember(2201,5). ismember(2201,8). ismember(2201,12). 
ismember(2202,2). ismember(2202,4). ismember(2202,5). ismember(2202,8). ismember(2202,12). 
ismember(2203,1). ismember(2203,2). ismember(2203,4). ismember(2203,5). ismember(2203,8). ismember(2203,12). 
ismember(2204,3). ismember(2204,4). ismember(2204,5). ismember(2204,8). ismember(2204,12). 
ismember(2205,1). ismember(2205,3). ismember(2205,4). ismember(2205,5). ismember(2205,8). ismember(2205,12). 
ismember(2206,2). ismember(2206,3). ismember(2206,4). ismember(2206,5). ismember(2206,8). ismember(2206,12). 
ismember(2207,1). ismember(2207,2). ismember(2207,3). ismember(2207,4). ismember(2207,5). ismember(2207,8). ismember(2207,12). 
ismember(2208,6). ismember(2208,8). ismember(2208,12). 
ismember(2209,1). ismember(2209,6). ismember(2209,8). ismember(2209,12). 
ismember(2210,2). ismember(2210,6). ismember(2210,8). ismember(2210,12). 
ismember(2211,1). ismember(2211,2). ismember(2211,6). ismember(2211,8). ismember(2211,12). 
ismember(2212,3). ismember(2212,6). ismember(2212,8). ismember(2212,12). 
ismember(2213,1). ismember(2213,3). ismember(2213,6). ismember(2213,8). ismember(2213,12). 
ismember(2214,2). ismember(2214,3). ismember(2214,6). ismember(2214,8). ismember(2214,12). 
ismember(2215,1). ismember(2215,2). ismember(2215,3). ismember(2215,6). ismember(2215,8). ismember(2215,12). 
ismember(2216,4). ismember(2216,6). ismember(2216,8). ismember(2216,12). 
ismember(2217,1). ismember(2217,4). ismember(2217,6). ismember(2217,8). ismember(2217,12). 
ismember(2218,2). ismember(2218,4). ismember(2218,6). ismember(2218,8). ismember(2218,12). 
ismember(2219,1). ismember(2219,2). ismember(2219,4). ismember(2219,6). ismember(2219,8). ismember(2219,12). 
ismember(2220,3). ismember(2220,4). ismember(2220,6). ismember(2220,8). ismember(2220,12). 
ismember(2221,1). ismember(2221,3). ismember(2221,4). ismember(2221,6). ismember(2221,8). ismember(2221,12). 
ismember(2222,2). ismember(2222,3). ismember(2222,4). ismember(2222,6). ismember(2222,8). ismember(2222,12). 
ismember(2223,1). ismember(2223,2). ismember(2223,3). ismember(2223,4). ismember(2223,6). ismember(2223,8). ismember(2223,12). 
ismember(2224,5). ismember(2224,6). ismember(2224,8). ismember(2224,12). 
ismember(2225,1). ismember(2225,5). ismember(2225,6). ismember(2225,8). ismember(2225,12). 
ismember(2226,2). ismember(2226,5). ismember(2226,6). ismember(2226,8). ismember(2226,12). 
ismember(2227,1). ismember(2227,2). ismember(2227,5). ismember(2227,6). ismember(2227,8). ismember(2227,12). 
ismember(2228,3). ismember(2228,5). ismember(2228,6). ismember(2228,8). ismember(2228,12). 
ismember(2229,1). ismember(2229,3). ismember(2229,5). ismember(2229,6). ismember(2229,8). ismember(2229,12). 
ismember(2230,2). ismember(2230,3). ismember(2230,5). ismember(2230,6). ismember(2230,8). ismember(2230,12). 
ismember(2231,1). ismember(2231,2). ismember(2231,3). ismember(2231,5). ismember(2231,6). ismember(2231,8). ismember(2231,12). 
ismember(2232,4). ismember(2232,5). ismember(2232,6). ismember(2232,8). ismember(2232,12). 
ismember(2233,1). ismember(2233,4). ismember(2233,5). ismember(2233,6). ismember(2233,8). ismember(2233,12). 
ismember(2234,2). ismember(2234,4). ismember(2234,5). ismember(2234,6). ismember(2234,8). ismember(2234,12). 
ismember(2235,1). ismember(2235,2). ismember(2235,4). ismember(2235,5). ismember(2235,6). ismember(2235,8). ismember(2235,12). 
ismember(2236,3). ismember(2236,4). ismember(2236,5). ismember(2236,6). ismember(2236,8). ismember(2236,12). 
ismember(2237,1). ismember(2237,3). ismember(2237,4). ismember(2237,5). ismember(2237,6). ismember(2237,8). ismember(2237,12). 
ismember(2238,2). ismember(2238,3). ismember(2238,4). ismember(2238,5). ismember(2238,6). ismember(2238,8). ismember(2238,12). 
ismember(2239,1). ismember(2239,2). ismember(2239,3). ismember(2239,4). ismember(2239,5). ismember(2239,6). ismember(2239,8). ismember(2239,12). 
ismember(2240,7). ismember(2240,8). ismember(2240,12). 
ismember(2241,1). ismember(2241,7). ismember(2241,8). ismember(2241,12). 
ismember(2242,2). ismember(2242,7). ismember(2242,8). ismember(2242,12). 
ismember(2243,1). ismember(2243,2). ismember(2243,7). ismember(2243,8). ismember(2243,12). 
ismember(2244,3). ismember(2244,7). ismember(2244,8). ismember(2244,12). 
ismember(2245,1). ismember(2245,3). ismember(2245,7). ismember(2245,8). ismember(2245,12). 
ismember(2246,2). ismember(2246,3). ismember(2246,7). ismember(2246,8). ismember(2246,12). 
ismember(2247,1). ismember(2247,2). ismember(2247,3). ismember(2247,7). ismember(2247,8). ismember(2247,12). 
ismember(2248,4). ismember(2248,7). ismember(2248,8). ismember(2248,12). 
ismember(2249,1). ismember(2249,4). ismember(2249,7). ismember(2249,8). ismember(2249,12). 
ismember(2250,2). ismember(2250,4). ismember(2250,7). ismember(2250,8). ismember(2250,12). 
ismember(2251,1). ismember(2251,2). ismember(2251,4). ismember(2251,7). ismember(2251,8). ismember(2251,12). 
ismember(2252,3). ismember(2252,4). ismember(2252,7). ismember(2252,8). ismember(2252,12). 
ismember(2253,1). ismember(2253,3). ismember(2253,4). ismember(2253,7). ismember(2253,8). ismember(2253,12). 
ismember(2254,2). ismember(2254,3). ismember(2254,4). ismember(2254,7). ismember(2254,8). ismember(2254,12). 
ismember(2255,1). ismember(2255,2). ismember(2255,3). ismember(2255,4). ismember(2255,7). ismember(2255,8). ismember(2255,12). 
ismember(2256,5). ismember(2256,7). ismember(2256,8). ismember(2256,12). 
ismember(2257,1). ismember(2257,5). ismember(2257,7). ismember(2257,8). ismember(2257,12). 
ismember(2258,2). ismember(2258,5). ismember(2258,7). ismember(2258,8). ismember(2258,12). 
ismember(2259,1). ismember(2259,2). ismember(2259,5). ismember(2259,7). ismember(2259,8). ismember(2259,12). 
ismember(2260,3). ismember(2260,5). ismember(2260,7). ismember(2260,8). ismember(2260,12). 
ismember(2261,1). ismember(2261,3). ismember(2261,5). ismember(2261,7). ismember(2261,8). ismember(2261,12). 
ismember(2262,2). ismember(2262,3). ismember(2262,5). ismember(2262,7). ismember(2262,8). ismember(2262,12). 
ismember(2263,1). ismember(2263,2). ismember(2263,3). ismember(2263,5). ismember(2263,7). ismember(2263,8). ismember(2263,12). 
ismember(2264,4). ismember(2264,5). ismember(2264,7). ismember(2264,8). ismember(2264,12). 
ismember(2265,1). ismember(2265,4). ismember(2265,5). ismember(2265,7). ismember(2265,8). ismember(2265,12). 
ismember(2266,2). ismember(2266,4). ismember(2266,5). ismember(2266,7). ismember(2266,8). ismember(2266,12). 
ismember(2267,1). ismember(2267,2). ismember(2267,4). ismember(2267,5). ismember(2267,7). ismember(2267,8). ismember(2267,12). 
ismember(2268,3). ismember(2268,4). ismember(2268,5). ismember(2268,7). ismember(2268,8). ismember(2268,12). 
ismember(2269,1). ismember(2269,3). ismember(2269,4). ismember(2269,5). ismember(2269,7). ismember(2269,8). ismember(2269,12). 
ismember(2270,2). ismember(2270,3). ismember(2270,4). ismember(2270,5). ismember(2270,7). ismember(2270,8). ismember(2270,12). 
ismember(2271,1). ismember(2271,2). ismember(2271,3). ismember(2271,4). ismember(2271,5). ismember(2271,7). ismember(2271,8). ismember(2271,12). 
ismember(2272,6). ismember(2272,7). ismember(2272,8). ismember(2272,12). 
ismember(2273,1). ismember(2273,6). ismember(2273,7). ismember(2273,8). ismember(2273,12). 
ismember(2274,2). ismember(2274,6). ismember(2274,7). ismember(2274,8). ismember(2274,12). 
ismember(2275,1). ismember(2275,2). ismember(2275,6). ismember(2275,7). ismember(2275,8). ismember(2275,12). 
ismember(2276,3). ismember(2276,6). ismember(2276,7). ismember(2276,8). ismember(2276,12). 
ismember(2277,1). ismember(2277,3). ismember(2277,6). ismember(2277,7). ismember(2277,8). ismember(2277,12). 
ismember(2278,2). ismember(2278,3). ismember(2278,6). ismember(2278,7). ismember(2278,8). ismember(2278,12). 
ismember(2279,1). ismember(2279,2). ismember(2279,3). ismember(2279,6). ismember(2279,7). ismember(2279,8). ismember(2279,12). 
ismember(2280,4). ismember(2280,6). ismember(2280,7). ismember(2280,8). ismember(2280,12). 
ismember(2281,1). ismember(2281,4). ismember(2281,6). ismember(2281,7). ismember(2281,8). ismember(2281,12). 
ismember(2282,2). ismember(2282,4). ismember(2282,6). ismember(2282,7). ismember(2282,8). ismember(2282,12). 
ismember(2283,1). ismember(2283,2). ismember(2283,4). ismember(2283,6). ismember(2283,7). ismember(2283,8). ismember(2283,12). 
ismember(2284,3). ismember(2284,4). ismember(2284,6). ismember(2284,7). ismember(2284,8). ismember(2284,12). 
ismember(2285,1). ismember(2285,3). ismember(2285,4). ismember(2285,6). ismember(2285,7). ismember(2285,8). ismember(2285,12). 
ismember(2286,2). ismember(2286,3). ismember(2286,4). ismember(2286,6). ismember(2286,7). ismember(2286,8). ismember(2286,12). 
ismember(2287,1). ismember(2287,2). ismember(2287,3). ismember(2287,4). ismember(2287,6). ismember(2287,7). ismember(2287,8). ismember(2287,12). 
ismember(2288,5). ismember(2288,6). ismember(2288,7). ismember(2288,8). ismember(2288,12). 
ismember(2289,1). ismember(2289,5). ismember(2289,6). ismember(2289,7). ismember(2289,8). ismember(2289,12). 
ismember(2290,2). ismember(2290,5). ismember(2290,6). ismember(2290,7). ismember(2290,8). ismember(2290,12). 
ismember(2291,1). ismember(2291,2). ismember(2291,5). ismember(2291,6). ismember(2291,7). ismember(2291,8). ismember(2291,12). 
ismember(2292,3). ismember(2292,5). ismember(2292,6). ismember(2292,7). ismember(2292,8). ismember(2292,12). 
ismember(2293,1). ismember(2293,3). ismember(2293,5). ismember(2293,6). ismember(2293,7). ismember(2293,8). ismember(2293,12). 
ismember(2294,2). ismember(2294,3). ismember(2294,5). ismember(2294,6). ismember(2294,7). ismember(2294,8). ismember(2294,12). 
ismember(2295,1). ismember(2295,2). ismember(2295,3). ismember(2295,5). ismember(2295,6). ismember(2295,7). ismember(2295,8). ismember(2295,12). 
ismember(2296,4). ismember(2296,5). ismember(2296,6). ismember(2296,7). ismember(2296,8). ismember(2296,12). 
ismember(2297,1). ismember(2297,4). ismember(2297,5). ismember(2297,6). ismember(2297,7). ismember(2297,8). ismember(2297,12). 
ismember(2298,2). ismember(2298,4). ismember(2298,5). ismember(2298,6). ismember(2298,7). ismember(2298,8). ismember(2298,12). 
ismember(2299,1). ismember(2299,2). ismember(2299,4). ismember(2299,5). ismember(2299,6). ismember(2299,7). ismember(2299,8). ismember(2299,12). 
ismember(2300,3). ismember(2300,4). ismember(2300,5). ismember(2300,6). ismember(2300,7). ismember(2300,8). ismember(2300,12). 
ismember(2301,1). ismember(2301,3). ismember(2301,4). ismember(2301,5). ismember(2301,6). ismember(2301,7). ismember(2301,8). ismember(2301,12). 
ismember(2302,2). ismember(2302,3). ismember(2302,4). ismember(2302,5). ismember(2302,6). ismember(2302,7). ismember(2302,8). ismember(2302,12). 
ismember(2303,1). ismember(2303,2). ismember(2303,3). ismember(2303,4). ismember(2303,5). ismember(2303,6). ismember(2303,7). ismember(2303,8). ismember(2303,12). 
ismember(2304,9). ismember(2304,12). 
ismember(2305,1). ismember(2305,9). ismember(2305,12). 
ismember(2306,2). ismember(2306,9). ismember(2306,12). 
ismember(2307,1). ismember(2307,2). ismember(2307,9). ismember(2307,12). 
ismember(2308,3). ismember(2308,9). ismember(2308,12). 
ismember(2309,1). ismember(2309,3). ismember(2309,9). ismember(2309,12). 
ismember(2310,2). ismember(2310,3). ismember(2310,9). ismember(2310,12). 
ismember(2311,1). ismember(2311,2). ismember(2311,3). ismember(2311,9). ismember(2311,12). 
ismember(2312,4). ismember(2312,9). ismember(2312,12). 
ismember(2313,1). ismember(2313,4). ismember(2313,9). ismember(2313,12). 
ismember(2314,2). ismember(2314,4). ismember(2314,9). ismember(2314,12). 
ismember(2315,1). ismember(2315,2). ismember(2315,4). ismember(2315,9). ismember(2315,12). 
ismember(2316,3). ismember(2316,4). ismember(2316,9). ismember(2316,12). 
ismember(2317,1). ismember(2317,3). ismember(2317,4). ismember(2317,9). ismember(2317,12). 
ismember(2318,2). ismember(2318,3). ismember(2318,4). ismember(2318,9). ismember(2318,12). 
ismember(2319,1). ismember(2319,2). ismember(2319,3). ismember(2319,4). ismember(2319,9). ismember(2319,12). 
ismember(2320,5). ismember(2320,9). ismember(2320,12). 
ismember(2321,1). ismember(2321,5). ismember(2321,9). ismember(2321,12). 
ismember(2322,2). ismember(2322,5). ismember(2322,9). ismember(2322,12). 
ismember(2323,1). ismember(2323,2). ismember(2323,5). ismember(2323,9). ismember(2323,12). 
ismember(2324,3). ismember(2324,5). ismember(2324,9). ismember(2324,12). 
ismember(2325,1). ismember(2325,3). ismember(2325,5). ismember(2325,9). ismember(2325,12). 
ismember(2326,2). ismember(2326,3). ismember(2326,5). ismember(2326,9). ismember(2326,12). 
ismember(2327,1). ismember(2327,2). ismember(2327,3). ismember(2327,5). ismember(2327,9). ismember(2327,12). 
ismember(2328,4). ismember(2328,5). ismember(2328,9). ismember(2328,12). 
ismember(2329,1). ismember(2329,4). ismember(2329,5). ismember(2329,9). ismember(2329,12). 
ismember(2330,2). ismember(2330,4). ismember(2330,5). ismember(2330,9). ismember(2330,12). 
ismember(2331,1). ismember(2331,2). ismember(2331,4). ismember(2331,5). ismember(2331,9). ismember(2331,12). 
ismember(2332,3). ismember(2332,4). ismember(2332,5). ismember(2332,9). ismember(2332,12). 
ismember(2333,1). ismember(2333,3). ismember(2333,4). ismember(2333,5). ismember(2333,9). ismember(2333,12). 
ismember(2334,2). ismember(2334,3). ismember(2334,4). ismember(2334,5). ismember(2334,9). ismember(2334,12). 
ismember(2335,1). ismember(2335,2). ismember(2335,3). ismember(2335,4). ismember(2335,5). ismember(2335,9). ismember(2335,12). 
ismember(2336,6). ismember(2336,9). ismember(2336,12). 
ismember(2337,1). ismember(2337,6). ismember(2337,9). ismember(2337,12). 
ismember(2338,2). ismember(2338,6). ismember(2338,9). ismember(2338,12). 
ismember(2339,1). ismember(2339,2). ismember(2339,6). ismember(2339,9). ismember(2339,12). 
ismember(2340,3). ismember(2340,6). ismember(2340,9). ismember(2340,12). 
ismember(2341,1). ismember(2341,3). ismember(2341,6). ismember(2341,9). ismember(2341,12). 
ismember(2342,2). ismember(2342,3). ismember(2342,6). ismember(2342,9). ismember(2342,12). 
ismember(2343,1). ismember(2343,2). ismember(2343,3). ismember(2343,6). ismember(2343,9). ismember(2343,12). 
ismember(2344,4). ismember(2344,6). ismember(2344,9). ismember(2344,12). 
ismember(2345,1). ismember(2345,4). ismember(2345,6). ismember(2345,9). ismember(2345,12). 
ismember(2346,2). ismember(2346,4). ismember(2346,6). ismember(2346,9). ismember(2346,12). 
ismember(2347,1). ismember(2347,2). ismember(2347,4). ismember(2347,6). ismember(2347,9). ismember(2347,12). 
ismember(2348,3). ismember(2348,4). ismember(2348,6). ismember(2348,9). ismember(2348,12). 
ismember(2349,1). ismember(2349,3). ismember(2349,4). ismember(2349,6). ismember(2349,9). ismember(2349,12). 
ismember(2350,2). ismember(2350,3). ismember(2350,4). ismember(2350,6). ismember(2350,9). ismember(2350,12). 
ismember(2351,1). ismember(2351,2). ismember(2351,3). ismember(2351,4). ismember(2351,6). ismember(2351,9). ismember(2351,12). 
ismember(2352,5). ismember(2352,6). ismember(2352,9). ismember(2352,12). 
ismember(2353,1). ismember(2353,5). ismember(2353,6). ismember(2353,9). ismember(2353,12). 
ismember(2354,2). ismember(2354,5). ismember(2354,6). ismember(2354,9). ismember(2354,12). 
ismember(2355,1). ismember(2355,2). ismember(2355,5). ismember(2355,6). ismember(2355,9). ismember(2355,12). 
ismember(2356,3). ismember(2356,5). ismember(2356,6). ismember(2356,9). ismember(2356,12). 
ismember(2357,1). ismember(2357,3). ismember(2357,5). ismember(2357,6). ismember(2357,9). ismember(2357,12). 
ismember(2358,2). ismember(2358,3). ismember(2358,5). ismember(2358,6). ismember(2358,9). ismember(2358,12). 
ismember(2359,1). ismember(2359,2). ismember(2359,3). ismember(2359,5). ismember(2359,6). ismember(2359,9). ismember(2359,12). 
ismember(2360,4). ismember(2360,5). ismember(2360,6). ismember(2360,9). ismember(2360,12). 
ismember(2361,1). ismember(2361,4). ismember(2361,5). ismember(2361,6). ismember(2361,9). ismember(2361,12). 
ismember(2362,2). ismember(2362,4). ismember(2362,5). ismember(2362,6). ismember(2362,9). ismember(2362,12). 
ismember(2363,1). ismember(2363,2). ismember(2363,4). ismember(2363,5). ismember(2363,6). ismember(2363,9). ismember(2363,12). 
ismember(2364,3). ismember(2364,4). ismember(2364,5). ismember(2364,6). ismember(2364,9). ismember(2364,12). 
ismember(2365,1). ismember(2365,3). ismember(2365,4). ismember(2365,5). ismember(2365,6). ismember(2365,9). ismember(2365,12). 
ismember(2366,2). ismember(2366,3). ismember(2366,4). ismember(2366,5). ismember(2366,6). ismember(2366,9). ismember(2366,12). 
ismember(2367,1). ismember(2367,2). ismember(2367,3). ismember(2367,4). ismember(2367,5). ismember(2367,6). ismember(2367,9). ismember(2367,12). 
ismember(2368,7). ismember(2368,9). ismember(2368,12). 
ismember(2369,1). ismember(2369,7). ismember(2369,9). ismember(2369,12). 
ismember(2370,2). ismember(2370,7). ismember(2370,9). ismember(2370,12). 
ismember(2371,1). ismember(2371,2). ismember(2371,7). ismember(2371,9). ismember(2371,12). 
ismember(2372,3). ismember(2372,7). ismember(2372,9). ismember(2372,12). 
ismember(2373,1). ismember(2373,3). ismember(2373,7). ismember(2373,9). ismember(2373,12). 
ismember(2374,2). ismember(2374,3). ismember(2374,7). ismember(2374,9). ismember(2374,12). 
ismember(2375,1). ismember(2375,2). ismember(2375,3). ismember(2375,7). ismember(2375,9). ismember(2375,12). 
ismember(2376,4). ismember(2376,7). ismember(2376,9). ismember(2376,12). 
ismember(2377,1). ismember(2377,4). ismember(2377,7). ismember(2377,9). ismember(2377,12). 
ismember(2378,2). ismember(2378,4). ismember(2378,7). ismember(2378,9). ismember(2378,12). 
ismember(2379,1). ismember(2379,2). ismember(2379,4). ismember(2379,7). ismember(2379,9). ismember(2379,12). 
ismember(2380,3). ismember(2380,4). ismember(2380,7). ismember(2380,9). ismember(2380,12). 
ismember(2381,1). ismember(2381,3). ismember(2381,4). ismember(2381,7). ismember(2381,9). ismember(2381,12). 
ismember(2382,2). ismember(2382,3). ismember(2382,4). ismember(2382,7). ismember(2382,9). ismember(2382,12). 
ismember(2383,1). ismember(2383,2). ismember(2383,3). ismember(2383,4). ismember(2383,7). ismember(2383,9). ismember(2383,12). 
ismember(2384,5). ismember(2384,7). ismember(2384,9). ismember(2384,12). 
ismember(2385,1). ismember(2385,5). ismember(2385,7). ismember(2385,9). ismember(2385,12). 
ismember(2386,2). ismember(2386,5). ismember(2386,7). ismember(2386,9). ismember(2386,12). 
ismember(2387,1). ismember(2387,2). ismember(2387,5). ismember(2387,7). ismember(2387,9). ismember(2387,12). 
ismember(2388,3). ismember(2388,5). ismember(2388,7). ismember(2388,9). ismember(2388,12). 
ismember(2389,1). ismember(2389,3). ismember(2389,5). ismember(2389,7). ismember(2389,9). ismember(2389,12). 
ismember(2390,2). ismember(2390,3). ismember(2390,5). ismember(2390,7). ismember(2390,9). ismember(2390,12). 
ismember(2391,1). ismember(2391,2). ismember(2391,3). ismember(2391,5). ismember(2391,7). ismember(2391,9). ismember(2391,12). 
ismember(2392,4). ismember(2392,5). ismember(2392,7). ismember(2392,9). ismember(2392,12). 
ismember(2393,1). ismember(2393,4). ismember(2393,5). ismember(2393,7). ismember(2393,9). ismember(2393,12). 
ismember(2394,2). ismember(2394,4). ismember(2394,5). ismember(2394,7). ismember(2394,9). ismember(2394,12). 
ismember(2395,1). ismember(2395,2). ismember(2395,4). ismember(2395,5). ismember(2395,7). ismember(2395,9). ismember(2395,12). 
ismember(2396,3). ismember(2396,4). ismember(2396,5). ismember(2396,7). ismember(2396,9). ismember(2396,12). 
ismember(2397,1). ismember(2397,3). ismember(2397,4). ismember(2397,5). ismember(2397,7). ismember(2397,9). ismember(2397,12). 
ismember(2398,2). ismember(2398,3). ismember(2398,4). ismember(2398,5). ismember(2398,7). ismember(2398,9). ismember(2398,12). 
ismember(2399,1). ismember(2399,2). ismember(2399,3). ismember(2399,4). ismember(2399,5). ismember(2399,7). ismember(2399,9). ismember(2399,12). 
ismember(2400,6). ismember(2400,7). ismember(2400,9). ismember(2400,12). 
ismember(2401,1). ismember(2401,6). ismember(2401,7). ismember(2401,9). ismember(2401,12). 
ismember(2402,2). ismember(2402,6). ismember(2402,7). ismember(2402,9). ismember(2402,12). 
ismember(2403,1). ismember(2403,2). ismember(2403,6). ismember(2403,7). ismember(2403,9). ismember(2403,12). 
ismember(2404,3). ismember(2404,6). ismember(2404,7). ismember(2404,9). ismember(2404,12). 
ismember(2405,1). ismember(2405,3). ismember(2405,6). ismember(2405,7). ismember(2405,9). ismember(2405,12). 
ismember(2406,2). ismember(2406,3). ismember(2406,6). ismember(2406,7). ismember(2406,9). ismember(2406,12). 
ismember(2407,1). ismember(2407,2). ismember(2407,3). ismember(2407,6). ismember(2407,7). ismember(2407,9). ismember(2407,12). 
ismember(2408,4). ismember(2408,6). ismember(2408,7). ismember(2408,9). ismember(2408,12). 
ismember(2409,1). ismember(2409,4). ismember(2409,6). ismember(2409,7). ismember(2409,9). ismember(2409,12). 
ismember(2410,2). ismember(2410,4). ismember(2410,6). ismember(2410,7). ismember(2410,9). ismember(2410,12). 
ismember(2411,1). ismember(2411,2). ismember(2411,4). ismember(2411,6). ismember(2411,7). ismember(2411,9). ismember(2411,12). 
ismember(2412,3). ismember(2412,4). ismember(2412,6). ismember(2412,7). ismember(2412,9). ismember(2412,12). 
ismember(2413,1). ismember(2413,3). ismember(2413,4). ismember(2413,6). ismember(2413,7). ismember(2413,9). ismember(2413,12). 
ismember(2414,2). ismember(2414,3). ismember(2414,4). ismember(2414,6). ismember(2414,7). ismember(2414,9). ismember(2414,12). 
ismember(2415,1). ismember(2415,2). ismember(2415,3). ismember(2415,4). ismember(2415,6). ismember(2415,7). ismember(2415,9). ismember(2415,12). 
ismember(2416,5). ismember(2416,6). ismember(2416,7). ismember(2416,9). ismember(2416,12). 
ismember(2417,1). ismember(2417,5). ismember(2417,6). ismember(2417,7). ismember(2417,9). ismember(2417,12). 
ismember(2418,2). ismember(2418,5). ismember(2418,6). ismember(2418,7). ismember(2418,9). ismember(2418,12). 
ismember(2419,1). ismember(2419,2). ismember(2419,5). ismember(2419,6). ismember(2419,7). ismember(2419,9). ismember(2419,12). 
ismember(2420,3). ismember(2420,5). ismember(2420,6). ismember(2420,7). ismember(2420,9). ismember(2420,12). 
ismember(2421,1). ismember(2421,3). ismember(2421,5). ismember(2421,6). ismember(2421,7). ismember(2421,9). ismember(2421,12). 
ismember(2422,2). ismember(2422,3). ismember(2422,5). ismember(2422,6). ismember(2422,7). ismember(2422,9). ismember(2422,12). 
ismember(2423,1). ismember(2423,2). ismember(2423,3). ismember(2423,5). ismember(2423,6). ismember(2423,7). ismember(2423,9). ismember(2423,12). 
ismember(2424,4). ismember(2424,5). ismember(2424,6). ismember(2424,7). ismember(2424,9). ismember(2424,12). 
ismember(2425,1). ismember(2425,4). ismember(2425,5). ismember(2425,6). ismember(2425,7). ismember(2425,9). ismember(2425,12). 
ismember(2426,2). ismember(2426,4). ismember(2426,5). ismember(2426,6). ismember(2426,7). ismember(2426,9). ismember(2426,12). 
ismember(2427,1). ismember(2427,2). ismember(2427,4). ismember(2427,5). ismember(2427,6). ismember(2427,7). ismember(2427,9). ismember(2427,12). 
ismember(2428,3). ismember(2428,4). ismember(2428,5). ismember(2428,6). ismember(2428,7). ismember(2428,9). ismember(2428,12). 
ismember(2429,1). ismember(2429,3). ismember(2429,4). ismember(2429,5). ismember(2429,6). ismember(2429,7). ismember(2429,9). ismember(2429,12). 
ismember(2430,2). ismember(2430,3). ismember(2430,4). ismember(2430,5). ismember(2430,6). ismember(2430,7). ismember(2430,9). ismember(2430,12). 
ismember(2431,1). ismember(2431,2). ismember(2431,3). ismember(2431,4). ismember(2431,5). ismember(2431,6). ismember(2431,7). ismember(2431,9). ismember(2431,12). 
ismember(2432,8). ismember(2432,9). ismember(2432,12). 
ismember(2433,1). ismember(2433,8). ismember(2433,9). ismember(2433,12). 
ismember(2434,2). ismember(2434,8). ismember(2434,9). ismember(2434,12). 
ismember(2435,1). ismember(2435,2). ismember(2435,8). ismember(2435,9). ismember(2435,12). 
ismember(2436,3). ismember(2436,8). ismember(2436,9). ismember(2436,12). 
ismember(2437,1). ismember(2437,3). ismember(2437,8). ismember(2437,9). ismember(2437,12). 
ismember(2438,2). ismember(2438,3). ismember(2438,8). ismember(2438,9). ismember(2438,12). 
ismember(2439,1). ismember(2439,2). ismember(2439,3). ismember(2439,8). ismember(2439,9). ismember(2439,12). 
ismember(2440,4). ismember(2440,8). ismember(2440,9). ismember(2440,12). 
ismember(2441,1). ismember(2441,4). ismember(2441,8). ismember(2441,9). ismember(2441,12). 
ismember(2442,2). ismember(2442,4). ismember(2442,8). ismember(2442,9). ismember(2442,12). 
ismember(2443,1). ismember(2443,2). ismember(2443,4). ismember(2443,8). ismember(2443,9). ismember(2443,12). 
ismember(2444,3). ismember(2444,4). ismember(2444,8). ismember(2444,9). ismember(2444,12). 
ismember(2445,1). ismember(2445,3). ismember(2445,4). ismember(2445,8). ismember(2445,9). ismember(2445,12). 
ismember(2446,2). ismember(2446,3). ismember(2446,4). ismember(2446,8). ismember(2446,9). ismember(2446,12). 
ismember(2447,1). ismember(2447,2). ismember(2447,3). ismember(2447,4). ismember(2447,8). ismember(2447,9). ismember(2447,12). 
ismember(2448,5). ismember(2448,8). ismember(2448,9). ismember(2448,12). 
ismember(2449,1). ismember(2449,5). ismember(2449,8). ismember(2449,9). ismember(2449,12). 
ismember(2450,2). ismember(2450,5). ismember(2450,8). ismember(2450,9). ismember(2450,12). 
ismember(2451,1). ismember(2451,2). ismember(2451,5). ismember(2451,8). ismember(2451,9). ismember(2451,12). 
ismember(2452,3). ismember(2452,5). ismember(2452,8). ismember(2452,9). ismember(2452,12). 
ismember(2453,1). ismember(2453,3). ismember(2453,5). ismember(2453,8). ismember(2453,9). ismember(2453,12). 
ismember(2454,2). ismember(2454,3). ismember(2454,5). ismember(2454,8). ismember(2454,9). ismember(2454,12). 
ismember(2455,1). ismember(2455,2). ismember(2455,3). ismember(2455,5). ismember(2455,8). ismember(2455,9). ismember(2455,12). 
ismember(2456,4). ismember(2456,5). ismember(2456,8). ismember(2456,9). ismember(2456,12). 
ismember(2457,1). ismember(2457,4). ismember(2457,5). ismember(2457,8). ismember(2457,9). ismember(2457,12). 
ismember(2458,2). ismember(2458,4). ismember(2458,5). ismember(2458,8). ismember(2458,9). ismember(2458,12). 
ismember(2459,1). ismember(2459,2). ismember(2459,4). ismember(2459,5). ismember(2459,8). ismember(2459,9). ismember(2459,12). 
ismember(2460,3). ismember(2460,4). ismember(2460,5). ismember(2460,8). ismember(2460,9). ismember(2460,12). 
ismember(2461,1). ismember(2461,3). ismember(2461,4). ismember(2461,5). ismember(2461,8). ismember(2461,9). ismember(2461,12). 
ismember(2462,2). ismember(2462,3). ismember(2462,4). ismember(2462,5). ismember(2462,8). ismember(2462,9). ismember(2462,12). 
ismember(2463,1). ismember(2463,2). ismember(2463,3). ismember(2463,4). ismember(2463,5). ismember(2463,8). ismember(2463,9). ismember(2463,12). 
ismember(2464,6). ismember(2464,8). ismember(2464,9). ismember(2464,12). 
ismember(2465,1). ismember(2465,6). ismember(2465,8). ismember(2465,9). ismember(2465,12). 
ismember(2466,2). ismember(2466,6). ismember(2466,8). ismember(2466,9). ismember(2466,12). 
ismember(2467,1). ismember(2467,2). ismember(2467,6). ismember(2467,8). ismember(2467,9). ismember(2467,12). 
ismember(2468,3). ismember(2468,6). ismember(2468,8). ismember(2468,9). ismember(2468,12). 
ismember(2469,1). ismember(2469,3). ismember(2469,6). ismember(2469,8). ismember(2469,9). ismember(2469,12). 
ismember(2470,2). ismember(2470,3). ismember(2470,6). ismember(2470,8). ismember(2470,9). ismember(2470,12). 
ismember(2471,1). ismember(2471,2). ismember(2471,3). ismember(2471,6). ismember(2471,8). ismember(2471,9). ismember(2471,12). 
ismember(2472,4). ismember(2472,6). ismember(2472,8). ismember(2472,9). ismember(2472,12). 
ismember(2473,1). ismember(2473,4). ismember(2473,6). ismember(2473,8). ismember(2473,9). ismember(2473,12). 
ismember(2474,2). ismember(2474,4). ismember(2474,6). ismember(2474,8). ismember(2474,9). ismember(2474,12). 
ismember(2475,1). ismember(2475,2). ismember(2475,4). ismember(2475,6). ismember(2475,8). ismember(2475,9). ismember(2475,12). 
ismember(2476,3). ismember(2476,4). ismember(2476,6). ismember(2476,8). ismember(2476,9). ismember(2476,12). 
ismember(2477,1). ismember(2477,3). ismember(2477,4). ismember(2477,6). ismember(2477,8). ismember(2477,9). ismember(2477,12). 
ismember(2478,2). ismember(2478,3). ismember(2478,4). ismember(2478,6). ismember(2478,8). ismember(2478,9). ismember(2478,12). 
ismember(2479,1). ismember(2479,2). ismember(2479,3). ismember(2479,4). ismember(2479,6). ismember(2479,8). ismember(2479,9). ismember(2479,12). 
ismember(2480,5). ismember(2480,6). ismember(2480,8). ismember(2480,9). ismember(2480,12). 
ismember(2481,1). ismember(2481,5). ismember(2481,6). ismember(2481,8). ismember(2481,9). ismember(2481,12). 
ismember(2482,2). ismember(2482,5). ismember(2482,6). ismember(2482,8). ismember(2482,9). ismember(2482,12). 
ismember(2483,1). ismember(2483,2). ismember(2483,5). ismember(2483,6). ismember(2483,8). ismember(2483,9). ismember(2483,12). 
ismember(2484,3). ismember(2484,5). ismember(2484,6). ismember(2484,8). ismember(2484,9). ismember(2484,12). 
ismember(2485,1). ismember(2485,3). ismember(2485,5). ismember(2485,6). ismember(2485,8). ismember(2485,9). ismember(2485,12). 
ismember(2486,2). ismember(2486,3). ismember(2486,5). ismember(2486,6). ismember(2486,8). ismember(2486,9). ismember(2486,12). 
ismember(2487,1). ismember(2487,2). ismember(2487,3). ismember(2487,5). ismember(2487,6). ismember(2487,8). ismember(2487,9). ismember(2487,12). 
ismember(2488,4). ismember(2488,5). ismember(2488,6). ismember(2488,8). ismember(2488,9). ismember(2488,12). 
ismember(2489,1). ismember(2489,4). ismember(2489,5). ismember(2489,6). ismember(2489,8). ismember(2489,9). ismember(2489,12). 
ismember(2490,2). ismember(2490,4). ismember(2490,5). ismember(2490,6). ismember(2490,8). ismember(2490,9). ismember(2490,12). 
ismember(2491,1). ismember(2491,2). ismember(2491,4). ismember(2491,5). ismember(2491,6). ismember(2491,8). ismember(2491,9). ismember(2491,12). 
ismember(2492,3). ismember(2492,4). ismember(2492,5). ismember(2492,6). ismember(2492,8). ismember(2492,9). ismember(2492,12). 
ismember(2493,1). ismember(2493,3). ismember(2493,4). ismember(2493,5). ismember(2493,6). ismember(2493,8). ismember(2493,9). ismember(2493,12). 
ismember(2494,2). ismember(2494,3). ismember(2494,4). ismember(2494,5). ismember(2494,6). ismember(2494,8). ismember(2494,9). ismember(2494,12). 
ismember(2495,1). ismember(2495,2). ismember(2495,3). ismember(2495,4). ismember(2495,5). ismember(2495,6). ismember(2495,8). ismember(2495,9). ismember(2495,12). 
ismember(2496,7). ismember(2496,8). ismember(2496,9). ismember(2496,12). 
ismember(2497,1). ismember(2497,7). ismember(2497,8). ismember(2497,9). ismember(2497,12). 
ismember(2498,2). ismember(2498,7). ismember(2498,8). ismember(2498,9). ismember(2498,12). 
ismember(2499,1). ismember(2499,2). ismember(2499,7). ismember(2499,8). ismember(2499,9). ismember(2499,12). 
ismember(2500,3). ismember(2500,7). ismember(2500,8). ismember(2500,9). ismember(2500,12). 
ismember(2501,1). ismember(2501,3). ismember(2501,7). ismember(2501,8). ismember(2501,9). ismember(2501,12). 
ismember(2502,2). ismember(2502,3). ismember(2502,7). ismember(2502,8). ismember(2502,9). ismember(2502,12). 
ismember(2503,1). ismember(2503,2). ismember(2503,3). ismember(2503,7). ismember(2503,8). ismember(2503,9). ismember(2503,12). 
ismember(2504,4). ismember(2504,7). ismember(2504,8). ismember(2504,9). ismember(2504,12). 
ismember(2505,1). ismember(2505,4). ismember(2505,7). ismember(2505,8). ismember(2505,9). ismember(2505,12). 
ismember(2506,2). ismember(2506,4). ismember(2506,7). ismember(2506,8). ismember(2506,9). ismember(2506,12). 
ismember(2507,1). ismember(2507,2). ismember(2507,4). ismember(2507,7). ismember(2507,8). ismember(2507,9). ismember(2507,12). 
ismember(2508,3). ismember(2508,4). ismember(2508,7). ismember(2508,8). ismember(2508,9). ismember(2508,12). 
ismember(2509,1). ismember(2509,3). ismember(2509,4). ismember(2509,7). ismember(2509,8). ismember(2509,9). ismember(2509,12). 
ismember(2510,2). ismember(2510,3). ismember(2510,4). ismember(2510,7). ismember(2510,8). ismember(2510,9). ismember(2510,12). 
ismember(2511,1). ismember(2511,2). ismember(2511,3). ismember(2511,4). ismember(2511,7). ismember(2511,8). ismember(2511,9). ismember(2511,12). 
ismember(2512,5). ismember(2512,7). ismember(2512,8). ismember(2512,9). ismember(2512,12). 
ismember(2513,1). ismember(2513,5). ismember(2513,7). ismember(2513,8). ismember(2513,9). ismember(2513,12). 
ismember(2514,2). ismember(2514,5). ismember(2514,7). ismember(2514,8). ismember(2514,9). ismember(2514,12). 
ismember(2515,1). ismember(2515,2). ismember(2515,5). ismember(2515,7). ismember(2515,8). ismember(2515,9). ismember(2515,12). 
ismember(2516,3). ismember(2516,5). ismember(2516,7). ismember(2516,8). ismember(2516,9). ismember(2516,12). 
ismember(2517,1). ismember(2517,3). ismember(2517,5). ismember(2517,7). ismember(2517,8). ismember(2517,9). ismember(2517,12). 
ismember(2518,2). ismember(2518,3). ismember(2518,5). ismember(2518,7). ismember(2518,8). ismember(2518,9). ismember(2518,12). 
ismember(2519,1). ismember(2519,2). ismember(2519,3). ismember(2519,5). ismember(2519,7). ismember(2519,8). ismember(2519,9). ismember(2519,12). 
ismember(2520,4). ismember(2520,5). ismember(2520,7). ismember(2520,8). ismember(2520,9). ismember(2520,12). 
ismember(2521,1). ismember(2521,4). ismember(2521,5). ismember(2521,7). ismember(2521,8). ismember(2521,9). ismember(2521,12). 
ismember(2522,2). ismember(2522,4). ismember(2522,5). ismember(2522,7). ismember(2522,8). ismember(2522,9). ismember(2522,12). 
ismember(2523,1). ismember(2523,2). ismember(2523,4). ismember(2523,5). ismember(2523,7). ismember(2523,8). ismember(2523,9). ismember(2523,12). 
ismember(2524,3). ismember(2524,4). ismember(2524,5). ismember(2524,7). ismember(2524,8). ismember(2524,9). ismember(2524,12). 
ismember(2525,1). ismember(2525,3). ismember(2525,4). ismember(2525,5). ismember(2525,7). ismember(2525,8). ismember(2525,9). ismember(2525,12). 
ismember(2526,2). ismember(2526,3). ismember(2526,4). ismember(2526,5). ismember(2526,7). ismember(2526,8). ismember(2526,9). ismember(2526,12). 
ismember(2527,1). ismember(2527,2). ismember(2527,3). ismember(2527,4). ismember(2527,5). ismember(2527,7). ismember(2527,8). ismember(2527,9). ismember(2527,12). 
ismember(2528,6). ismember(2528,7). ismember(2528,8). ismember(2528,9). ismember(2528,12). 
ismember(2529,1). ismember(2529,6). ismember(2529,7). ismember(2529,8). ismember(2529,9). ismember(2529,12). 
ismember(2530,2). ismember(2530,6). ismember(2530,7). ismember(2530,8). ismember(2530,9). ismember(2530,12). 
ismember(2531,1). ismember(2531,2). ismember(2531,6). ismember(2531,7). ismember(2531,8). ismember(2531,9). ismember(2531,12). 
ismember(2532,3). ismember(2532,6). ismember(2532,7). ismember(2532,8). ismember(2532,9). ismember(2532,12). 
ismember(2533,1). ismember(2533,3). ismember(2533,6). ismember(2533,7). ismember(2533,8). ismember(2533,9). ismember(2533,12). 
ismember(2534,2). ismember(2534,3). ismember(2534,6). ismember(2534,7). ismember(2534,8). ismember(2534,9). ismember(2534,12). 
ismember(2535,1). ismember(2535,2). ismember(2535,3). ismember(2535,6). ismember(2535,7). ismember(2535,8). ismember(2535,9). ismember(2535,12). 
ismember(2536,4). ismember(2536,6). ismember(2536,7). ismember(2536,8). ismember(2536,9). ismember(2536,12). 
ismember(2537,1). ismember(2537,4). ismember(2537,6). ismember(2537,7). ismember(2537,8). ismember(2537,9). ismember(2537,12). 
ismember(2538,2). ismember(2538,4). ismember(2538,6). ismember(2538,7). ismember(2538,8). ismember(2538,9). ismember(2538,12). 
ismember(2539,1). ismember(2539,2). ismember(2539,4). ismember(2539,6). ismember(2539,7). ismember(2539,8). ismember(2539,9). ismember(2539,12). 
ismember(2540,3). ismember(2540,4). ismember(2540,6). ismember(2540,7). ismember(2540,8). ismember(2540,9). ismember(2540,12). 
ismember(2541,1). ismember(2541,3). ismember(2541,4). ismember(2541,6). ismember(2541,7). ismember(2541,8). ismember(2541,9). ismember(2541,12). 
ismember(2542,2). ismember(2542,3). ismember(2542,4). ismember(2542,6). ismember(2542,7). ismember(2542,8). ismember(2542,9). ismember(2542,12). 
ismember(2543,1). ismember(2543,2). ismember(2543,3). ismember(2543,4). ismember(2543,6). ismember(2543,7). ismember(2543,8). ismember(2543,9). ismember(2543,12). 
ismember(2544,5). ismember(2544,6). ismember(2544,7). ismember(2544,8). ismember(2544,9). ismember(2544,12). 
ismember(2545,1). ismember(2545,5). ismember(2545,6). ismember(2545,7). ismember(2545,8). ismember(2545,9). ismember(2545,12). 
ismember(2546,2). ismember(2546,5). ismember(2546,6). ismember(2546,7). ismember(2546,8). ismember(2546,9). ismember(2546,12). 
ismember(2547,1). ismember(2547,2). ismember(2547,5). ismember(2547,6). ismember(2547,7). ismember(2547,8). ismember(2547,9). ismember(2547,12). 
ismember(2548,3). ismember(2548,5). ismember(2548,6). ismember(2548,7). ismember(2548,8). ismember(2548,9). ismember(2548,12). 
ismember(2549,1). ismember(2549,3). ismember(2549,5). ismember(2549,6). ismember(2549,7). ismember(2549,8). ismember(2549,9). ismember(2549,12). 
ismember(2550,2). ismember(2550,3). ismember(2550,5). ismember(2550,6). ismember(2550,7). ismember(2550,8). ismember(2550,9). ismember(2550,12). 
ismember(2551,1). ismember(2551,2). ismember(2551,3). ismember(2551,5). ismember(2551,6). ismember(2551,7). ismember(2551,8). ismember(2551,9). ismember(2551,12). 
ismember(2552,4). ismember(2552,5). ismember(2552,6). ismember(2552,7). ismember(2552,8). ismember(2552,9). ismember(2552,12). 
ismember(2553,1). ismember(2553,4). ismember(2553,5). ismember(2553,6). ismember(2553,7). ismember(2553,8). ismember(2553,9). ismember(2553,12). 
ismember(2554,2). ismember(2554,4). ismember(2554,5). ismember(2554,6). ismember(2554,7). ismember(2554,8). ismember(2554,9). ismember(2554,12). 
ismember(2555,1). ismember(2555,2). ismember(2555,4). ismember(2555,5). ismember(2555,6). ismember(2555,7). ismember(2555,8). ismember(2555,9). ismember(2555,12). 
ismember(2556,3). ismember(2556,4). ismember(2556,5). ismember(2556,6). ismember(2556,7). ismember(2556,8). ismember(2556,9). ismember(2556,12). 
ismember(2557,1). ismember(2557,3). ismember(2557,4). ismember(2557,5). ismember(2557,6). ismember(2557,7). ismember(2557,8). ismember(2557,9). ismember(2557,12). 
ismember(2558,2). ismember(2558,3). ismember(2558,4). ismember(2558,5). ismember(2558,6). ismember(2558,7). ismember(2558,8). ismember(2558,9). ismember(2558,12). 
ismember(2559,1). ismember(2559,2). ismember(2559,3). ismember(2559,4). ismember(2559,5). ismember(2559,6). ismember(2559,7). ismember(2559,8). ismember(2559,9). ismember(2559,12). 
ismember(2560,10). ismember(2560,12). 
ismember(2561,1). ismember(2561,10). ismember(2561,12). 
ismember(2562,2). ismember(2562,10). ismember(2562,12). 
ismember(2563,1). ismember(2563,2). ismember(2563,10). ismember(2563,12). 
ismember(2564,3). ismember(2564,10). ismember(2564,12). 
ismember(2565,1). ismember(2565,3). ismember(2565,10). ismember(2565,12). 
ismember(2566,2). ismember(2566,3). ismember(2566,10). ismember(2566,12). 
ismember(2567,1). ismember(2567,2). ismember(2567,3). ismember(2567,10). ismember(2567,12). 
ismember(2568,4). ismember(2568,10). ismember(2568,12). 
ismember(2569,1). ismember(2569,4). ismember(2569,10). ismember(2569,12). 
ismember(2570,2). ismember(2570,4). ismember(2570,10). ismember(2570,12). 
ismember(2571,1). ismember(2571,2). ismember(2571,4). ismember(2571,10). ismember(2571,12). 
ismember(2572,3). ismember(2572,4). ismember(2572,10). ismember(2572,12). 
ismember(2573,1). ismember(2573,3). ismember(2573,4). ismember(2573,10). ismember(2573,12). 
ismember(2574,2). ismember(2574,3). ismember(2574,4). ismember(2574,10). ismember(2574,12). 
ismember(2575,1). ismember(2575,2). ismember(2575,3). ismember(2575,4). ismember(2575,10). ismember(2575,12). 
ismember(2576,5). ismember(2576,10). ismember(2576,12). 
ismember(2577,1). ismember(2577,5). ismember(2577,10). ismember(2577,12). 
ismember(2578,2). ismember(2578,5). ismember(2578,10). ismember(2578,12). 
ismember(2579,1). ismember(2579,2). ismember(2579,5). ismember(2579,10). ismember(2579,12). 
ismember(2580,3). ismember(2580,5). ismember(2580,10). ismember(2580,12). 
ismember(2581,1). ismember(2581,3). ismember(2581,5). ismember(2581,10). ismember(2581,12). 
ismember(2582,2). ismember(2582,3). ismember(2582,5). ismember(2582,10). ismember(2582,12). 
ismember(2583,1). ismember(2583,2). ismember(2583,3). ismember(2583,5). ismember(2583,10). ismember(2583,12). 
ismember(2584,4). ismember(2584,5). ismember(2584,10). ismember(2584,12). 
ismember(2585,1). ismember(2585,4). ismember(2585,5). ismember(2585,10). ismember(2585,12). 
ismember(2586,2). ismember(2586,4). ismember(2586,5). ismember(2586,10). ismember(2586,12). 
ismember(2587,1). ismember(2587,2). ismember(2587,4). ismember(2587,5). ismember(2587,10). ismember(2587,12). 
ismember(2588,3). ismember(2588,4). ismember(2588,5). ismember(2588,10). ismember(2588,12). 
ismember(2589,1). ismember(2589,3). ismember(2589,4). ismember(2589,5). ismember(2589,10). ismember(2589,12). 
ismember(2590,2). ismember(2590,3). ismember(2590,4). ismember(2590,5). ismember(2590,10). ismember(2590,12). 
ismember(2591,1). ismember(2591,2). ismember(2591,3). ismember(2591,4). ismember(2591,5). ismember(2591,10). ismember(2591,12). 
ismember(2592,6). ismember(2592,10). ismember(2592,12). 
ismember(2593,1). ismember(2593,6). ismember(2593,10). ismember(2593,12). 
ismember(2594,2). ismember(2594,6). ismember(2594,10). ismember(2594,12). 
ismember(2595,1). ismember(2595,2). ismember(2595,6). ismember(2595,10). ismember(2595,12). 
ismember(2596,3). ismember(2596,6). ismember(2596,10). ismember(2596,12). 
ismember(2597,1). ismember(2597,3). ismember(2597,6). ismember(2597,10). ismember(2597,12). 
ismember(2598,2). ismember(2598,3). ismember(2598,6). ismember(2598,10). ismember(2598,12). 
ismember(2599,1). ismember(2599,2). ismember(2599,3). ismember(2599,6). ismember(2599,10). ismember(2599,12). 
ismember(2600,4). ismember(2600,6). ismember(2600,10). ismember(2600,12). 
ismember(2601,1). ismember(2601,4). ismember(2601,6). ismember(2601,10). ismember(2601,12). 
ismember(2602,2). ismember(2602,4). ismember(2602,6). ismember(2602,10). ismember(2602,12). 
ismember(2603,1). ismember(2603,2). ismember(2603,4). ismember(2603,6). ismember(2603,10). ismember(2603,12). 
ismember(2604,3). ismember(2604,4). ismember(2604,6). ismember(2604,10). ismember(2604,12). 
ismember(2605,1). ismember(2605,3). ismember(2605,4). ismember(2605,6). ismember(2605,10). ismember(2605,12). 
ismember(2606,2). ismember(2606,3). ismember(2606,4). ismember(2606,6). ismember(2606,10). ismember(2606,12). 
ismember(2607,1). ismember(2607,2). ismember(2607,3). ismember(2607,4). ismember(2607,6). ismember(2607,10). ismember(2607,12). 
ismember(2608,5). ismember(2608,6). ismember(2608,10). ismember(2608,12). 
ismember(2609,1). ismember(2609,5). ismember(2609,6). ismember(2609,10). ismember(2609,12). 
ismember(2610,2). ismember(2610,5). ismember(2610,6). ismember(2610,10). ismember(2610,12). 
ismember(2611,1). ismember(2611,2). ismember(2611,5). ismember(2611,6). ismember(2611,10). ismember(2611,12). 
ismember(2612,3). ismember(2612,5). ismember(2612,6). ismember(2612,10). ismember(2612,12). 
ismember(2613,1). ismember(2613,3). ismember(2613,5). ismember(2613,6). ismember(2613,10). ismember(2613,12). 
ismember(2614,2). ismember(2614,3). ismember(2614,5). ismember(2614,6). ismember(2614,10). ismember(2614,12). 
ismember(2615,1). ismember(2615,2). ismember(2615,3). ismember(2615,5). ismember(2615,6). ismember(2615,10). ismember(2615,12). 
ismember(2616,4). ismember(2616,5). ismember(2616,6). ismember(2616,10). ismember(2616,12). 
ismember(2617,1). ismember(2617,4). ismember(2617,5). ismember(2617,6). ismember(2617,10). ismember(2617,12). 
ismember(2618,2). ismember(2618,4). ismember(2618,5). ismember(2618,6). ismember(2618,10). ismember(2618,12). 
ismember(2619,1). ismember(2619,2). ismember(2619,4). ismember(2619,5). ismember(2619,6). ismember(2619,10). ismember(2619,12). 
ismember(2620,3). ismember(2620,4). ismember(2620,5). ismember(2620,6). ismember(2620,10). ismember(2620,12). 
ismember(2621,1). ismember(2621,3). ismember(2621,4). ismember(2621,5). ismember(2621,6). ismember(2621,10). ismember(2621,12). 
ismember(2622,2). ismember(2622,3). ismember(2622,4). ismember(2622,5). ismember(2622,6). ismember(2622,10). ismember(2622,12). 
ismember(2623,1). ismember(2623,2). ismember(2623,3). ismember(2623,4). ismember(2623,5). ismember(2623,6). ismember(2623,10). ismember(2623,12). 
ismember(2624,7). ismember(2624,10). ismember(2624,12). 
ismember(2625,1). ismember(2625,7). ismember(2625,10). ismember(2625,12). 
ismember(2626,2). ismember(2626,7). ismember(2626,10). ismember(2626,12). 
ismember(2627,1). ismember(2627,2). ismember(2627,7). ismember(2627,10). ismember(2627,12). 
ismember(2628,3). ismember(2628,7). ismember(2628,10). ismember(2628,12). 
ismember(2629,1). ismember(2629,3). ismember(2629,7). ismember(2629,10). ismember(2629,12). 
ismember(2630,2). ismember(2630,3). ismember(2630,7). ismember(2630,10). ismember(2630,12). 
ismember(2631,1). ismember(2631,2). ismember(2631,3). ismember(2631,7). ismember(2631,10). ismember(2631,12). 
ismember(2632,4). ismember(2632,7). ismember(2632,10). ismember(2632,12). 
ismember(2633,1). ismember(2633,4). ismember(2633,7). ismember(2633,10). ismember(2633,12). 
ismember(2634,2). ismember(2634,4). ismember(2634,7). ismember(2634,10). ismember(2634,12). 
ismember(2635,1). ismember(2635,2). ismember(2635,4). ismember(2635,7). ismember(2635,10). ismember(2635,12). 
ismember(2636,3). ismember(2636,4). ismember(2636,7). ismember(2636,10). ismember(2636,12). 
ismember(2637,1). ismember(2637,3). ismember(2637,4). ismember(2637,7). ismember(2637,10). ismember(2637,12). 
ismember(2638,2). ismember(2638,3). ismember(2638,4). ismember(2638,7). ismember(2638,10). ismember(2638,12). 
ismember(2639,1). ismember(2639,2). ismember(2639,3). ismember(2639,4). ismember(2639,7). ismember(2639,10). ismember(2639,12). 
ismember(2640,5). ismember(2640,7). ismember(2640,10). ismember(2640,12). 
ismember(2641,1). ismember(2641,5). ismember(2641,7). ismember(2641,10). ismember(2641,12). 
ismember(2642,2). ismember(2642,5). ismember(2642,7). ismember(2642,10). ismember(2642,12). 
ismember(2643,1). ismember(2643,2). ismember(2643,5). ismember(2643,7). ismember(2643,10). ismember(2643,12). 
ismember(2644,3). ismember(2644,5). ismember(2644,7). ismember(2644,10). ismember(2644,12). 
ismember(2645,1). ismember(2645,3). ismember(2645,5). ismember(2645,7). ismember(2645,10). ismember(2645,12). 
ismember(2646,2). ismember(2646,3). ismember(2646,5). ismember(2646,7). ismember(2646,10). ismember(2646,12). 
ismember(2647,1). ismember(2647,2). ismember(2647,3). ismember(2647,5). ismember(2647,7). ismember(2647,10). ismember(2647,12). 
ismember(2648,4). ismember(2648,5). ismember(2648,7). ismember(2648,10). ismember(2648,12). 
ismember(2649,1). ismember(2649,4). ismember(2649,5). ismember(2649,7). ismember(2649,10). ismember(2649,12). 
ismember(2650,2). ismember(2650,4). ismember(2650,5). ismember(2650,7). ismember(2650,10). ismember(2650,12). 
ismember(2651,1). ismember(2651,2). ismember(2651,4). ismember(2651,5). ismember(2651,7). ismember(2651,10). ismember(2651,12). 
ismember(2652,3). ismember(2652,4). ismember(2652,5). ismember(2652,7). ismember(2652,10). ismember(2652,12). 
ismember(2653,1). ismember(2653,3). ismember(2653,4). ismember(2653,5). ismember(2653,7). ismember(2653,10). ismember(2653,12). 
ismember(2654,2). ismember(2654,3). ismember(2654,4). ismember(2654,5). ismember(2654,7). ismember(2654,10). ismember(2654,12). 
ismember(2655,1). ismember(2655,2). ismember(2655,3). ismember(2655,4). ismember(2655,5). ismember(2655,7). ismember(2655,10). ismember(2655,12). 
ismember(2656,6). ismember(2656,7). ismember(2656,10). ismember(2656,12). 
ismember(2657,1). ismember(2657,6). ismember(2657,7). ismember(2657,10). ismember(2657,12). 
ismember(2658,2). ismember(2658,6). ismember(2658,7). ismember(2658,10). ismember(2658,12). 
ismember(2659,1). ismember(2659,2). ismember(2659,6). ismember(2659,7). ismember(2659,10). ismember(2659,12). 
ismember(2660,3). ismember(2660,6). ismember(2660,7). ismember(2660,10). ismember(2660,12). 
ismember(2661,1). ismember(2661,3). ismember(2661,6). ismember(2661,7). ismember(2661,10). ismember(2661,12). 
ismember(2662,2). ismember(2662,3). ismember(2662,6). ismember(2662,7). ismember(2662,10). ismember(2662,12). 
ismember(2663,1). ismember(2663,2). ismember(2663,3). ismember(2663,6). ismember(2663,7). ismember(2663,10). ismember(2663,12). 
ismember(2664,4). ismember(2664,6). ismember(2664,7). ismember(2664,10). ismember(2664,12). 
ismember(2665,1). ismember(2665,4). ismember(2665,6). ismember(2665,7). ismember(2665,10). ismember(2665,12). 
ismember(2666,2). ismember(2666,4). ismember(2666,6). ismember(2666,7). ismember(2666,10). ismember(2666,12). 
ismember(2667,1). ismember(2667,2). ismember(2667,4). ismember(2667,6). ismember(2667,7). ismember(2667,10). ismember(2667,12). 
ismember(2668,3). ismember(2668,4). ismember(2668,6). ismember(2668,7). ismember(2668,10). ismember(2668,12). 
ismember(2669,1). ismember(2669,3). ismember(2669,4). ismember(2669,6). ismember(2669,7). ismember(2669,10). ismember(2669,12). 
ismember(2670,2). ismember(2670,3). ismember(2670,4). ismember(2670,6). ismember(2670,7). ismember(2670,10). ismember(2670,12). 
ismember(2671,1). ismember(2671,2). ismember(2671,3). ismember(2671,4). ismember(2671,6). ismember(2671,7). ismember(2671,10). ismember(2671,12). 
ismember(2672,5). ismember(2672,6). ismember(2672,7). ismember(2672,10). ismember(2672,12). 
ismember(2673,1). ismember(2673,5). ismember(2673,6). ismember(2673,7). ismember(2673,10). ismember(2673,12). 
ismember(2674,2). ismember(2674,5). ismember(2674,6). ismember(2674,7). ismember(2674,10). ismember(2674,12). 
ismember(2675,1). ismember(2675,2). ismember(2675,5). ismember(2675,6). ismember(2675,7). ismember(2675,10). ismember(2675,12). 
ismember(2676,3). ismember(2676,5). ismember(2676,6). ismember(2676,7). ismember(2676,10). ismember(2676,12). 
ismember(2677,1). ismember(2677,3). ismember(2677,5). ismember(2677,6). ismember(2677,7). ismember(2677,10). ismember(2677,12). 
ismember(2678,2). ismember(2678,3). ismember(2678,5). ismember(2678,6). ismember(2678,7). ismember(2678,10). ismember(2678,12). 
ismember(2679,1). ismember(2679,2). ismember(2679,3). ismember(2679,5). ismember(2679,6). ismember(2679,7). ismember(2679,10). ismember(2679,12). 
ismember(2680,4). ismember(2680,5). ismember(2680,6). ismember(2680,7). ismember(2680,10). ismember(2680,12). 
ismember(2681,1). ismember(2681,4). ismember(2681,5). ismember(2681,6). ismember(2681,7). ismember(2681,10). ismember(2681,12). 
ismember(2682,2). ismember(2682,4). ismember(2682,5). ismember(2682,6). ismember(2682,7). ismember(2682,10). ismember(2682,12). 
ismember(2683,1). ismember(2683,2). ismember(2683,4). ismember(2683,5). ismember(2683,6). ismember(2683,7). ismember(2683,10). ismember(2683,12). 
ismember(2684,3). ismember(2684,4). ismember(2684,5). ismember(2684,6). ismember(2684,7). ismember(2684,10). ismember(2684,12). 
ismember(2685,1). ismember(2685,3). ismember(2685,4). ismember(2685,5). ismember(2685,6). ismember(2685,7). ismember(2685,10). ismember(2685,12). 
ismember(2686,2). ismember(2686,3). ismember(2686,4). ismember(2686,5). ismember(2686,6). ismember(2686,7). ismember(2686,10). ismember(2686,12). 
ismember(2687,1). ismember(2687,2). ismember(2687,3). ismember(2687,4). ismember(2687,5). ismember(2687,6). ismember(2687,7). ismember(2687,10). ismember(2687,12). 
ismember(2688,8). ismember(2688,10). ismember(2688,12). 
ismember(2689,1). ismember(2689,8). ismember(2689,10). ismember(2689,12). 
ismember(2690,2). ismember(2690,8). ismember(2690,10). ismember(2690,12). 
ismember(2691,1). ismember(2691,2). ismember(2691,8). ismember(2691,10). ismember(2691,12). 
ismember(2692,3). ismember(2692,8). ismember(2692,10). ismember(2692,12). 
ismember(2693,1). ismember(2693,3). ismember(2693,8). ismember(2693,10). ismember(2693,12). 
ismember(2694,2). ismember(2694,3). ismember(2694,8). ismember(2694,10). ismember(2694,12). 
ismember(2695,1). ismember(2695,2). ismember(2695,3). ismember(2695,8). ismember(2695,10). ismember(2695,12). 
ismember(2696,4). ismember(2696,8). ismember(2696,10). ismember(2696,12). 
ismember(2697,1). ismember(2697,4). ismember(2697,8). ismember(2697,10). ismember(2697,12). 
ismember(2698,2). ismember(2698,4). ismember(2698,8). ismember(2698,10). ismember(2698,12). 
ismember(2699,1). ismember(2699,2). ismember(2699,4). ismember(2699,8). ismember(2699,10). ismember(2699,12). 
ismember(2700,3). ismember(2700,4). ismember(2700,8). ismember(2700,10). ismember(2700,12). 
ismember(2701,1). ismember(2701,3). ismember(2701,4). ismember(2701,8). ismember(2701,10). ismember(2701,12). 
ismember(2702,2). ismember(2702,3). ismember(2702,4). ismember(2702,8). ismember(2702,10). ismember(2702,12). 
ismember(2703,1). ismember(2703,2). ismember(2703,3). ismember(2703,4). ismember(2703,8). ismember(2703,10). ismember(2703,12). 
ismember(2704,5). ismember(2704,8). ismember(2704,10). ismember(2704,12). 
ismember(2705,1). ismember(2705,5). ismember(2705,8). ismember(2705,10). ismember(2705,12). 
ismember(2706,2). ismember(2706,5). ismember(2706,8). ismember(2706,10). ismember(2706,12). 
ismember(2707,1). ismember(2707,2). ismember(2707,5). ismember(2707,8). ismember(2707,10). ismember(2707,12). 
ismember(2708,3). ismember(2708,5). ismember(2708,8). ismember(2708,10). ismember(2708,12). 
ismember(2709,1). ismember(2709,3). ismember(2709,5). ismember(2709,8). ismember(2709,10). ismember(2709,12). 
ismember(2710,2). ismember(2710,3). ismember(2710,5). ismember(2710,8). ismember(2710,10). ismember(2710,12). 
ismember(2711,1). ismember(2711,2). ismember(2711,3). ismember(2711,5). ismember(2711,8). ismember(2711,10). ismember(2711,12). 
ismember(2712,4). ismember(2712,5). ismember(2712,8). ismember(2712,10). ismember(2712,12). 
ismember(2713,1). ismember(2713,4). ismember(2713,5). ismember(2713,8). ismember(2713,10). ismember(2713,12). 
ismember(2714,2). ismember(2714,4). ismember(2714,5). ismember(2714,8). ismember(2714,10). ismember(2714,12). 
ismember(2715,1). ismember(2715,2). ismember(2715,4). ismember(2715,5). ismember(2715,8). ismember(2715,10). ismember(2715,12). 
ismember(2716,3). ismember(2716,4). ismember(2716,5). ismember(2716,8). ismember(2716,10). ismember(2716,12). 
ismember(2717,1). ismember(2717,3). ismember(2717,4). ismember(2717,5). ismember(2717,8). ismember(2717,10). ismember(2717,12). 
ismember(2718,2). ismember(2718,3). ismember(2718,4). ismember(2718,5). ismember(2718,8). ismember(2718,10). ismember(2718,12). 
ismember(2719,1). ismember(2719,2). ismember(2719,3). ismember(2719,4). ismember(2719,5). ismember(2719,8). ismember(2719,10). ismember(2719,12). 
ismember(2720,6). ismember(2720,8). ismember(2720,10). ismember(2720,12). 
ismember(2721,1). ismember(2721,6). ismember(2721,8). ismember(2721,10). ismember(2721,12). 
ismember(2722,2). ismember(2722,6). ismember(2722,8). ismember(2722,10). ismember(2722,12). 
ismember(2723,1). ismember(2723,2). ismember(2723,6). ismember(2723,8). ismember(2723,10). ismember(2723,12). 
ismember(2724,3). ismember(2724,6). ismember(2724,8). ismember(2724,10). ismember(2724,12). 
ismember(2725,1). ismember(2725,3). ismember(2725,6). ismember(2725,8). ismember(2725,10). ismember(2725,12). 
ismember(2726,2). ismember(2726,3). ismember(2726,6). ismember(2726,8). ismember(2726,10). ismember(2726,12). 
ismember(2727,1). ismember(2727,2). ismember(2727,3). ismember(2727,6). ismember(2727,8). ismember(2727,10). ismember(2727,12). 
ismember(2728,4). ismember(2728,6). ismember(2728,8). ismember(2728,10). ismember(2728,12). 
ismember(2729,1). ismember(2729,4). ismember(2729,6). ismember(2729,8). ismember(2729,10). ismember(2729,12). 
ismember(2730,2). ismember(2730,4). ismember(2730,6). ismember(2730,8). ismember(2730,10). ismember(2730,12). 
ismember(2731,1). ismember(2731,2). ismember(2731,4). ismember(2731,6). ismember(2731,8). ismember(2731,10). ismember(2731,12). 
ismember(2732,3). ismember(2732,4). ismember(2732,6). ismember(2732,8). ismember(2732,10). ismember(2732,12). 
ismember(2733,1). ismember(2733,3). ismember(2733,4). ismember(2733,6). ismember(2733,8). ismember(2733,10). ismember(2733,12). 
ismember(2734,2). ismember(2734,3). ismember(2734,4). ismember(2734,6). ismember(2734,8). ismember(2734,10). ismember(2734,12). 
ismember(2735,1). ismember(2735,2). ismember(2735,3). ismember(2735,4). ismember(2735,6). ismember(2735,8). ismember(2735,10). ismember(2735,12). 
ismember(2736,5). ismember(2736,6). ismember(2736,8). ismember(2736,10). ismember(2736,12). 
ismember(2737,1). ismember(2737,5). ismember(2737,6). ismember(2737,8). ismember(2737,10). ismember(2737,12). 
ismember(2738,2). ismember(2738,5). ismember(2738,6). ismember(2738,8). ismember(2738,10). ismember(2738,12). 
ismember(2739,1). ismember(2739,2). ismember(2739,5). ismember(2739,6). ismember(2739,8). ismember(2739,10). ismember(2739,12). 
ismember(2740,3). ismember(2740,5). ismember(2740,6). ismember(2740,8). ismember(2740,10). ismember(2740,12). 
ismember(2741,1). ismember(2741,3). ismember(2741,5). ismember(2741,6). ismember(2741,8). ismember(2741,10). ismember(2741,12). 
ismember(2742,2). ismember(2742,3). ismember(2742,5). ismember(2742,6). ismember(2742,8). ismember(2742,10). ismember(2742,12). 
ismember(2743,1). ismember(2743,2). ismember(2743,3). ismember(2743,5). ismember(2743,6). ismember(2743,8). ismember(2743,10). ismember(2743,12). 
ismember(2744,4). ismember(2744,5). ismember(2744,6). ismember(2744,8). ismember(2744,10). ismember(2744,12). 
ismember(2745,1). ismember(2745,4). ismember(2745,5). ismember(2745,6). ismember(2745,8). ismember(2745,10). ismember(2745,12). 
ismember(2746,2). ismember(2746,4). ismember(2746,5). ismember(2746,6). ismember(2746,8). ismember(2746,10). ismember(2746,12). 
ismember(2747,1). ismember(2747,2). ismember(2747,4). ismember(2747,5). ismember(2747,6). ismember(2747,8). ismember(2747,10). ismember(2747,12). 
ismember(2748,3). ismember(2748,4). ismember(2748,5). ismember(2748,6). ismember(2748,8). ismember(2748,10). ismember(2748,12). 
ismember(2749,1). ismember(2749,3). ismember(2749,4). ismember(2749,5). ismember(2749,6). ismember(2749,8). ismember(2749,10). ismember(2749,12). 
ismember(2750,2). ismember(2750,3). ismember(2750,4). ismember(2750,5). ismember(2750,6). ismember(2750,8). ismember(2750,10). ismember(2750,12). 
ismember(2751,1). ismember(2751,2). ismember(2751,3). ismember(2751,4). ismember(2751,5). ismember(2751,6). ismember(2751,8). ismember(2751,10). ismember(2751,12). 
ismember(2752,7). ismember(2752,8). ismember(2752,10). ismember(2752,12). 
ismember(2753,1). ismember(2753,7). ismember(2753,8). ismember(2753,10). ismember(2753,12). 
ismember(2754,2). ismember(2754,7). ismember(2754,8). ismember(2754,10). ismember(2754,12). 
ismember(2755,1). ismember(2755,2). ismember(2755,7). ismember(2755,8). ismember(2755,10). ismember(2755,12). 
ismember(2756,3). ismember(2756,7). ismember(2756,8). ismember(2756,10). ismember(2756,12). 
ismember(2757,1). ismember(2757,3). ismember(2757,7). ismember(2757,8). ismember(2757,10). ismember(2757,12). 
ismember(2758,2). ismember(2758,3). ismember(2758,7). ismember(2758,8). ismember(2758,10). ismember(2758,12). 
ismember(2759,1). ismember(2759,2). ismember(2759,3). ismember(2759,7). ismember(2759,8). ismember(2759,10). ismember(2759,12). 
ismember(2760,4). ismember(2760,7). ismember(2760,8). ismember(2760,10). ismember(2760,12). 
ismember(2761,1). ismember(2761,4). ismember(2761,7). ismember(2761,8). ismember(2761,10). ismember(2761,12). 
ismember(2762,2). ismember(2762,4). ismember(2762,7). ismember(2762,8). ismember(2762,10). ismember(2762,12). 
ismember(2763,1). ismember(2763,2). ismember(2763,4). ismember(2763,7). ismember(2763,8). ismember(2763,10). ismember(2763,12). 
ismember(2764,3). ismember(2764,4). ismember(2764,7). ismember(2764,8). ismember(2764,10). ismember(2764,12). 
ismember(2765,1). ismember(2765,3). ismember(2765,4). ismember(2765,7). ismember(2765,8). ismember(2765,10). ismember(2765,12). 
ismember(2766,2). ismember(2766,3). ismember(2766,4). ismember(2766,7). ismember(2766,8). ismember(2766,10). ismember(2766,12). 
ismember(2767,1). ismember(2767,2). ismember(2767,3). ismember(2767,4). ismember(2767,7). ismember(2767,8). ismember(2767,10). ismember(2767,12). 
ismember(2768,5). ismember(2768,7). ismember(2768,8). ismember(2768,10). ismember(2768,12). 
ismember(2769,1). ismember(2769,5). ismember(2769,7). ismember(2769,8). ismember(2769,10). ismember(2769,12). 
ismember(2770,2). ismember(2770,5). ismember(2770,7). ismember(2770,8). ismember(2770,10). ismember(2770,12). 
ismember(2771,1). ismember(2771,2). ismember(2771,5). ismember(2771,7). ismember(2771,8). ismember(2771,10). ismember(2771,12). 
ismember(2772,3). ismember(2772,5). ismember(2772,7). ismember(2772,8). ismember(2772,10). ismember(2772,12). 
ismember(2773,1). ismember(2773,3). ismember(2773,5). ismember(2773,7). ismember(2773,8). ismember(2773,10). ismember(2773,12). 
ismember(2774,2). ismember(2774,3). ismember(2774,5). ismember(2774,7). ismember(2774,8). ismember(2774,10). ismember(2774,12). 
ismember(2775,1). ismember(2775,2). ismember(2775,3). ismember(2775,5). ismember(2775,7). ismember(2775,8). ismember(2775,10). ismember(2775,12). 
ismember(2776,4). ismember(2776,5). ismember(2776,7). ismember(2776,8). ismember(2776,10). ismember(2776,12). 
ismember(2777,1). ismember(2777,4). ismember(2777,5). ismember(2777,7). ismember(2777,8). ismember(2777,10). ismember(2777,12). 
ismember(2778,2). ismember(2778,4). ismember(2778,5). ismember(2778,7). ismember(2778,8). ismember(2778,10). ismember(2778,12). 
ismember(2779,1). ismember(2779,2). ismember(2779,4). ismember(2779,5). ismember(2779,7). ismember(2779,8). ismember(2779,10). ismember(2779,12). 
ismember(2780,3). ismember(2780,4). ismember(2780,5). ismember(2780,7). ismember(2780,8). ismember(2780,10). ismember(2780,12). 
ismember(2781,1). ismember(2781,3). ismember(2781,4). ismember(2781,5). ismember(2781,7). ismember(2781,8). ismember(2781,10). ismember(2781,12). 
ismember(2782,2). ismember(2782,3). ismember(2782,4). ismember(2782,5). ismember(2782,7). ismember(2782,8). ismember(2782,10). ismember(2782,12). 
ismember(2783,1). ismember(2783,2). ismember(2783,3). ismember(2783,4). ismember(2783,5). ismember(2783,7). ismember(2783,8). ismember(2783,10). ismember(2783,12). 
ismember(2784,6). ismember(2784,7). ismember(2784,8). ismember(2784,10). ismember(2784,12). 
ismember(2785,1). ismember(2785,6). ismember(2785,7). ismember(2785,8). ismember(2785,10). ismember(2785,12). 
ismember(2786,2). ismember(2786,6). ismember(2786,7). ismember(2786,8). ismember(2786,10). ismember(2786,12). 
ismember(2787,1). ismember(2787,2). ismember(2787,6). ismember(2787,7). ismember(2787,8). ismember(2787,10). ismember(2787,12). 
ismember(2788,3). ismember(2788,6). ismember(2788,7). ismember(2788,8). ismember(2788,10). ismember(2788,12). 
ismember(2789,1). ismember(2789,3). ismember(2789,6). ismember(2789,7). ismember(2789,8). ismember(2789,10). ismember(2789,12). 
ismember(2790,2). ismember(2790,3). ismember(2790,6). ismember(2790,7). ismember(2790,8). ismember(2790,10). ismember(2790,12). 
ismember(2791,1). ismember(2791,2). ismember(2791,3). ismember(2791,6). ismember(2791,7). ismember(2791,8). ismember(2791,10). ismember(2791,12). 
ismember(2792,4). ismember(2792,6). ismember(2792,7). ismember(2792,8). ismember(2792,10). ismember(2792,12). 
ismember(2793,1). ismember(2793,4). ismember(2793,6). ismember(2793,7). ismember(2793,8). ismember(2793,10). ismember(2793,12). 
ismember(2794,2). ismember(2794,4). ismember(2794,6). ismember(2794,7). ismember(2794,8). ismember(2794,10). ismember(2794,12). 
ismember(2795,1). ismember(2795,2). ismember(2795,4). ismember(2795,6). ismember(2795,7). ismember(2795,8). ismember(2795,10). ismember(2795,12). 
ismember(2796,3). ismember(2796,4). ismember(2796,6). ismember(2796,7). ismember(2796,8). ismember(2796,10). ismember(2796,12). 
ismember(2797,1). ismember(2797,3). ismember(2797,4). ismember(2797,6). ismember(2797,7). ismember(2797,8). ismember(2797,10). ismember(2797,12). 
ismember(2798,2). ismember(2798,3). ismember(2798,4). ismember(2798,6). ismember(2798,7). ismember(2798,8). ismember(2798,10). ismember(2798,12). 
ismember(2799,1). ismember(2799,2). ismember(2799,3). ismember(2799,4). ismember(2799,6). ismember(2799,7). ismember(2799,8). ismember(2799,10). ismember(2799,12). 
ismember(2800,5). ismember(2800,6). ismember(2800,7). ismember(2800,8). ismember(2800,10). ismember(2800,12). 
ismember(2801,1). ismember(2801,5). ismember(2801,6). ismember(2801,7). ismember(2801,8). ismember(2801,10). ismember(2801,12). 
ismember(2802,2). ismember(2802,5). ismember(2802,6). ismember(2802,7). ismember(2802,8). ismember(2802,10). ismember(2802,12). 
ismember(2803,1). ismember(2803,2). ismember(2803,5). ismember(2803,6). ismember(2803,7). ismember(2803,8). ismember(2803,10). ismember(2803,12). 
ismember(2804,3). ismember(2804,5). ismember(2804,6). ismember(2804,7). ismember(2804,8). ismember(2804,10). ismember(2804,12). 
ismember(2805,1). ismember(2805,3). ismember(2805,5). ismember(2805,6). ismember(2805,7). ismember(2805,8). ismember(2805,10). ismember(2805,12). 
ismember(2806,2). ismember(2806,3). ismember(2806,5). ismember(2806,6). ismember(2806,7). ismember(2806,8). ismember(2806,10). ismember(2806,12). 
ismember(2807,1). ismember(2807,2). ismember(2807,3). ismember(2807,5). ismember(2807,6). ismember(2807,7). ismember(2807,8). ismember(2807,10). ismember(2807,12). 
ismember(2808,4). ismember(2808,5). ismember(2808,6). ismember(2808,7). ismember(2808,8). ismember(2808,10). ismember(2808,12). 
ismember(2809,1). ismember(2809,4). ismember(2809,5). ismember(2809,6). ismember(2809,7). ismember(2809,8). ismember(2809,10). ismember(2809,12). 
ismember(2810,2). ismember(2810,4). ismember(2810,5). ismember(2810,6). ismember(2810,7). ismember(2810,8). ismember(2810,10). ismember(2810,12). 
ismember(2811,1). ismember(2811,2). ismember(2811,4). ismember(2811,5). ismember(2811,6). ismember(2811,7). ismember(2811,8). ismember(2811,10). ismember(2811,12). 
ismember(2812,3). ismember(2812,4). ismember(2812,5). ismember(2812,6). ismember(2812,7). ismember(2812,8). ismember(2812,10). ismember(2812,12). 
ismember(2813,1). ismember(2813,3). ismember(2813,4). ismember(2813,5). ismember(2813,6). ismember(2813,7). ismember(2813,8). ismember(2813,10). ismember(2813,12). 
ismember(2814,2). ismember(2814,3). ismember(2814,4). ismember(2814,5). ismember(2814,6). ismember(2814,7). ismember(2814,8). ismember(2814,10). ismember(2814,12). 
ismember(2815,1). ismember(2815,2). ismember(2815,3). ismember(2815,4). ismember(2815,5). ismember(2815,6). ismember(2815,7). ismember(2815,8). ismember(2815,10). ismember(2815,12). 
ismember(2816,9). ismember(2816,10). ismember(2816,12). 
ismember(2817,1). ismember(2817,9). ismember(2817,10). ismember(2817,12). 
ismember(2818,2). ismember(2818,9). ismember(2818,10). ismember(2818,12). 
ismember(2819,1). ismember(2819,2). ismember(2819,9). ismember(2819,10). ismember(2819,12). 
ismember(2820,3). ismember(2820,9). ismember(2820,10). ismember(2820,12). 
ismember(2821,1). ismember(2821,3). ismember(2821,9). ismember(2821,10). ismember(2821,12). 
ismember(2822,2). ismember(2822,3). ismember(2822,9). ismember(2822,10). ismember(2822,12). 
ismember(2823,1). ismember(2823,2). ismember(2823,3). ismember(2823,9). ismember(2823,10). ismember(2823,12). 
ismember(2824,4). ismember(2824,9). ismember(2824,10). ismember(2824,12). 
ismember(2825,1). ismember(2825,4). ismember(2825,9). ismember(2825,10). ismember(2825,12). 
ismember(2826,2). ismember(2826,4). ismember(2826,9). ismember(2826,10). ismember(2826,12). 
ismember(2827,1). ismember(2827,2). ismember(2827,4). ismember(2827,9). ismember(2827,10). ismember(2827,12). 
ismember(2828,3). ismember(2828,4). ismember(2828,9). ismember(2828,10). ismember(2828,12). 
ismember(2829,1). ismember(2829,3). ismember(2829,4). ismember(2829,9). ismember(2829,10). ismember(2829,12). 
ismember(2830,2). ismember(2830,3). ismember(2830,4). ismember(2830,9). ismember(2830,10). ismember(2830,12). 
ismember(2831,1). ismember(2831,2). ismember(2831,3). ismember(2831,4). ismember(2831,9). ismember(2831,10). ismember(2831,12). 
ismember(2832,5). ismember(2832,9). ismember(2832,10). ismember(2832,12). 
ismember(2833,1). ismember(2833,5). ismember(2833,9). ismember(2833,10). ismember(2833,12). 
ismember(2834,2). ismember(2834,5). ismember(2834,9). ismember(2834,10). ismember(2834,12). 
ismember(2835,1). ismember(2835,2). ismember(2835,5). ismember(2835,9). ismember(2835,10). ismember(2835,12). 
ismember(2836,3). ismember(2836,5). ismember(2836,9). ismember(2836,10). ismember(2836,12). 
ismember(2837,1). ismember(2837,3). ismember(2837,5). ismember(2837,9). ismember(2837,10). ismember(2837,12). 
ismember(2838,2). ismember(2838,3). ismember(2838,5). ismember(2838,9). ismember(2838,10). ismember(2838,12). 
ismember(2839,1). ismember(2839,2). ismember(2839,3). ismember(2839,5). ismember(2839,9). ismember(2839,10). ismember(2839,12). 
ismember(2840,4). ismember(2840,5). ismember(2840,9). ismember(2840,10). ismember(2840,12). 
ismember(2841,1). ismember(2841,4). ismember(2841,5). ismember(2841,9). ismember(2841,10). ismember(2841,12). 
ismember(2842,2). ismember(2842,4). ismember(2842,5). ismember(2842,9). ismember(2842,10). ismember(2842,12). 
ismember(2843,1). ismember(2843,2). ismember(2843,4). ismember(2843,5). ismember(2843,9). ismember(2843,10). ismember(2843,12). 
ismember(2844,3). ismember(2844,4). ismember(2844,5). ismember(2844,9). ismember(2844,10). ismember(2844,12). 
ismember(2845,1). ismember(2845,3). ismember(2845,4). ismember(2845,5). ismember(2845,9). ismember(2845,10). ismember(2845,12). 
ismember(2846,2). ismember(2846,3). ismember(2846,4). ismember(2846,5). ismember(2846,9). ismember(2846,10). ismember(2846,12). 
ismember(2847,1). ismember(2847,2). ismember(2847,3). ismember(2847,4). ismember(2847,5). ismember(2847,9). ismember(2847,10). ismember(2847,12). 
ismember(2848,6). ismember(2848,9). ismember(2848,10). ismember(2848,12). 
ismember(2849,1). ismember(2849,6). ismember(2849,9). ismember(2849,10). ismember(2849,12). 
ismember(2850,2). ismember(2850,6). ismember(2850,9). ismember(2850,10). ismember(2850,12). 
ismember(2851,1). ismember(2851,2). ismember(2851,6). ismember(2851,9). ismember(2851,10). ismember(2851,12). 
ismember(2852,3). ismember(2852,6). ismember(2852,9). ismember(2852,10). ismember(2852,12). 
ismember(2853,1). ismember(2853,3). ismember(2853,6). ismember(2853,9). ismember(2853,10). ismember(2853,12). 
ismember(2854,2). ismember(2854,3). ismember(2854,6). ismember(2854,9). ismember(2854,10). ismember(2854,12). 
ismember(2855,1). ismember(2855,2). ismember(2855,3). ismember(2855,6). ismember(2855,9). ismember(2855,10). ismember(2855,12). 
ismember(2856,4). ismember(2856,6). ismember(2856,9). ismember(2856,10). ismember(2856,12). 
ismember(2857,1). ismember(2857,4). ismember(2857,6). ismember(2857,9). ismember(2857,10). ismember(2857,12). 
ismember(2858,2). ismember(2858,4). ismember(2858,6). ismember(2858,9). ismember(2858,10). ismember(2858,12). 
ismember(2859,1). ismember(2859,2). ismember(2859,4). ismember(2859,6). ismember(2859,9). ismember(2859,10). ismember(2859,12). 
ismember(2860,3). ismember(2860,4). ismember(2860,6). ismember(2860,9). ismember(2860,10). ismember(2860,12). 
ismember(2861,1). ismember(2861,3). ismember(2861,4). ismember(2861,6). ismember(2861,9). ismember(2861,10). ismember(2861,12). 
ismember(2862,2). ismember(2862,3). ismember(2862,4). ismember(2862,6). ismember(2862,9). ismember(2862,10). ismember(2862,12). 
ismember(2863,1). ismember(2863,2). ismember(2863,3). ismember(2863,4). ismember(2863,6). ismember(2863,9). ismember(2863,10). ismember(2863,12). 
ismember(2864,5). ismember(2864,6). ismember(2864,9). ismember(2864,10). ismember(2864,12). 
ismember(2865,1). ismember(2865,5). ismember(2865,6). ismember(2865,9). ismember(2865,10). ismember(2865,12). 
ismember(2866,2). ismember(2866,5). ismember(2866,6). ismember(2866,9). ismember(2866,10). ismember(2866,12). 
ismember(2867,1). ismember(2867,2). ismember(2867,5). ismember(2867,6). ismember(2867,9). ismember(2867,10). ismember(2867,12). 
ismember(2868,3). ismember(2868,5). ismember(2868,6). ismember(2868,9). ismember(2868,10). ismember(2868,12). 
ismember(2869,1). ismember(2869,3). ismember(2869,5). ismember(2869,6). ismember(2869,9). ismember(2869,10). ismember(2869,12). 
ismember(2870,2). ismember(2870,3). ismember(2870,5). ismember(2870,6). ismember(2870,9). ismember(2870,10). ismember(2870,12). 
ismember(2871,1). ismember(2871,2). ismember(2871,3). ismember(2871,5). ismember(2871,6). ismember(2871,9). ismember(2871,10). ismember(2871,12). 
ismember(2872,4). ismember(2872,5). ismember(2872,6). ismember(2872,9). ismember(2872,10). ismember(2872,12). 
ismember(2873,1). ismember(2873,4). ismember(2873,5). ismember(2873,6). ismember(2873,9). ismember(2873,10). ismember(2873,12). 
ismember(2874,2). ismember(2874,4). ismember(2874,5). ismember(2874,6). ismember(2874,9). ismember(2874,10). ismember(2874,12). 
ismember(2875,1). ismember(2875,2). ismember(2875,4). ismember(2875,5). ismember(2875,6). ismember(2875,9). ismember(2875,10). ismember(2875,12). 
ismember(2876,3). ismember(2876,4). ismember(2876,5). ismember(2876,6). ismember(2876,9). ismember(2876,10). ismember(2876,12). 
ismember(2877,1). ismember(2877,3). ismember(2877,4). ismember(2877,5). ismember(2877,6). ismember(2877,9). ismember(2877,10). ismember(2877,12). 
ismember(2878,2). ismember(2878,3). ismember(2878,4). ismember(2878,5). ismember(2878,6). ismember(2878,9). ismember(2878,10). ismember(2878,12). 
ismember(2879,1). ismember(2879,2). ismember(2879,3). ismember(2879,4). ismember(2879,5). ismember(2879,6). ismember(2879,9). ismember(2879,10). ismember(2879,12). 
ismember(2880,7). ismember(2880,9). ismember(2880,10). ismember(2880,12). 
ismember(2881,1). ismember(2881,7). ismember(2881,9). ismember(2881,10). ismember(2881,12). 
ismember(2882,2). ismember(2882,7). ismember(2882,9). ismember(2882,10). ismember(2882,12). 
ismember(2883,1). ismember(2883,2). ismember(2883,7). ismember(2883,9). ismember(2883,10). ismember(2883,12). 
ismember(2884,3). ismember(2884,7). ismember(2884,9). ismember(2884,10). ismember(2884,12). 
ismember(2885,1). ismember(2885,3). ismember(2885,7). ismember(2885,9). ismember(2885,10). ismember(2885,12). 
ismember(2886,2). ismember(2886,3). ismember(2886,7). ismember(2886,9). ismember(2886,10). ismember(2886,12). 
ismember(2887,1). ismember(2887,2). ismember(2887,3). ismember(2887,7). ismember(2887,9). ismember(2887,10). ismember(2887,12). 
ismember(2888,4). ismember(2888,7). ismember(2888,9). ismember(2888,10). ismember(2888,12). 
ismember(2889,1). ismember(2889,4). ismember(2889,7). ismember(2889,9). ismember(2889,10). ismember(2889,12). 
ismember(2890,2). ismember(2890,4). ismember(2890,7). ismember(2890,9). ismember(2890,10). ismember(2890,12). 
ismember(2891,1). ismember(2891,2). ismember(2891,4). ismember(2891,7). ismember(2891,9). ismember(2891,10). ismember(2891,12). 
ismember(2892,3). ismember(2892,4). ismember(2892,7). ismember(2892,9). ismember(2892,10). ismember(2892,12). 
ismember(2893,1). ismember(2893,3). ismember(2893,4). ismember(2893,7). ismember(2893,9). ismember(2893,10). ismember(2893,12). 
ismember(2894,2). ismember(2894,3). ismember(2894,4). ismember(2894,7). ismember(2894,9). ismember(2894,10). ismember(2894,12). 
ismember(2895,1). ismember(2895,2). ismember(2895,3). ismember(2895,4). ismember(2895,7). ismember(2895,9). ismember(2895,10). ismember(2895,12). 
ismember(2896,5). ismember(2896,7). ismember(2896,9). ismember(2896,10). ismember(2896,12). 
ismember(2897,1). ismember(2897,5). ismember(2897,7). ismember(2897,9). ismember(2897,10). ismember(2897,12). 
ismember(2898,2). ismember(2898,5). ismember(2898,7). ismember(2898,9). ismember(2898,10). ismember(2898,12). 
ismember(2899,1). ismember(2899,2). ismember(2899,5). ismember(2899,7). ismember(2899,9). ismember(2899,10). ismember(2899,12). 
ismember(2900,3). ismember(2900,5). ismember(2900,7). ismember(2900,9). ismember(2900,10). ismember(2900,12). 
ismember(2901,1). ismember(2901,3). ismember(2901,5). ismember(2901,7). ismember(2901,9). ismember(2901,10). ismember(2901,12). 
ismember(2902,2). ismember(2902,3). ismember(2902,5). ismember(2902,7). ismember(2902,9). ismember(2902,10). ismember(2902,12). 
ismember(2903,1). ismember(2903,2). ismember(2903,3). ismember(2903,5). ismember(2903,7). ismember(2903,9). ismember(2903,10). ismember(2903,12). 
ismember(2904,4). ismember(2904,5). ismember(2904,7). ismember(2904,9). ismember(2904,10). ismember(2904,12). 
ismember(2905,1). ismember(2905,4). ismember(2905,5). ismember(2905,7). ismember(2905,9). ismember(2905,10). ismember(2905,12). 
ismember(2906,2). ismember(2906,4). ismember(2906,5). ismember(2906,7). ismember(2906,9). ismember(2906,10). ismember(2906,12). 
ismember(2907,1). ismember(2907,2). ismember(2907,4). ismember(2907,5). ismember(2907,7). ismember(2907,9). ismember(2907,10). ismember(2907,12). 
ismember(2908,3). ismember(2908,4). ismember(2908,5). ismember(2908,7). ismember(2908,9). ismember(2908,10). ismember(2908,12). 
ismember(2909,1). ismember(2909,3). ismember(2909,4). ismember(2909,5). ismember(2909,7). ismember(2909,9). ismember(2909,10). ismember(2909,12). 
ismember(2910,2). ismember(2910,3). ismember(2910,4). ismember(2910,5). ismember(2910,7). ismember(2910,9). ismember(2910,10). ismember(2910,12). 
ismember(2911,1). ismember(2911,2). ismember(2911,3). ismember(2911,4). ismember(2911,5). ismember(2911,7). ismember(2911,9). ismember(2911,10). ismember(2911,12). 
ismember(2912,6). ismember(2912,7). ismember(2912,9). ismember(2912,10). ismember(2912,12). 
ismember(2913,1). ismember(2913,6). ismember(2913,7). ismember(2913,9). ismember(2913,10). ismember(2913,12). 
ismember(2914,2). ismember(2914,6). ismember(2914,7). ismember(2914,9). ismember(2914,10). ismember(2914,12). 
ismember(2915,1). ismember(2915,2). ismember(2915,6). ismember(2915,7). ismember(2915,9). ismember(2915,10). ismember(2915,12). 
ismember(2916,3). ismember(2916,6). ismember(2916,7). ismember(2916,9). ismember(2916,10). ismember(2916,12). 
ismember(2917,1). ismember(2917,3). ismember(2917,6). ismember(2917,7). ismember(2917,9). ismember(2917,10). ismember(2917,12). 
ismember(2918,2). ismember(2918,3). ismember(2918,6). ismember(2918,7). ismember(2918,9). ismember(2918,10). ismember(2918,12). 
ismember(2919,1). ismember(2919,2). ismember(2919,3). ismember(2919,6). ismember(2919,7). ismember(2919,9). ismember(2919,10). ismember(2919,12). 
ismember(2920,4). ismember(2920,6). ismember(2920,7). ismember(2920,9). ismember(2920,10). ismember(2920,12). 
ismember(2921,1). ismember(2921,4). ismember(2921,6). ismember(2921,7). ismember(2921,9). ismember(2921,10). ismember(2921,12). 
ismember(2922,2). ismember(2922,4). ismember(2922,6). ismember(2922,7). ismember(2922,9). ismember(2922,10). ismember(2922,12). 
ismember(2923,1). ismember(2923,2). ismember(2923,4). ismember(2923,6). ismember(2923,7). ismember(2923,9). ismember(2923,10). ismember(2923,12). 
ismember(2924,3). ismember(2924,4). ismember(2924,6). ismember(2924,7). ismember(2924,9). ismember(2924,10). ismember(2924,12). 
ismember(2925,1). ismember(2925,3). ismember(2925,4). ismember(2925,6). ismember(2925,7). ismember(2925,9). ismember(2925,10). ismember(2925,12). 
ismember(2926,2). ismember(2926,3). ismember(2926,4). ismember(2926,6). ismember(2926,7). ismember(2926,9). ismember(2926,10). ismember(2926,12). 
ismember(2927,1). ismember(2927,2). ismember(2927,3). ismember(2927,4). ismember(2927,6). ismember(2927,7). ismember(2927,9). ismember(2927,10). ismember(2927,12). 
ismember(2928,5). ismember(2928,6). ismember(2928,7). ismember(2928,9). ismember(2928,10). ismember(2928,12). 
ismember(2929,1). ismember(2929,5). ismember(2929,6). ismember(2929,7). ismember(2929,9). ismember(2929,10). ismember(2929,12). 
ismember(2930,2). ismember(2930,5). ismember(2930,6). ismember(2930,7). ismember(2930,9). ismember(2930,10). ismember(2930,12). 
ismember(2931,1). ismember(2931,2). ismember(2931,5). ismember(2931,6). ismember(2931,7). ismember(2931,9). ismember(2931,10). ismember(2931,12). 
ismember(2932,3). ismember(2932,5). ismember(2932,6). ismember(2932,7). ismember(2932,9). ismember(2932,10). ismember(2932,12). 
ismember(2933,1). ismember(2933,3). ismember(2933,5). ismember(2933,6). ismember(2933,7). ismember(2933,9). ismember(2933,10). ismember(2933,12). 
ismember(2934,2). ismember(2934,3). ismember(2934,5). ismember(2934,6). ismember(2934,7). ismember(2934,9). ismember(2934,10). ismember(2934,12). 
ismember(2935,1). ismember(2935,2). ismember(2935,3). ismember(2935,5). ismember(2935,6). ismember(2935,7). ismember(2935,9). ismember(2935,10). ismember(2935,12). 
ismember(2936,4). ismember(2936,5). ismember(2936,6). ismember(2936,7). ismember(2936,9). ismember(2936,10). ismember(2936,12). 
ismember(2937,1). ismember(2937,4). ismember(2937,5). ismember(2937,6). ismember(2937,7). ismember(2937,9). ismember(2937,10). ismember(2937,12). 
ismember(2938,2). ismember(2938,4). ismember(2938,5). ismember(2938,6). ismember(2938,7). ismember(2938,9). ismember(2938,10). ismember(2938,12). 
ismember(2939,1). ismember(2939,2). ismember(2939,4). ismember(2939,5). ismember(2939,6). ismember(2939,7). ismember(2939,9). ismember(2939,10). ismember(2939,12). 
ismember(2940,3). ismember(2940,4). ismember(2940,5). ismember(2940,6). ismember(2940,7). ismember(2940,9). ismember(2940,10). ismember(2940,12). 
ismember(2941,1). ismember(2941,3). ismember(2941,4). ismember(2941,5). ismember(2941,6). ismember(2941,7). ismember(2941,9). ismember(2941,10). ismember(2941,12). 
ismember(2942,2). ismember(2942,3). ismember(2942,4). ismember(2942,5). ismember(2942,6). ismember(2942,7). ismember(2942,9). ismember(2942,10). ismember(2942,12). 
ismember(2943,1). ismember(2943,2). ismember(2943,3). ismember(2943,4). ismember(2943,5). ismember(2943,6). ismember(2943,7). ismember(2943,9). ismember(2943,10). ismember(2943,12). 
ismember(2944,8). ismember(2944,9). ismember(2944,10). ismember(2944,12). 
ismember(2945,1). ismember(2945,8). ismember(2945,9). ismember(2945,10). ismember(2945,12). 
ismember(2946,2). ismember(2946,8). ismember(2946,9). ismember(2946,10). ismember(2946,12). 
ismember(2947,1). ismember(2947,2). ismember(2947,8). ismember(2947,9). ismember(2947,10). ismember(2947,12). 
ismember(2948,3). ismember(2948,8). ismember(2948,9). ismember(2948,10). ismember(2948,12). 
ismember(2949,1). ismember(2949,3). ismember(2949,8). ismember(2949,9). ismember(2949,10). ismember(2949,12). 
ismember(2950,2). ismember(2950,3). ismember(2950,8). ismember(2950,9). ismember(2950,10). ismember(2950,12). 
ismember(2951,1). ismember(2951,2). ismember(2951,3). ismember(2951,8). ismember(2951,9). ismember(2951,10). ismember(2951,12). 
ismember(2952,4). ismember(2952,8). ismember(2952,9). ismember(2952,10). ismember(2952,12). 
ismember(2953,1). ismember(2953,4). ismember(2953,8). ismember(2953,9). ismember(2953,10). ismember(2953,12). 
ismember(2954,2). ismember(2954,4). ismember(2954,8). ismember(2954,9). ismember(2954,10). ismember(2954,12). 
ismember(2955,1). ismember(2955,2). ismember(2955,4). ismember(2955,8). ismember(2955,9). ismember(2955,10). ismember(2955,12). 
ismember(2956,3). ismember(2956,4). ismember(2956,8). ismember(2956,9). ismember(2956,10). ismember(2956,12). 
ismember(2957,1). ismember(2957,3). ismember(2957,4). ismember(2957,8). ismember(2957,9). ismember(2957,10). ismember(2957,12). 
ismember(2958,2). ismember(2958,3). ismember(2958,4). ismember(2958,8). ismember(2958,9). ismember(2958,10). ismember(2958,12). 
ismember(2959,1). ismember(2959,2). ismember(2959,3). ismember(2959,4). ismember(2959,8). ismember(2959,9). ismember(2959,10). ismember(2959,12). 
ismember(2960,5). ismember(2960,8). ismember(2960,9). ismember(2960,10). ismember(2960,12). 
ismember(2961,1). ismember(2961,5). ismember(2961,8). ismember(2961,9). ismember(2961,10). ismember(2961,12). 
ismember(2962,2). ismember(2962,5). ismember(2962,8). ismember(2962,9). ismember(2962,10). ismember(2962,12). 
ismember(2963,1). ismember(2963,2). ismember(2963,5). ismember(2963,8). ismember(2963,9). ismember(2963,10). ismember(2963,12). 
ismember(2964,3). ismember(2964,5). ismember(2964,8). ismember(2964,9). ismember(2964,10). ismember(2964,12). 
ismember(2965,1). ismember(2965,3). ismember(2965,5). ismember(2965,8). ismember(2965,9). ismember(2965,10). ismember(2965,12). 
ismember(2966,2). ismember(2966,3). ismember(2966,5). ismember(2966,8). ismember(2966,9). ismember(2966,10). ismember(2966,12). 
ismember(2967,1). ismember(2967,2). ismember(2967,3). ismember(2967,5). ismember(2967,8). ismember(2967,9). ismember(2967,10). ismember(2967,12). 
ismember(2968,4). ismember(2968,5). ismember(2968,8). ismember(2968,9). ismember(2968,10). ismember(2968,12). 
ismember(2969,1). ismember(2969,4). ismember(2969,5). ismember(2969,8). ismember(2969,9). ismember(2969,10). ismember(2969,12). 
ismember(2970,2). ismember(2970,4). ismember(2970,5). ismember(2970,8). ismember(2970,9). ismember(2970,10). ismember(2970,12). 
ismember(2971,1). ismember(2971,2). ismember(2971,4). ismember(2971,5). ismember(2971,8). ismember(2971,9). ismember(2971,10). ismember(2971,12). 
ismember(2972,3). ismember(2972,4). ismember(2972,5). ismember(2972,8). ismember(2972,9). ismember(2972,10). ismember(2972,12). 
ismember(2973,1). ismember(2973,3). ismember(2973,4). ismember(2973,5). ismember(2973,8). ismember(2973,9). ismember(2973,10). ismember(2973,12). 
ismember(2974,2). ismember(2974,3). ismember(2974,4). ismember(2974,5). ismember(2974,8). ismember(2974,9). ismember(2974,10). ismember(2974,12). 
ismember(2975,1). ismember(2975,2). ismember(2975,3). ismember(2975,4). ismember(2975,5). ismember(2975,8). ismember(2975,9). ismember(2975,10). ismember(2975,12). 
ismember(2976,6). ismember(2976,8). ismember(2976,9). ismember(2976,10). ismember(2976,12). 
ismember(2977,1). ismember(2977,6). ismember(2977,8). ismember(2977,9). ismember(2977,10). ismember(2977,12). 
ismember(2978,2). ismember(2978,6). ismember(2978,8). ismember(2978,9). ismember(2978,10). ismember(2978,12). 
ismember(2979,1). ismember(2979,2). ismember(2979,6). ismember(2979,8). ismember(2979,9). ismember(2979,10). ismember(2979,12). 
ismember(2980,3). ismember(2980,6). ismember(2980,8). ismember(2980,9). ismember(2980,10). ismember(2980,12). 
ismember(2981,1). ismember(2981,3). ismember(2981,6). ismember(2981,8). ismember(2981,9). ismember(2981,10). ismember(2981,12). 
ismember(2982,2). ismember(2982,3). ismember(2982,6). ismember(2982,8). ismember(2982,9). ismember(2982,10). ismember(2982,12). 
ismember(2983,1). ismember(2983,2). ismember(2983,3). ismember(2983,6). ismember(2983,8). ismember(2983,9). ismember(2983,10). ismember(2983,12). 
ismember(2984,4). ismember(2984,6). ismember(2984,8). ismember(2984,9). ismember(2984,10). ismember(2984,12). 
ismember(2985,1). ismember(2985,4). ismember(2985,6). ismember(2985,8). ismember(2985,9). ismember(2985,10). ismember(2985,12). 
ismember(2986,2). ismember(2986,4). ismember(2986,6). ismember(2986,8). ismember(2986,9). ismember(2986,10). ismember(2986,12). 
ismember(2987,1). ismember(2987,2). ismember(2987,4). ismember(2987,6). ismember(2987,8). ismember(2987,9). ismember(2987,10). ismember(2987,12). 
ismember(2988,3). ismember(2988,4). ismember(2988,6). ismember(2988,8). ismember(2988,9). ismember(2988,10). ismember(2988,12). 
ismember(2989,1). ismember(2989,3). ismember(2989,4). ismember(2989,6). ismember(2989,8). ismember(2989,9). ismember(2989,10). ismember(2989,12). 
ismember(2990,2). ismember(2990,3). ismember(2990,4). ismember(2990,6). ismember(2990,8). ismember(2990,9). ismember(2990,10). ismember(2990,12). 
ismember(2991,1). ismember(2991,2). ismember(2991,3). ismember(2991,4). ismember(2991,6). ismember(2991,8). ismember(2991,9). ismember(2991,10). ismember(2991,12). 
ismember(2992,5). ismember(2992,6). ismember(2992,8). ismember(2992,9). ismember(2992,10). ismember(2992,12). 
ismember(2993,1). ismember(2993,5). ismember(2993,6). ismember(2993,8). ismember(2993,9). ismember(2993,10). ismember(2993,12). 
ismember(2994,2). ismember(2994,5). ismember(2994,6). ismember(2994,8). ismember(2994,9). ismember(2994,10). ismember(2994,12). 
ismember(2995,1). ismember(2995,2). ismember(2995,5). ismember(2995,6). ismember(2995,8). ismember(2995,9). ismember(2995,10). ismember(2995,12). 
ismember(2996,3). ismember(2996,5). ismember(2996,6). ismember(2996,8). ismember(2996,9). ismember(2996,10). ismember(2996,12). 
ismember(2997,1). ismember(2997,3). ismember(2997,5). ismember(2997,6). ismember(2997,8). ismember(2997,9). ismember(2997,10). ismember(2997,12). 
ismember(2998,2). ismember(2998,3). ismember(2998,5). ismember(2998,6). ismember(2998,8). ismember(2998,9). ismember(2998,10). ismember(2998,12). 
ismember(2999,1). ismember(2999,2). ismember(2999,3). ismember(2999,5). ismember(2999,6). ismember(2999,8). ismember(2999,9). ismember(2999,10). ismember(2999,12). 
ismember(3000,4). ismember(3000,5). ismember(3000,6). ismember(3000,8). ismember(3000,9). ismember(3000,10). ismember(3000,12). 
ismember(3001,1). ismember(3001,4). ismember(3001,5). ismember(3001,6). ismember(3001,8). ismember(3001,9). ismember(3001,10). ismember(3001,12). 
ismember(3002,2). ismember(3002,4). ismember(3002,5). ismember(3002,6). ismember(3002,8). ismember(3002,9). ismember(3002,10). ismember(3002,12). 
ismember(3003,1). ismember(3003,2). ismember(3003,4). ismember(3003,5). ismember(3003,6). ismember(3003,8). ismember(3003,9). ismember(3003,10). ismember(3003,12). 
ismember(3004,3). ismember(3004,4). ismember(3004,5). ismember(3004,6). ismember(3004,8). ismember(3004,9). ismember(3004,10). ismember(3004,12). 
ismember(3005,1). ismember(3005,3). ismember(3005,4). ismember(3005,5). ismember(3005,6). ismember(3005,8). ismember(3005,9). ismember(3005,10). ismember(3005,12). 
ismember(3006,2). ismember(3006,3). ismember(3006,4). ismember(3006,5). ismember(3006,6). ismember(3006,8). ismember(3006,9). ismember(3006,10). ismember(3006,12). 
ismember(3007,1). ismember(3007,2). ismember(3007,3). ismember(3007,4). ismember(3007,5). ismember(3007,6). ismember(3007,8). ismember(3007,9). ismember(3007,10). ismember(3007,12). 
ismember(3008,7). ismember(3008,8). ismember(3008,9). ismember(3008,10). ismember(3008,12). 
ismember(3009,1). ismember(3009,7). ismember(3009,8). ismember(3009,9). ismember(3009,10). ismember(3009,12). 
ismember(3010,2). ismember(3010,7). ismember(3010,8). ismember(3010,9). ismember(3010,10). ismember(3010,12). 
ismember(3011,1). ismember(3011,2). ismember(3011,7). ismember(3011,8). ismember(3011,9). ismember(3011,10). ismember(3011,12). 
ismember(3012,3). ismember(3012,7). ismember(3012,8). ismember(3012,9). ismember(3012,10). ismember(3012,12). 
ismember(3013,1). ismember(3013,3). ismember(3013,7). ismember(3013,8). ismember(3013,9). ismember(3013,10). ismember(3013,12). 
ismember(3014,2). ismember(3014,3). ismember(3014,7). ismember(3014,8). ismember(3014,9). ismember(3014,10). ismember(3014,12). 
ismember(3015,1). ismember(3015,2). ismember(3015,3). ismember(3015,7). ismember(3015,8). ismember(3015,9). ismember(3015,10). ismember(3015,12). 
ismember(3016,4). ismember(3016,7). ismember(3016,8). ismember(3016,9). ismember(3016,10). ismember(3016,12). 
ismember(3017,1). ismember(3017,4). ismember(3017,7). ismember(3017,8). ismember(3017,9). ismember(3017,10). ismember(3017,12). 
ismember(3018,2). ismember(3018,4). ismember(3018,7). ismember(3018,8). ismember(3018,9). ismember(3018,10). ismember(3018,12). 
ismember(3019,1). ismember(3019,2). ismember(3019,4). ismember(3019,7). ismember(3019,8). ismember(3019,9). ismember(3019,10). ismember(3019,12). 
ismember(3020,3). ismember(3020,4). ismember(3020,7). ismember(3020,8). ismember(3020,9). ismember(3020,10). ismember(3020,12). 
ismember(3021,1). ismember(3021,3). ismember(3021,4). ismember(3021,7). ismember(3021,8). ismember(3021,9). ismember(3021,10). ismember(3021,12). 
ismember(3022,2). ismember(3022,3). ismember(3022,4). ismember(3022,7). ismember(3022,8). ismember(3022,9). ismember(3022,10). ismember(3022,12). 
ismember(3023,1). ismember(3023,2). ismember(3023,3). ismember(3023,4). ismember(3023,7). ismember(3023,8). ismember(3023,9). ismember(3023,10). ismember(3023,12). 
ismember(3024,5). ismember(3024,7). ismember(3024,8). ismember(3024,9). ismember(3024,10). ismember(3024,12). 
ismember(3025,1). ismember(3025,5). ismember(3025,7). ismember(3025,8). ismember(3025,9). ismember(3025,10). ismember(3025,12). 
ismember(3026,2). ismember(3026,5). ismember(3026,7). ismember(3026,8). ismember(3026,9). ismember(3026,10). ismember(3026,12). 
ismember(3027,1). ismember(3027,2). ismember(3027,5). ismember(3027,7). ismember(3027,8). ismember(3027,9). ismember(3027,10). ismember(3027,12). 
ismember(3028,3). ismember(3028,5). ismember(3028,7). ismember(3028,8). ismember(3028,9). ismember(3028,10). ismember(3028,12). 
ismember(3029,1). ismember(3029,3). ismember(3029,5). ismember(3029,7). ismember(3029,8). ismember(3029,9). ismember(3029,10). ismember(3029,12). 
ismember(3030,2). ismember(3030,3). ismember(3030,5). ismember(3030,7). ismember(3030,8). ismember(3030,9). ismember(3030,10). ismember(3030,12). 
ismember(3031,1). ismember(3031,2). ismember(3031,3). ismember(3031,5). ismember(3031,7). ismember(3031,8). ismember(3031,9). ismember(3031,10). ismember(3031,12). 
ismember(3032,4). ismember(3032,5). ismember(3032,7). ismember(3032,8). ismember(3032,9). ismember(3032,10). ismember(3032,12). 
ismember(3033,1). ismember(3033,4). ismember(3033,5). ismember(3033,7). ismember(3033,8). ismember(3033,9). ismember(3033,10). ismember(3033,12). 
ismember(3034,2). ismember(3034,4). ismember(3034,5). ismember(3034,7). ismember(3034,8). ismember(3034,9). ismember(3034,10). ismember(3034,12). 
ismember(3035,1). ismember(3035,2). ismember(3035,4). ismember(3035,5). ismember(3035,7). ismember(3035,8). ismember(3035,9). ismember(3035,10). ismember(3035,12). 
ismember(3036,3). ismember(3036,4). ismember(3036,5). ismember(3036,7). ismember(3036,8). ismember(3036,9). ismember(3036,10). ismember(3036,12). 
ismember(3037,1). ismember(3037,3). ismember(3037,4). ismember(3037,5). ismember(3037,7). ismember(3037,8). ismember(3037,9). ismember(3037,10). ismember(3037,12). 
ismember(3038,2). ismember(3038,3). ismember(3038,4). ismember(3038,5). ismember(3038,7). ismember(3038,8). ismember(3038,9). ismember(3038,10). ismember(3038,12). 
ismember(3039,1). ismember(3039,2). ismember(3039,3). ismember(3039,4). ismember(3039,5). ismember(3039,7). ismember(3039,8). ismember(3039,9). ismember(3039,10). ismember(3039,12). 
ismember(3040,6). ismember(3040,7). ismember(3040,8). ismember(3040,9). ismember(3040,10). ismember(3040,12). 
ismember(3041,1). ismember(3041,6). ismember(3041,7). ismember(3041,8). ismember(3041,9). ismember(3041,10). ismember(3041,12). 
ismember(3042,2). ismember(3042,6). ismember(3042,7). ismember(3042,8). ismember(3042,9). ismember(3042,10). ismember(3042,12). 
ismember(3043,1). ismember(3043,2). ismember(3043,6). ismember(3043,7). ismember(3043,8). ismember(3043,9). ismember(3043,10). ismember(3043,12). 
ismember(3044,3). ismember(3044,6). ismember(3044,7). ismember(3044,8). ismember(3044,9). ismember(3044,10). ismember(3044,12). 
ismember(3045,1). ismember(3045,3). ismember(3045,6). ismember(3045,7). ismember(3045,8). ismember(3045,9). ismember(3045,10). ismember(3045,12). 
ismember(3046,2). ismember(3046,3). ismember(3046,6). ismember(3046,7). ismember(3046,8). ismember(3046,9). ismember(3046,10). ismember(3046,12). 
ismember(3047,1). ismember(3047,2). ismember(3047,3). ismember(3047,6). ismember(3047,7). ismember(3047,8). ismember(3047,9). ismember(3047,10). ismember(3047,12). 
ismember(3048,4). ismember(3048,6). ismember(3048,7). ismember(3048,8). ismember(3048,9). ismember(3048,10). ismember(3048,12). 
ismember(3049,1). ismember(3049,4). ismember(3049,6). ismember(3049,7). ismember(3049,8). ismember(3049,9). ismember(3049,10). ismember(3049,12). 
ismember(3050,2). ismember(3050,4). ismember(3050,6). ismember(3050,7). ismember(3050,8). ismember(3050,9). ismember(3050,10). ismember(3050,12). 
ismember(3051,1). ismember(3051,2). ismember(3051,4). ismember(3051,6). ismember(3051,7). ismember(3051,8). ismember(3051,9). ismember(3051,10). ismember(3051,12). 
ismember(3052,3). ismember(3052,4). ismember(3052,6). ismember(3052,7). ismember(3052,8). ismember(3052,9). ismember(3052,10). ismember(3052,12). 
ismember(3053,1). ismember(3053,3). ismember(3053,4). ismember(3053,6). ismember(3053,7). ismember(3053,8). ismember(3053,9). ismember(3053,10). ismember(3053,12). 
ismember(3054,2). ismember(3054,3). ismember(3054,4). ismember(3054,6). ismember(3054,7). ismember(3054,8). ismember(3054,9). ismember(3054,10). ismember(3054,12). 
ismember(3055,1). ismember(3055,2). ismember(3055,3). ismember(3055,4). ismember(3055,6). ismember(3055,7). ismember(3055,8). ismember(3055,9). ismember(3055,10). ismember(3055,12). 
ismember(3056,5). ismember(3056,6). ismember(3056,7). ismember(3056,8). ismember(3056,9). ismember(3056,10). ismember(3056,12). 
ismember(3057,1). ismember(3057,5). ismember(3057,6). ismember(3057,7). ismember(3057,8). ismember(3057,9). ismember(3057,10). ismember(3057,12). 
ismember(3058,2). ismember(3058,5). ismember(3058,6). ismember(3058,7). ismember(3058,8). ismember(3058,9). ismember(3058,10). ismember(3058,12). 
ismember(3059,1). ismember(3059,2). ismember(3059,5). ismember(3059,6). ismember(3059,7). ismember(3059,8). ismember(3059,9). ismember(3059,10). ismember(3059,12). 
ismember(3060,3). ismember(3060,5). ismember(3060,6). ismember(3060,7). ismember(3060,8). ismember(3060,9). ismember(3060,10). ismember(3060,12). 
ismember(3061,1). ismember(3061,3). ismember(3061,5). ismember(3061,6). ismember(3061,7). ismember(3061,8). ismember(3061,9). ismember(3061,10). ismember(3061,12). 
ismember(3062,2). ismember(3062,3). ismember(3062,5). ismember(3062,6). ismember(3062,7). ismember(3062,8). ismember(3062,9). ismember(3062,10). ismember(3062,12). 
ismember(3063,1). ismember(3063,2). ismember(3063,3). ismember(3063,5). ismember(3063,6). ismember(3063,7). ismember(3063,8). ismember(3063,9). ismember(3063,10). ismember(3063,12). 
ismember(3064,4). ismember(3064,5). ismember(3064,6). ismember(3064,7). ismember(3064,8). ismember(3064,9). ismember(3064,10). ismember(3064,12). 
ismember(3065,1). ismember(3065,4). ismember(3065,5). ismember(3065,6). ismember(3065,7). ismember(3065,8). ismember(3065,9). ismember(3065,10). ismember(3065,12). 
ismember(3066,2). ismember(3066,4). ismember(3066,5). ismember(3066,6). ismember(3066,7). ismember(3066,8). ismember(3066,9). ismember(3066,10). ismember(3066,12). 
ismember(3067,1). ismember(3067,2). ismember(3067,4). ismember(3067,5). ismember(3067,6). ismember(3067,7). ismember(3067,8). ismember(3067,9). ismember(3067,10). ismember(3067,12). 
ismember(3068,3). ismember(3068,4). ismember(3068,5). ismember(3068,6). ismember(3068,7). ismember(3068,8). ismember(3068,9). ismember(3068,10). ismember(3068,12). 
ismember(3069,1). ismember(3069,3). ismember(3069,4). ismember(3069,5). ismember(3069,6). ismember(3069,7). ismember(3069,8). ismember(3069,9). ismember(3069,10). ismember(3069,12). 
ismember(3070,2). ismember(3070,3). ismember(3070,4). ismember(3070,5). ismember(3070,6). ismember(3070,7). ismember(3070,8). ismember(3070,9). ismember(3070,10). ismember(3070,12). 
ismember(3071,1). ismember(3071,2). ismember(3071,3). ismember(3071,4). ismember(3071,5). ismember(3071,6). ismember(3071,7). ismember(3071,8). ismember(3071,9). ismember(3071,10). ismember(3071,12). 
ismember(3072,11). ismember(3072,12). 
ismember(3073,1). ismember(3073,11). ismember(3073,12). 
ismember(3074,2). ismember(3074,11). ismember(3074,12). 
ismember(3075,1). ismember(3075,2). ismember(3075,11). ismember(3075,12). 
ismember(3076,3). ismember(3076,11). ismember(3076,12). 
ismember(3077,1). ismember(3077,3). ismember(3077,11). ismember(3077,12). 
ismember(3078,2). ismember(3078,3). ismember(3078,11). ismember(3078,12). 
ismember(3079,1). ismember(3079,2). ismember(3079,3). ismember(3079,11). ismember(3079,12). 
ismember(3080,4). ismember(3080,11). ismember(3080,12). 
ismember(3081,1). ismember(3081,4). ismember(3081,11). ismember(3081,12). 
ismember(3082,2). ismember(3082,4). ismember(3082,11). ismember(3082,12). 
ismember(3083,1). ismember(3083,2). ismember(3083,4). ismember(3083,11). ismember(3083,12). 
ismember(3084,3). ismember(3084,4). ismember(3084,11). ismember(3084,12). 
ismember(3085,1). ismember(3085,3). ismember(3085,4). ismember(3085,11). ismember(3085,12). 
ismember(3086,2). ismember(3086,3). ismember(3086,4). ismember(3086,11). ismember(3086,12). 
ismember(3087,1). ismember(3087,2). ismember(3087,3). ismember(3087,4). ismember(3087,11). ismember(3087,12). 
ismember(3088,5). ismember(3088,11). ismember(3088,12). 
ismember(3089,1). ismember(3089,5). ismember(3089,11). ismember(3089,12). 
ismember(3090,2). ismember(3090,5). ismember(3090,11). ismember(3090,12). 
ismember(3091,1). ismember(3091,2). ismember(3091,5). ismember(3091,11). ismember(3091,12). 
ismember(3092,3). ismember(3092,5). ismember(3092,11). ismember(3092,12). 
ismember(3093,1). ismember(3093,3). ismember(3093,5). ismember(3093,11). ismember(3093,12). 
ismember(3094,2). ismember(3094,3). ismember(3094,5). ismember(3094,11). ismember(3094,12). 
ismember(3095,1). ismember(3095,2). ismember(3095,3). ismember(3095,5). ismember(3095,11). ismember(3095,12). 
ismember(3096,4). ismember(3096,5). ismember(3096,11). ismember(3096,12). 
ismember(3097,1). ismember(3097,4). ismember(3097,5). ismember(3097,11). ismember(3097,12). 
ismember(3098,2). ismember(3098,4). ismember(3098,5). ismember(3098,11). ismember(3098,12). 
ismember(3099,1). ismember(3099,2). ismember(3099,4). ismember(3099,5). ismember(3099,11). ismember(3099,12). 
ismember(3100,3). ismember(3100,4). ismember(3100,5). ismember(3100,11). ismember(3100,12). 
ismember(3101,1). ismember(3101,3). ismember(3101,4). ismember(3101,5). ismember(3101,11). ismember(3101,12). 
ismember(3102,2). ismember(3102,3). ismember(3102,4). ismember(3102,5). ismember(3102,11). ismember(3102,12). 
ismember(3103,1). ismember(3103,2). ismember(3103,3). ismember(3103,4). ismember(3103,5). ismember(3103,11). ismember(3103,12). 
ismember(3104,6). ismember(3104,11). ismember(3104,12). 
ismember(3105,1). ismember(3105,6). ismember(3105,11). ismember(3105,12). 
ismember(3106,2). ismember(3106,6). ismember(3106,11). ismember(3106,12). 
ismember(3107,1). ismember(3107,2). ismember(3107,6). ismember(3107,11). ismember(3107,12). 
ismember(3108,3). ismember(3108,6). ismember(3108,11). ismember(3108,12). 
ismember(3109,1). ismember(3109,3). ismember(3109,6). ismember(3109,11). ismember(3109,12). 
ismember(3110,2). ismember(3110,3). ismember(3110,6). ismember(3110,11). ismember(3110,12). 
ismember(3111,1). ismember(3111,2). ismember(3111,3). ismember(3111,6). ismember(3111,11). ismember(3111,12). 
ismember(3112,4). ismember(3112,6). ismember(3112,11). ismember(3112,12). 
ismember(3113,1). ismember(3113,4). ismember(3113,6). ismember(3113,11). ismember(3113,12). 
ismember(3114,2). ismember(3114,4). ismember(3114,6). ismember(3114,11). ismember(3114,12). 
ismember(3115,1). ismember(3115,2). ismember(3115,4). ismember(3115,6). ismember(3115,11). ismember(3115,12). 
ismember(3116,3). ismember(3116,4). ismember(3116,6). ismember(3116,11). ismember(3116,12). 
ismember(3117,1). ismember(3117,3). ismember(3117,4). ismember(3117,6). ismember(3117,11). ismember(3117,12). 
ismember(3118,2). ismember(3118,3). ismember(3118,4). ismember(3118,6). ismember(3118,11). ismember(3118,12). 
ismember(3119,1). ismember(3119,2). ismember(3119,3). ismember(3119,4). ismember(3119,6). ismember(3119,11). ismember(3119,12). 
ismember(3120,5). ismember(3120,6). ismember(3120,11). ismember(3120,12). 
ismember(3121,1). ismember(3121,5). ismember(3121,6). ismember(3121,11). ismember(3121,12). 
ismember(3122,2). ismember(3122,5). ismember(3122,6). ismember(3122,11). ismember(3122,12). 
ismember(3123,1). ismember(3123,2). ismember(3123,5). ismember(3123,6). ismember(3123,11). ismember(3123,12). 
ismember(3124,3). ismember(3124,5). ismember(3124,6). ismember(3124,11). ismember(3124,12). 
ismember(3125,1). ismember(3125,3). ismember(3125,5). ismember(3125,6). ismember(3125,11). ismember(3125,12). 
ismember(3126,2). ismember(3126,3). ismember(3126,5). ismember(3126,6). ismember(3126,11). ismember(3126,12). 
ismember(3127,1). ismember(3127,2). ismember(3127,3). ismember(3127,5). ismember(3127,6). ismember(3127,11). ismember(3127,12). 
ismember(3128,4). ismember(3128,5). ismember(3128,6). ismember(3128,11). ismember(3128,12). 
ismember(3129,1). ismember(3129,4). ismember(3129,5). ismember(3129,6). ismember(3129,11). ismember(3129,12). 
ismember(3130,2). ismember(3130,4). ismember(3130,5). ismember(3130,6). ismember(3130,11). ismember(3130,12). 
ismember(3131,1). ismember(3131,2). ismember(3131,4). ismember(3131,5). ismember(3131,6). ismember(3131,11). ismember(3131,12). 
ismember(3132,3). ismember(3132,4). ismember(3132,5). ismember(3132,6). ismember(3132,11). ismember(3132,12). 
ismember(3133,1). ismember(3133,3). ismember(3133,4). ismember(3133,5). ismember(3133,6). ismember(3133,11). ismember(3133,12). 
ismember(3134,2). ismember(3134,3). ismember(3134,4). ismember(3134,5). ismember(3134,6). ismember(3134,11). ismember(3134,12). 
ismember(3135,1). ismember(3135,2). ismember(3135,3). ismember(3135,4). ismember(3135,5). ismember(3135,6). ismember(3135,11). ismember(3135,12). 
ismember(3136,7). ismember(3136,11). ismember(3136,12). 
ismember(3137,1). ismember(3137,7). ismember(3137,11). ismember(3137,12). 
ismember(3138,2). ismember(3138,7). ismember(3138,11). ismember(3138,12). 
ismember(3139,1). ismember(3139,2). ismember(3139,7). ismember(3139,11). ismember(3139,12). 
ismember(3140,3). ismember(3140,7). ismember(3140,11). ismember(3140,12). 
ismember(3141,1). ismember(3141,3). ismember(3141,7). ismember(3141,11). ismember(3141,12). 
ismember(3142,2). ismember(3142,3). ismember(3142,7). ismember(3142,11). ismember(3142,12). 
ismember(3143,1). ismember(3143,2). ismember(3143,3). ismember(3143,7). ismember(3143,11). ismember(3143,12). 
ismember(3144,4). ismember(3144,7). ismember(3144,11). ismember(3144,12). 
ismember(3145,1). ismember(3145,4). ismember(3145,7). ismember(3145,11). ismember(3145,12). 
ismember(3146,2). ismember(3146,4). ismember(3146,7). ismember(3146,11). ismember(3146,12). 
ismember(3147,1). ismember(3147,2). ismember(3147,4). ismember(3147,7). ismember(3147,11). ismember(3147,12). 
ismember(3148,3). ismember(3148,4). ismember(3148,7). ismember(3148,11). ismember(3148,12). 
ismember(3149,1). ismember(3149,3). ismember(3149,4). ismember(3149,7). ismember(3149,11). ismember(3149,12). 
ismember(3150,2). ismember(3150,3). ismember(3150,4). ismember(3150,7). ismember(3150,11). ismember(3150,12). 
ismember(3151,1). ismember(3151,2). ismember(3151,3). ismember(3151,4). ismember(3151,7). ismember(3151,11). ismember(3151,12). 
ismember(3152,5). ismember(3152,7). ismember(3152,11). ismember(3152,12). 
ismember(3153,1). ismember(3153,5). ismember(3153,7). ismember(3153,11). ismember(3153,12). 
ismember(3154,2). ismember(3154,5). ismember(3154,7). ismember(3154,11). ismember(3154,12). 
ismember(3155,1). ismember(3155,2). ismember(3155,5). ismember(3155,7). ismember(3155,11). ismember(3155,12). 
ismember(3156,3). ismember(3156,5). ismember(3156,7). ismember(3156,11). ismember(3156,12). 
ismember(3157,1). ismember(3157,3). ismember(3157,5). ismember(3157,7). ismember(3157,11). ismember(3157,12). 
ismember(3158,2). ismember(3158,3). ismember(3158,5). ismember(3158,7). ismember(3158,11). ismember(3158,12). 
ismember(3159,1). ismember(3159,2). ismember(3159,3). ismember(3159,5). ismember(3159,7). ismember(3159,11). ismember(3159,12). 
ismember(3160,4). ismember(3160,5). ismember(3160,7). ismember(3160,11). ismember(3160,12). 
ismember(3161,1). ismember(3161,4). ismember(3161,5). ismember(3161,7). ismember(3161,11). ismember(3161,12). 
ismember(3162,2). ismember(3162,4). ismember(3162,5). ismember(3162,7). ismember(3162,11). ismember(3162,12). 
ismember(3163,1). ismember(3163,2). ismember(3163,4). ismember(3163,5). ismember(3163,7). ismember(3163,11). ismember(3163,12). 
ismember(3164,3). ismember(3164,4). ismember(3164,5). ismember(3164,7). ismember(3164,11). ismember(3164,12). 
ismember(3165,1). ismember(3165,3). ismember(3165,4). ismember(3165,5). ismember(3165,7). ismember(3165,11). ismember(3165,12). 
ismember(3166,2). ismember(3166,3). ismember(3166,4). ismember(3166,5). ismember(3166,7). ismember(3166,11). ismember(3166,12). 
ismember(3167,1). ismember(3167,2). ismember(3167,3). ismember(3167,4). ismember(3167,5). ismember(3167,7). ismember(3167,11). ismember(3167,12). 
ismember(3168,6). ismember(3168,7). ismember(3168,11). ismember(3168,12). 
ismember(3169,1). ismember(3169,6). ismember(3169,7). ismember(3169,11). ismember(3169,12). 
ismember(3170,2). ismember(3170,6). ismember(3170,7). ismember(3170,11). ismember(3170,12). 
ismember(3171,1). ismember(3171,2). ismember(3171,6). ismember(3171,7). ismember(3171,11). ismember(3171,12). 
ismember(3172,3). ismember(3172,6). ismember(3172,7). ismember(3172,11). ismember(3172,12). 
ismember(3173,1). ismember(3173,3). ismember(3173,6). ismember(3173,7). ismember(3173,11). ismember(3173,12). 
ismember(3174,2). ismember(3174,3). ismember(3174,6). ismember(3174,7). ismember(3174,11). ismember(3174,12). 
ismember(3175,1). ismember(3175,2). ismember(3175,3). ismember(3175,6). ismember(3175,7). ismember(3175,11). ismember(3175,12). 
ismember(3176,4). ismember(3176,6). ismember(3176,7). ismember(3176,11). ismember(3176,12). 
ismember(3177,1). ismember(3177,4). ismember(3177,6). ismember(3177,7). ismember(3177,11). ismember(3177,12). 
ismember(3178,2). ismember(3178,4). ismember(3178,6). ismember(3178,7). ismember(3178,11). ismember(3178,12). 
ismember(3179,1). ismember(3179,2). ismember(3179,4). ismember(3179,6). ismember(3179,7). ismember(3179,11). ismember(3179,12). 
ismember(3180,3). ismember(3180,4). ismember(3180,6). ismember(3180,7). ismember(3180,11). ismember(3180,12). 
ismember(3181,1). ismember(3181,3). ismember(3181,4). ismember(3181,6). ismember(3181,7). ismember(3181,11). ismember(3181,12). 
ismember(3182,2). ismember(3182,3). ismember(3182,4). ismember(3182,6). ismember(3182,7). ismember(3182,11). ismember(3182,12). 
ismember(3183,1). ismember(3183,2). ismember(3183,3). ismember(3183,4). ismember(3183,6). ismember(3183,7). ismember(3183,11). ismember(3183,12). 
ismember(3184,5). ismember(3184,6). ismember(3184,7). ismember(3184,11). ismember(3184,12). 
ismember(3185,1). ismember(3185,5). ismember(3185,6). ismember(3185,7). ismember(3185,11). ismember(3185,12). 
ismember(3186,2). ismember(3186,5). ismember(3186,6). ismember(3186,7). ismember(3186,11). ismember(3186,12). 
ismember(3187,1). ismember(3187,2). ismember(3187,5). ismember(3187,6). ismember(3187,7). ismember(3187,11). ismember(3187,12). 
ismember(3188,3). ismember(3188,5). ismember(3188,6). ismember(3188,7). ismember(3188,11). ismember(3188,12). 
ismember(3189,1). ismember(3189,3). ismember(3189,5). ismember(3189,6). ismember(3189,7). ismember(3189,11). ismember(3189,12). 
ismember(3190,2). ismember(3190,3). ismember(3190,5). ismember(3190,6). ismember(3190,7). ismember(3190,11). ismember(3190,12). 
ismember(3191,1). ismember(3191,2). ismember(3191,3). ismember(3191,5). ismember(3191,6). ismember(3191,7). ismember(3191,11). ismember(3191,12). 
ismember(3192,4). ismember(3192,5). ismember(3192,6). ismember(3192,7). ismember(3192,11). ismember(3192,12). 
ismember(3193,1). ismember(3193,4). ismember(3193,5). ismember(3193,6). ismember(3193,7). ismember(3193,11). ismember(3193,12). 
ismember(3194,2). ismember(3194,4). ismember(3194,5). ismember(3194,6). ismember(3194,7). ismember(3194,11). ismember(3194,12). 
ismember(3195,1). ismember(3195,2). ismember(3195,4). ismember(3195,5). ismember(3195,6). ismember(3195,7). ismember(3195,11). ismember(3195,12). 
ismember(3196,3). ismember(3196,4). ismember(3196,5). ismember(3196,6). ismember(3196,7). ismember(3196,11). ismember(3196,12). 
ismember(3197,1). ismember(3197,3). ismember(3197,4). ismember(3197,5). ismember(3197,6). ismember(3197,7). ismember(3197,11). ismember(3197,12). 
ismember(3198,2). ismember(3198,3). ismember(3198,4). ismember(3198,5). ismember(3198,6). ismember(3198,7). ismember(3198,11). ismember(3198,12). 
ismember(3199,1). ismember(3199,2). ismember(3199,3). ismember(3199,4). ismember(3199,5). ismember(3199,6). ismember(3199,7). ismember(3199,11). ismember(3199,12). 
ismember(3200,8). ismember(3200,11). ismember(3200,12). 
ismember(3201,1). ismember(3201,8). ismember(3201,11). ismember(3201,12). 
ismember(3202,2). ismember(3202,8). ismember(3202,11). ismember(3202,12). 
ismember(3203,1). ismember(3203,2). ismember(3203,8). ismember(3203,11). ismember(3203,12). 
ismember(3204,3). ismember(3204,8). ismember(3204,11). ismember(3204,12). 
ismember(3205,1). ismember(3205,3). ismember(3205,8). ismember(3205,11). ismember(3205,12). 
ismember(3206,2). ismember(3206,3). ismember(3206,8). ismember(3206,11). ismember(3206,12). 
ismember(3207,1). ismember(3207,2). ismember(3207,3). ismember(3207,8). ismember(3207,11). ismember(3207,12). 
ismember(3208,4). ismember(3208,8). ismember(3208,11). ismember(3208,12). 
ismember(3209,1). ismember(3209,4). ismember(3209,8). ismember(3209,11). ismember(3209,12). 
ismember(3210,2). ismember(3210,4). ismember(3210,8). ismember(3210,11). ismember(3210,12). 
ismember(3211,1). ismember(3211,2). ismember(3211,4). ismember(3211,8). ismember(3211,11). ismember(3211,12). 
ismember(3212,3). ismember(3212,4). ismember(3212,8). ismember(3212,11). ismember(3212,12). 
ismember(3213,1). ismember(3213,3). ismember(3213,4). ismember(3213,8). ismember(3213,11). ismember(3213,12). 
ismember(3214,2). ismember(3214,3). ismember(3214,4). ismember(3214,8). ismember(3214,11). ismember(3214,12). 
ismember(3215,1). ismember(3215,2). ismember(3215,3). ismember(3215,4). ismember(3215,8). ismember(3215,11). ismember(3215,12). 
ismember(3216,5). ismember(3216,8). ismember(3216,11). ismember(3216,12). 
ismember(3217,1). ismember(3217,5). ismember(3217,8). ismember(3217,11). ismember(3217,12). 
ismember(3218,2). ismember(3218,5). ismember(3218,8). ismember(3218,11). ismember(3218,12). 
ismember(3219,1). ismember(3219,2). ismember(3219,5). ismember(3219,8). ismember(3219,11). ismember(3219,12). 
ismember(3220,3). ismember(3220,5). ismember(3220,8). ismember(3220,11). ismember(3220,12). 
ismember(3221,1). ismember(3221,3). ismember(3221,5). ismember(3221,8). ismember(3221,11). ismember(3221,12). 
ismember(3222,2). ismember(3222,3). ismember(3222,5). ismember(3222,8). ismember(3222,11). ismember(3222,12). 
ismember(3223,1). ismember(3223,2). ismember(3223,3). ismember(3223,5). ismember(3223,8). ismember(3223,11). ismember(3223,12). 
ismember(3224,4). ismember(3224,5). ismember(3224,8). ismember(3224,11). ismember(3224,12). 
ismember(3225,1). ismember(3225,4). ismember(3225,5). ismember(3225,8). ismember(3225,11). ismember(3225,12). 
ismember(3226,2). ismember(3226,4). ismember(3226,5). ismember(3226,8). ismember(3226,11). ismember(3226,12). 
ismember(3227,1). ismember(3227,2). ismember(3227,4). ismember(3227,5). ismember(3227,8). ismember(3227,11). ismember(3227,12). 
ismember(3228,3). ismember(3228,4). ismember(3228,5). ismember(3228,8). ismember(3228,11). ismember(3228,12). 
ismember(3229,1). ismember(3229,3). ismember(3229,4). ismember(3229,5). ismember(3229,8). ismember(3229,11). ismember(3229,12). 
ismember(3230,2). ismember(3230,3). ismember(3230,4). ismember(3230,5). ismember(3230,8). ismember(3230,11). ismember(3230,12). 
ismember(3231,1). ismember(3231,2). ismember(3231,3). ismember(3231,4). ismember(3231,5). ismember(3231,8). ismember(3231,11). ismember(3231,12). 
ismember(3232,6). ismember(3232,8). ismember(3232,11). ismember(3232,12). 
ismember(3233,1). ismember(3233,6). ismember(3233,8). ismember(3233,11). ismember(3233,12). 
ismember(3234,2). ismember(3234,6). ismember(3234,8). ismember(3234,11). ismember(3234,12). 
ismember(3235,1). ismember(3235,2). ismember(3235,6). ismember(3235,8). ismember(3235,11). ismember(3235,12). 
ismember(3236,3). ismember(3236,6). ismember(3236,8). ismember(3236,11). ismember(3236,12). 
ismember(3237,1). ismember(3237,3). ismember(3237,6). ismember(3237,8). ismember(3237,11). ismember(3237,12). 
ismember(3238,2). ismember(3238,3). ismember(3238,6). ismember(3238,8). ismember(3238,11). ismember(3238,12). 
ismember(3239,1). ismember(3239,2). ismember(3239,3). ismember(3239,6). ismember(3239,8). ismember(3239,11). ismember(3239,12). 
ismember(3240,4). ismember(3240,6). ismember(3240,8). ismember(3240,11). ismember(3240,12). 
ismember(3241,1). ismember(3241,4). ismember(3241,6). ismember(3241,8). ismember(3241,11). ismember(3241,12). 
ismember(3242,2). ismember(3242,4). ismember(3242,6). ismember(3242,8). ismember(3242,11). ismember(3242,12). 
ismember(3243,1). ismember(3243,2). ismember(3243,4). ismember(3243,6). ismember(3243,8). ismember(3243,11). ismember(3243,12). 
ismember(3244,3). ismember(3244,4). ismember(3244,6). ismember(3244,8). ismember(3244,11). ismember(3244,12). 
ismember(3245,1). ismember(3245,3). ismember(3245,4). ismember(3245,6). ismember(3245,8). ismember(3245,11). ismember(3245,12). 
ismember(3246,2). ismember(3246,3). ismember(3246,4). ismember(3246,6). ismember(3246,8). ismember(3246,11). ismember(3246,12). 
ismember(3247,1). ismember(3247,2). ismember(3247,3). ismember(3247,4). ismember(3247,6). ismember(3247,8). ismember(3247,11). ismember(3247,12). 
ismember(3248,5). ismember(3248,6). ismember(3248,8). ismember(3248,11). ismember(3248,12). 
ismember(3249,1). ismember(3249,5). ismember(3249,6). ismember(3249,8). ismember(3249,11). ismember(3249,12). 
ismember(3250,2). ismember(3250,5). ismember(3250,6). ismember(3250,8). ismember(3250,11). ismember(3250,12). 
ismember(3251,1). ismember(3251,2). ismember(3251,5). ismember(3251,6). ismember(3251,8). ismember(3251,11). ismember(3251,12). 
ismember(3252,3). ismember(3252,5). ismember(3252,6). ismember(3252,8). ismember(3252,11). ismember(3252,12). 
ismember(3253,1). ismember(3253,3). ismember(3253,5). ismember(3253,6). ismember(3253,8). ismember(3253,11). ismember(3253,12). 
ismember(3254,2). ismember(3254,3). ismember(3254,5). ismember(3254,6). ismember(3254,8). ismember(3254,11). ismember(3254,12). 
ismember(3255,1). ismember(3255,2). ismember(3255,3). ismember(3255,5). ismember(3255,6). ismember(3255,8). ismember(3255,11). ismember(3255,12). 
ismember(3256,4). ismember(3256,5). ismember(3256,6). ismember(3256,8). ismember(3256,11). ismember(3256,12). 
ismember(3257,1). ismember(3257,4). ismember(3257,5). ismember(3257,6). ismember(3257,8). ismember(3257,11). ismember(3257,12). 
ismember(3258,2). ismember(3258,4). ismember(3258,5). ismember(3258,6). ismember(3258,8). ismember(3258,11). ismember(3258,12). 
ismember(3259,1). ismember(3259,2). ismember(3259,4). ismember(3259,5). ismember(3259,6). ismember(3259,8). ismember(3259,11). ismember(3259,12). 
ismember(3260,3). ismember(3260,4). ismember(3260,5). ismember(3260,6). ismember(3260,8). ismember(3260,11). ismember(3260,12). 
ismember(3261,1). ismember(3261,3). ismember(3261,4). ismember(3261,5). ismember(3261,6). ismember(3261,8). ismember(3261,11). ismember(3261,12). 
ismember(3262,2). ismember(3262,3). ismember(3262,4). ismember(3262,5). ismember(3262,6). ismember(3262,8). ismember(3262,11). ismember(3262,12). 
ismember(3263,1). ismember(3263,2). ismember(3263,3). ismember(3263,4). ismember(3263,5). ismember(3263,6). ismember(3263,8). ismember(3263,11). ismember(3263,12). 
ismember(3264,7). ismember(3264,8). ismember(3264,11). ismember(3264,12). 
ismember(3265,1). ismember(3265,7). ismember(3265,8). ismember(3265,11). ismember(3265,12). 
ismember(3266,2). ismember(3266,7). ismember(3266,8). ismember(3266,11). ismember(3266,12). 
ismember(3267,1). ismember(3267,2). ismember(3267,7). ismember(3267,8). ismember(3267,11). ismember(3267,12). 
ismember(3268,3). ismember(3268,7). ismember(3268,8). ismember(3268,11). ismember(3268,12). 
ismember(3269,1). ismember(3269,3). ismember(3269,7). ismember(3269,8). ismember(3269,11). ismember(3269,12). 
ismember(3270,2). ismember(3270,3). ismember(3270,7). ismember(3270,8). ismember(3270,11). ismember(3270,12). 
ismember(3271,1). ismember(3271,2). ismember(3271,3). ismember(3271,7). ismember(3271,8). ismember(3271,11). ismember(3271,12). 
ismember(3272,4). ismember(3272,7). ismember(3272,8). ismember(3272,11). ismember(3272,12). 
ismember(3273,1). ismember(3273,4). ismember(3273,7). ismember(3273,8). ismember(3273,11). ismember(3273,12). 
ismember(3274,2). ismember(3274,4). ismember(3274,7). ismember(3274,8). ismember(3274,11). ismember(3274,12). 
ismember(3275,1). ismember(3275,2). ismember(3275,4). ismember(3275,7). ismember(3275,8). ismember(3275,11). ismember(3275,12). 
ismember(3276,3). ismember(3276,4). ismember(3276,7). ismember(3276,8). ismember(3276,11). ismember(3276,12). 
ismember(3277,1). ismember(3277,3). ismember(3277,4). ismember(3277,7). ismember(3277,8). ismember(3277,11). ismember(3277,12). 
ismember(3278,2). ismember(3278,3). ismember(3278,4). ismember(3278,7). ismember(3278,8). ismember(3278,11). ismember(3278,12). 
ismember(3279,1). ismember(3279,2). ismember(3279,3). ismember(3279,4). ismember(3279,7). ismember(3279,8). ismember(3279,11). ismember(3279,12). 
ismember(3280,5). ismember(3280,7). ismember(3280,8). ismember(3280,11). ismember(3280,12). 
ismember(3281,1). ismember(3281,5). ismember(3281,7). ismember(3281,8). ismember(3281,11). ismember(3281,12). 
ismember(3282,2). ismember(3282,5). ismember(3282,7). ismember(3282,8). ismember(3282,11). ismember(3282,12). 
ismember(3283,1). ismember(3283,2). ismember(3283,5). ismember(3283,7). ismember(3283,8). ismember(3283,11). ismember(3283,12). 
ismember(3284,3). ismember(3284,5). ismember(3284,7). ismember(3284,8). ismember(3284,11). ismember(3284,12). 
ismember(3285,1). ismember(3285,3). ismember(3285,5). ismember(3285,7). ismember(3285,8). ismember(3285,11). ismember(3285,12). 
ismember(3286,2). ismember(3286,3). ismember(3286,5). ismember(3286,7). ismember(3286,8). ismember(3286,11). ismember(3286,12). 
ismember(3287,1). ismember(3287,2). ismember(3287,3). ismember(3287,5). ismember(3287,7). ismember(3287,8). ismember(3287,11). ismember(3287,12). 
ismember(3288,4). ismember(3288,5). ismember(3288,7). ismember(3288,8). ismember(3288,11). ismember(3288,12). 
ismember(3289,1). ismember(3289,4). ismember(3289,5). ismember(3289,7). ismember(3289,8). ismember(3289,11). ismember(3289,12). 
ismember(3290,2). ismember(3290,4). ismember(3290,5). ismember(3290,7). ismember(3290,8). ismember(3290,11). ismember(3290,12). 
ismember(3291,1). ismember(3291,2). ismember(3291,4). ismember(3291,5). ismember(3291,7). ismember(3291,8). ismember(3291,11). ismember(3291,12). 
ismember(3292,3). ismember(3292,4). ismember(3292,5). ismember(3292,7). ismember(3292,8). ismember(3292,11). ismember(3292,12). 
ismember(3293,1). ismember(3293,3). ismember(3293,4). ismember(3293,5). ismember(3293,7). ismember(3293,8). ismember(3293,11). ismember(3293,12). 
ismember(3294,2). ismember(3294,3). ismember(3294,4). ismember(3294,5). ismember(3294,7). ismember(3294,8). ismember(3294,11). ismember(3294,12). 
ismember(3295,1). ismember(3295,2). ismember(3295,3). ismember(3295,4). ismember(3295,5). ismember(3295,7). ismember(3295,8). ismember(3295,11). ismember(3295,12). 
ismember(3296,6). ismember(3296,7). ismember(3296,8). ismember(3296,11). ismember(3296,12). 
ismember(3297,1). ismember(3297,6). ismember(3297,7). ismember(3297,8). ismember(3297,11). ismember(3297,12). 
ismember(3298,2). ismember(3298,6). ismember(3298,7). ismember(3298,8). ismember(3298,11). ismember(3298,12). 
ismember(3299,1). ismember(3299,2). ismember(3299,6). ismember(3299,7). ismember(3299,8). ismember(3299,11). ismember(3299,12). 
ismember(3300,3). ismember(3300,6). ismember(3300,7). ismember(3300,8). ismember(3300,11). ismember(3300,12). 
ismember(3301,1). ismember(3301,3). ismember(3301,6). ismember(3301,7). ismember(3301,8). ismember(3301,11). ismember(3301,12). 
ismember(3302,2). ismember(3302,3). ismember(3302,6). ismember(3302,7). ismember(3302,8). ismember(3302,11). ismember(3302,12). 
ismember(3303,1). ismember(3303,2). ismember(3303,3). ismember(3303,6). ismember(3303,7). ismember(3303,8). ismember(3303,11). ismember(3303,12). 
ismember(3304,4). ismember(3304,6). ismember(3304,7). ismember(3304,8). ismember(3304,11). ismember(3304,12). 
ismember(3305,1). ismember(3305,4). ismember(3305,6). ismember(3305,7). ismember(3305,8). ismember(3305,11). ismember(3305,12). 
ismember(3306,2). ismember(3306,4). ismember(3306,6). ismember(3306,7). ismember(3306,8). ismember(3306,11). ismember(3306,12). 
ismember(3307,1). ismember(3307,2). ismember(3307,4). ismember(3307,6). ismember(3307,7). ismember(3307,8). ismember(3307,11). ismember(3307,12). 
ismember(3308,3). ismember(3308,4). ismember(3308,6). ismember(3308,7). ismember(3308,8). ismember(3308,11). ismember(3308,12). 
ismember(3309,1). ismember(3309,3). ismember(3309,4). ismember(3309,6). ismember(3309,7). ismember(3309,8). ismember(3309,11). ismember(3309,12). 
ismember(3310,2). ismember(3310,3). ismember(3310,4). ismember(3310,6). ismember(3310,7). ismember(3310,8). ismember(3310,11). ismember(3310,12). 
ismember(3311,1). ismember(3311,2). ismember(3311,3). ismember(3311,4). ismember(3311,6). ismember(3311,7). ismember(3311,8). ismember(3311,11). ismember(3311,12). 
ismember(3312,5). ismember(3312,6). ismember(3312,7). ismember(3312,8). ismember(3312,11). ismember(3312,12). 
ismember(3313,1). ismember(3313,5). ismember(3313,6). ismember(3313,7). ismember(3313,8). ismember(3313,11). ismember(3313,12). 
ismember(3314,2). ismember(3314,5). ismember(3314,6). ismember(3314,7). ismember(3314,8). ismember(3314,11). ismember(3314,12). 
ismember(3315,1). ismember(3315,2). ismember(3315,5). ismember(3315,6). ismember(3315,7). ismember(3315,8). ismember(3315,11). ismember(3315,12). 
ismember(3316,3). ismember(3316,5). ismember(3316,6). ismember(3316,7). ismember(3316,8). ismember(3316,11). ismember(3316,12). 
ismember(3317,1). ismember(3317,3). ismember(3317,5). ismember(3317,6). ismember(3317,7). ismember(3317,8). ismember(3317,11). ismember(3317,12). 
ismember(3318,2). ismember(3318,3). ismember(3318,5). ismember(3318,6). ismember(3318,7). ismember(3318,8). ismember(3318,11). ismember(3318,12). 
ismember(3319,1). ismember(3319,2). ismember(3319,3). ismember(3319,5). ismember(3319,6). ismember(3319,7). ismember(3319,8). ismember(3319,11). ismember(3319,12). 
ismember(3320,4). ismember(3320,5). ismember(3320,6). ismember(3320,7). ismember(3320,8). ismember(3320,11). ismember(3320,12). 
ismember(3321,1). ismember(3321,4). ismember(3321,5). ismember(3321,6). ismember(3321,7). ismember(3321,8). ismember(3321,11). ismember(3321,12). 
ismember(3322,2). ismember(3322,4). ismember(3322,5). ismember(3322,6). ismember(3322,7). ismember(3322,8). ismember(3322,11). ismember(3322,12). 
ismember(3323,1). ismember(3323,2). ismember(3323,4). ismember(3323,5). ismember(3323,6). ismember(3323,7). ismember(3323,8). ismember(3323,11). ismember(3323,12). 
ismember(3324,3). ismember(3324,4). ismember(3324,5). ismember(3324,6). ismember(3324,7). ismember(3324,8). ismember(3324,11). ismember(3324,12). 
ismember(3325,1). ismember(3325,3). ismember(3325,4). ismember(3325,5). ismember(3325,6). ismember(3325,7). ismember(3325,8). ismember(3325,11). ismember(3325,12). 
ismember(3326,2). ismember(3326,3). ismember(3326,4). ismember(3326,5). ismember(3326,6). ismember(3326,7). ismember(3326,8). ismember(3326,11). ismember(3326,12). 
ismember(3327,1). ismember(3327,2). ismember(3327,3). ismember(3327,4). ismember(3327,5). ismember(3327,6). ismember(3327,7). ismember(3327,8). ismember(3327,11). ismember(3327,12). 
ismember(3328,9). ismember(3328,11). ismember(3328,12). 
ismember(3329,1). ismember(3329,9). ismember(3329,11). ismember(3329,12). 
ismember(3330,2). ismember(3330,9). ismember(3330,11). ismember(3330,12). 
ismember(3331,1). ismember(3331,2). ismember(3331,9). ismember(3331,11). ismember(3331,12). 
ismember(3332,3). ismember(3332,9). ismember(3332,11). ismember(3332,12). 
ismember(3333,1). ismember(3333,3). ismember(3333,9). ismember(3333,11). ismember(3333,12). 
ismember(3334,2). ismember(3334,3). ismember(3334,9). ismember(3334,11). ismember(3334,12). 
ismember(3335,1). ismember(3335,2). ismember(3335,3). ismember(3335,9). ismember(3335,11). ismember(3335,12). 
ismember(3336,4). ismember(3336,9). ismember(3336,11). ismember(3336,12). 
ismember(3337,1). ismember(3337,4). ismember(3337,9). ismember(3337,11). ismember(3337,12). 
ismember(3338,2). ismember(3338,4). ismember(3338,9). ismember(3338,11). ismember(3338,12). 
ismember(3339,1). ismember(3339,2). ismember(3339,4). ismember(3339,9). ismember(3339,11). ismember(3339,12). 
ismember(3340,3). ismember(3340,4). ismember(3340,9). ismember(3340,11). ismember(3340,12). 
ismember(3341,1). ismember(3341,3). ismember(3341,4). ismember(3341,9). ismember(3341,11). ismember(3341,12). 
ismember(3342,2). ismember(3342,3). ismember(3342,4). ismember(3342,9). ismember(3342,11). ismember(3342,12). 
ismember(3343,1). ismember(3343,2). ismember(3343,3). ismember(3343,4). ismember(3343,9). ismember(3343,11). ismember(3343,12). 
ismember(3344,5). ismember(3344,9). ismember(3344,11). ismember(3344,12). 
ismember(3345,1). ismember(3345,5). ismember(3345,9). ismember(3345,11). ismember(3345,12). 
ismember(3346,2). ismember(3346,5). ismember(3346,9). ismember(3346,11). ismember(3346,12). 
ismember(3347,1). ismember(3347,2). ismember(3347,5). ismember(3347,9). ismember(3347,11). ismember(3347,12). 
ismember(3348,3). ismember(3348,5). ismember(3348,9). ismember(3348,11). ismember(3348,12). 
ismember(3349,1). ismember(3349,3). ismember(3349,5). ismember(3349,9). ismember(3349,11). ismember(3349,12). 
ismember(3350,2). ismember(3350,3). ismember(3350,5). ismember(3350,9). ismember(3350,11). ismember(3350,12). 
ismember(3351,1). ismember(3351,2). ismember(3351,3). ismember(3351,5). ismember(3351,9). ismember(3351,11). ismember(3351,12). 
ismember(3352,4). ismember(3352,5). ismember(3352,9). ismember(3352,11). ismember(3352,12). 
ismember(3353,1). ismember(3353,4). ismember(3353,5). ismember(3353,9). ismember(3353,11). ismember(3353,12). 
ismember(3354,2). ismember(3354,4). ismember(3354,5). ismember(3354,9). ismember(3354,11). ismember(3354,12). 
ismember(3355,1). ismember(3355,2). ismember(3355,4). ismember(3355,5). ismember(3355,9). ismember(3355,11). ismember(3355,12). 
ismember(3356,3). ismember(3356,4). ismember(3356,5). ismember(3356,9). ismember(3356,11). ismember(3356,12). 
ismember(3357,1). ismember(3357,3). ismember(3357,4). ismember(3357,5). ismember(3357,9). ismember(3357,11). ismember(3357,12). 
ismember(3358,2). ismember(3358,3). ismember(3358,4). ismember(3358,5). ismember(3358,9). ismember(3358,11). ismember(3358,12). 
ismember(3359,1). ismember(3359,2). ismember(3359,3). ismember(3359,4). ismember(3359,5). ismember(3359,9). ismember(3359,11). ismember(3359,12). 
ismember(3360,6). ismember(3360,9). ismember(3360,11). ismember(3360,12). 
ismember(3361,1). ismember(3361,6). ismember(3361,9). ismember(3361,11). ismember(3361,12). 
ismember(3362,2). ismember(3362,6). ismember(3362,9). ismember(3362,11). ismember(3362,12). 
ismember(3363,1). ismember(3363,2). ismember(3363,6). ismember(3363,9). ismember(3363,11). ismember(3363,12). 
ismember(3364,3). ismember(3364,6). ismember(3364,9). ismember(3364,11). ismember(3364,12). 
ismember(3365,1). ismember(3365,3). ismember(3365,6). ismember(3365,9). ismember(3365,11). ismember(3365,12). 
ismember(3366,2). ismember(3366,3). ismember(3366,6). ismember(3366,9). ismember(3366,11). ismember(3366,12). 
ismember(3367,1). ismember(3367,2). ismember(3367,3). ismember(3367,6). ismember(3367,9). ismember(3367,11). ismember(3367,12). 
ismember(3368,4). ismember(3368,6). ismember(3368,9). ismember(3368,11). ismember(3368,12). 
ismember(3369,1). ismember(3369,4). ismember(3369,6). ismember(3369,9). ismember(3369,11). ismember(3369,12). 
ismember(3370,2). ismember(3370,4). ismember(3370,6). ismember(3370,9). ismember(3370,11). ismember(3370,12). 
ismember(3371,1). ismember(3371,2). ismember(3371,4). ismember(3371,6). ismember(3371,9). ismember(3371,11). ismember(3371,12). 
ismember(3372,3). ismember(3372,4). ismember(3372,6). ismember(3372,9). ismember(3372,11). ismember(3372,12). 
ismember(3373,1). ismember(3373,3). ismember(3373,4). ismember(3373,6). ismember(3373,9). ismember(3373,11). ismember(3373,12). 
ismember(3374,2). ismember(3374,3). ismember(3374,4). ismember(3374,6). ismember(3374,9). ismember(3374,11). ismember(3374,12). 
ismember(3375,1). ismember(3375,2). ismember(3375,3). ismember(3375,4). ismember(3375,6). ismember(3375,9). ismember(3375,11). ismember(3375,12). 
ismember(3376,5). ismember(3376,6). ismember(3376,9). ismember(3376,11). ismember(3376,12). 
ismember(3377,1). ismember(3377,5). ismember(3377,6). ismember(3377,9). ismember(3377,11). ismember(3377,12). 
ismember(3378,2). ismember(3378,5). ismember(3378,6). ismember(3378,9). ismember(3378,11). ismember(3378,12). 
ismember(3379,1). ismember(3379,2). ismember(3379,5). ismember(3379,6). ismember(3379,9). ismember(3379,11). ismember(3379,12). 
ismember(3380,3). ismember(3380,5). ismember(3380,6). ismember(3380,9). ismember(3380,11). ismember(3380,12). 
ismember(3381,1). ismember(3381,3). ismember(3381,5). ismember(3381,6). ismember(3381,9). ismember(3381,11). ismember(3381,12). 
ismember(3382,2). ismember(3382,3). ismember(3382,5). ismember(3382,6). ismember(3382,9). ismember(3382,11). ismember(3382,12). 
ismember(3383,1). ismember(3383,2). ismember(3383,3). ismember(3383,5). ismember(3383,6). ismember(3383,9). ismember(3383,11). ismember(3383,12). 
ismember(3384,4). ismember(3384,5). ismember(3384,6). ismember(3384,9). ismember(3384,11). ismember(3384,12). 
ismember(3385,1). ismember(3385,4). ismember(3385,5). ismember(3385,6). ismember(3385,9). ismember(3385,11). ismember(3385,12). 
ismember(3386,2). ismember(3386,4). ismember(3386,5). ismember(3386,6). ismember(3386,9). ismember(3386,11). ismember(3386,12). 
ismember(3387,1). ismember(3387,2). ismember(3387,4). ismember(3387,5). ismember(3387,6). ismember(3387,9). ismember(3387,11). ismember(3387,12). 
ismember(3388,3). ismember(3388,4). ismember(3388,5). ismember(3388,6). ismember(3388,9). ismember(3388,11). ismember(3388,12). 
ismember(3389,1). ismember(3389,3). ismember(3389,4). ismember(3389,5). ismember(3389,6). ismember(3389,9). ismember(3389,11). ismember(3389,12). 
ismember(3390,2). ismember(3390,3). ismember(3390,4). ismember(3390,5). ismember(3390,6). ismember(3390,9). ismember(3390,11). ismember(3390,12). 
ismember(3391,1). ismember(3391,2). ismember(3391,3). ismember(3391,4). ismember(3391,5). ismember(3391,6). ismember(3391,9). ismember(3391,11). ismember(3391,12). 
ismember(3392,7). ismember(3392,9). ismember(3392,11). ismember(3392,12). 
ismember(3393,1). ismember(3393,7). ismember(3393,9). ismember(3393,11). ismember(3393,12). 
ismember(3394,2). ismember(3394,7). ismember(3394,9). ismember(3394,11). ismember(3394,12). 
ismember(3395,1). ismember(3395,2). ismember(3395,7). ismember(3395,9). ismember(3395,11). ismember(3395,12). 
ismember(3396,3). ismember(3396,7). ismember(3396,9). ismember(3396,11). ismember(3396,12). 
ismember(3397,1). ismember(3397,3). ismember(3397,7). ismember(3397,9). ismember(3397,11). ismember(3397,12). 
ismember(3398,2). ismember(3398,3). ismember(3398,7). ismember(3398,9). ismember(3398,11). ismember(3398,12). 
ismember(3399,1). ismember(3399,2). ismember(3399,3). ismember(3399,7). ismember(3399,9). ismember(3399,11). ismember(3399,12). 
ismember(3400,4). ismember(3400,7). ismember(3400,9). ismember(3400,11). ismember(3400,12). 
ismember(3401,1). ismember(3401,4). ismember(3401,7). ismember(3401,9). ismember(3401,11). ismember(3401,12). 
ismember(3402,2). ismember(3402,4). ismember(3402,7). ismember(3402,9). ismember(3402,11). ismember(3402,12). 
ismember(3403,1). ismember(3403,2). ismember(3403,4). ismember(3403,7). ismember(3403,9). ismember(3403,11). ismember(3403,12). 
ismember(3404,3). ismember(3404,4). ismember(3404,7). ismember(3404,9). ismember(3404,11). ismember(3404,12). 
ismember(3405,1). ismember(3405,3). ismember(3405,4). ismember(3405,7). ismember(3405,9). ismember(3405,11). ismember(3405,12). 
ismember(3406,2). ismember(3406,3). ismember(3406,4). ismember(3406,7). ismember(3406,9). ismember(3406,11). ismember(3406,12). 
ismember(3407,1). ismember(3407,2). ismember(3407,3). ismember(3407,4). ismember(3407,7). ismember(3407,9). ismember(3407,11). ismember(3407,12). 
ismember(3408,5). ismember(3408,7). ismember(3408,9). ismember(3408,11). ismember(3408,12). 
ismember(3409,1). ismember(3409,5). ismember(3409,7). ismember(3409,9). ismember(3409,11). ismember(3409,12). 
ismember(3410,2). ismember(3410,5). ismember(3410,7). ismember(3410,9). ismember(3410,11). ismember(3410,12). 
ismember(3411,1). ismember(3411,2). ismember(3411,5). ismember(3411,7). ismember(3411,9). ismember(3411,11). ismember(3411,12). 
ismember(3412,3). ismember(3412,5). ismember(3412,7). ismember(3412,9). ismember(3412,11). ismember(3412,12). 
ismember(3413,1). ismember(3413,3). ismember(3413,5). ismember(3413,7). ismember(3413,9). ismember(3413,11). ismember(3413,12). 
ismember(3414,2). ismember(3414,3). ismember(3414,5). ismember(3414,7). ismember(3414,9). ismember(3414,11). ismember(3414,12). 
ismember(3415,1). ismember(3415,2). ismember(3415,3). ismember(3415,5). ismember(3415,7). ismember(3415,9). ismember(3415,11). ismember(3415,12). 
ismember(3416,4). ismember(3416,5). ismember(3416,7). ismember(3416,9). ismember(3416,11). ismember(3416,12). 
ismember(3417,1). ismember(3417,4). ismember(3417,5). ismember(3417,7). ismember(3417,9). ismember(3417,11). ismember(3417,12). 
ismember(3418,2). ismember(3418,4). ismember(3418,5). ismember(3418,7). ismember(3418,9). ismember(3418,11). ismember(3418,12). 
ismember(3419,1). ismember(3419,2). ismember(3419,4). ismember(3419,5). ismember(3419,7). ismember(3419,9). ismember(3419,11). ismember(3419,12). 
ismember(3420,3). ismember(3420,4). ismember(3420,5). ismember(3420,7). ismember(3420,9). ismember(3420,11). ismember(3420,12). 
ismember(3421,1). ismember(3421,3). ismember(3421,4). ismember(3421,5). ismember(3421,7). ismember(3421,9). ismember(3421,11). ismember(3421,12). 
ismember(3422,2). ismember(3422,3). ismember(3422,4). ismember(3422,5). ismember(3422,7). ismember(3422,9). ismember(3422,11). ismember(3422,12). 
ismember(3423,1). ismember(3423,2). ismember(3423,3). ismember(3423,4). ismember(3423,5). ismember(3423,7). ismember(3423,9). ismember(3423,11). ismember(3423,12). 
ismember(3424,6). ismember(3424,7). ismember(3424,9). ismember(3424,11). ismember(3424,12). 
ismember(3425,1). ismember(3425,6). ismember(3425,7). ismember(3425,9). ismember(3425,11). ismember(3425,12). 
ismember(3426,2). ismember(3426,6). ismember(3426,7). ismember(3426,9). ismember(3426,11). ismember(3426,12). 
ismember(3427,1). ismember(3427,2). ismember(3427,6). ismember(3427,7). ismember(3427,9). ismember(3427,11). ismember(3427,12). 
ismember(3428,3). ismember(3428,6). ismember(3428,7). ismember(3428,9). ismember(3428,11). ismember(3428,12). 
ismember(3429,1). ismember(3429,3). ismember(3429,6). ismember(3429,7). ismember(3429,9). ismember(3429,11). ismember(3429,12). 
ismember(3430,2). ismember(3430,3). ismember(3430,6). ismember(3430,7). ismember(3430,9). ismember(3430,11). ismember(3430,12). 
ismember(3431,1). ismember(3431,2). ismember(3431,3). ismember(3431,6). ismember(3431,7). ismember(3431,9). ismember(3431,11). ismember(3431,12). 
ismember(3432,4). ismember(3432,6). ismember(3432,7). ismember(3432,9). ismember(3432,11). ismember(3432,12). 
ismember(3433,1). ismember(3433,4). ismember(3433,6). ismember(3433,7). ismember(3433,9). ismember(3433,11). ismember(3433,12). 
ismember(3434,2). ismember(3434,4). ismember(3434,6). ismember(3434,7). ismember(3434,9). ismember(3434,11). ismember(3434,12). 
ismember(3435,1). ismember(3435,2). ismember(3435,4). ismember(3435,6). ismember(3435,7). ismember(3435,9). ismember(3435,11). ismember(3435,12). 
ismember(3436,3). ismember(3436,4). ismember(3436,6). ismember(3436,7). ismember(3436,9). ismember(3436,11). ismember(3436,12). 
ismember(3437,1). ismember(3437,3). ismember(3437,4). ismember(3437,6). ismember(3437,7). ismember(3437,9). ismember(3437,11). ismember(3437,12). 
ismember(3438,2). ismember(3438,3). ismember(3438,4). ismember(3438,6). ismember(3438,7). ismember(3438,9). ismember(3438,11). ismember(3438,12). 
ismember(3439,1). ismember(3439,2). ismember(3439,3). ismember(3439,4). ismember(3439,6). ismember(3439,7). ismember(3439,9). ismember(3439,11). ismember(3439,12). 
ismember(3440,5). ismember(3440,6). ismember(3440,7). ismember(3440,9). ismember(3440,11). ismember(3440,12). 
ismember(3441,1). ismember(3441,5). ismember(3441,6). ismember(3441,7). ismember(3441,9). ismember(3441,11). ismember(3441,12). 
ismember(3442,2). ismember(3442,5). ismember(3442,6). ismember(3442,7). ismember(3442,9). ismember(3442,11). ismember(3442,12). 
ismember(3443,1). ismember(3443,2). ismember(3443,5). ismember(3443,6). ismember(3443,7). ismember(3443,9). ismember(3443,11). ismember(3443,12). 
ismember(3444,3). ismember(3444,5). ismember(3444,6). ismember(3444,7). ismember(3444,9). ismember(3444,11). ismember(3444,12). 
ismember(3445,1). ismember(3445,3). ismember(3445,5). ismember(3445,6). ismember(3445,7). ismember(3445,9). ismember(3445,11). ismember(3445,12). 
ismember(3446,2). ismember(3446,3). ismember(3446,5). ismember(3446,6). ismember(3446,7). ismember(3446,9). ismember(3446,11). ismember(3446,12). 
ismember(3447,1). ismember(3447,2). ismember(3447,3). ismember(3447,5). ismember(3447,6). ismember(3447,7). ismember(3447,9). ismember(3447,11). ismember(3447,12). 
ismember(3448,4). ismember(3448,5). ismember(3448,6). ismember(3448,7). ismember(3448,9). ismember(3448,11). ismember(3448,12). 
ismember(3449,1). ismember(3449,4). ismember(3449,5). ismember(3449,6). ismember(3449,7). ismember(3449,9). ismember(3449,11). ismember(3449,12). 
ismember(3450,2). ismember(3450,4). ismember(3450,5). ismember(3450,6). ismember(3450,7). ismember(3450,9). ismember(3450,11). ismember(3450,12). 
ismember(3451,1). ismember(3451,2). ismember(3451,4). ismember(3451,5). ismember(3451,6). ismember(3451,7). ismember(3451,9). ismember(3451,11). ismember(3451,12). 
ismember(3452,3). ismember(3452,4). ismember(3452,5). ismember(3452,6). ismember(3452,7). ismember(3452,9). ismember(3452,11). ismember(3452,12). 
ismember(3453,1). ismember(3453,3). ismember(3453,4). ismember(3453,5). ismember(3453,6). ismember(3453,7). ismember(3453,9). ismember(3453,11). ismember(3453,12). 
ismember(3454,2). ismember(3454,3). ismember(3454,4). ismember(3454,5). ismember(3454,6). ismember(3454,7). ismember(3454,9). ismember(3454,11). ismember(3454,12). 
ismember(3455,1). ismember(3455,2). ismember(3455,3). ismember(3455,4). ismember(3455,5). ismember(3455,6). ismember(3455,7). ismember(3455,9). ismember(3455,11). ismember(3455,12). 
ismember(3456,8). ismember(3456,9). ismember(3456,11). ismember(3456,12). 
ismember(3457,1). ismember(3457,8). ismember(3457,9). ismember(3457,11). ismember(3457,12). 
ismember(3458,2). ismember(3458,8). ismember(3458,9). ismember(3458,11). ismember(3458,12). 
ismember(3459,1). ismember(3459,2). ismember(3459,8). ismember(3459,9). ismember(3459,11). ismember(3459,12). 
ismember(3460,3). ismember(3460,8). ismember(3460,9). ismember(3460,11). ismember(3460,12). 
ismember(3461,1). ismember(3461,3). ismember(3461,8). ismember(3461,9). ismember(3461,11). ismember(3461,12). 
ismember(3462,2). ismember(3462,3). ismember(3462,8). ismember(3462,9). ismember(3462,11). ismember(3462,12). 
ismember(3463,1). ismember(3463,2). ismember(3463,3). ismember(3463,8). ismember(3463,9). ismember(3463,11). ismember(3463,12). 
ismember(3464,4). ismember(3464,8). ismember(3464,9). ismember(3464,11). ismember(3464,12). 
ismember(3465,1). ismember(3465,4). ismember(3465,8). ismember(3465,9). ismember(3465,11). ismember(3465,12). 
ismember(3466,2). ismember(3466,4). ismember(3466,8). ismember(3466,9). ismember(3466,11). ismember(3466,12). 
ismember(3467,1). ismember(3467,2). ismember(3467,4). ismember(3467,8). ismember(3467,9). ismember(3467,11). ismember(3467,12). 
ismember(3468,3). ismember(3468,4). ismember(3468,8). ismember(3468,9). ismember(3468,11). ismember(3468,12). 
ismember(3469,1). ismember(3469,3). ismember(3469,4). ismember(3469,8). ismember(3469,9). ismember(3469,11). ismember(3469,12). 
ismember(3470,2). ismember(3470,3). ismember(3470,4). ismember(3470,8). ismember(3470,9). ismember(3470,11). ismember(3470,12). 
ismember(3471,1). ismember(3471,2). ismember(3471,3). ismember(3471,4). ismember(3471,8). ismember(3471,9). ismember(3471,11). ismember(3471,12). 
ismember(3472,5). ismember(3472,8). ismember(3472,9). ismember(3472,11). ismember(3472,12). 
ismember(3473,1). ismember(3473,5). ismember(3473,8). ismember(3473,9). ismember(3473,11). ismember(3473,12). 
ismember(3474,2). ismember(3474,5). ismember(3474,8). ismember(3474,9). ismember(3474,11). ismember(3474,12). 
ismember(3475,1). ismember(3475,2). ismember(3475,5). ismember(3475,8). ismember(3475,9). ismember(3475,11). ismember(3475,12). 
ismember(3476,3). ismember(3476,5). ismember(3476,8). ismember(3476,9). ismember(3476,11). ismember(3476,12). 
ismember(3477,1). ismember(3477,3). ismember(3477,5). ismember(3477,8). ismember(3477,9). ismember(3477,11). ismember(3477,12). 
ismember(3478,2). ismember(3478,3). ismember(3478,5). ismember(3478,8). ismember(3478,9). ismember(3478,11). ismember(3478,12). 
ismember(3479,1). ismember(3479,2). ismember(3479,3). ismember(3479,5). ismember(3479,8). ismember(3479,9). ismember(3479,11). ismember(3479,12). 
ismember(3480,4). ismember(3480,5). ismember(3480,8). ismember(3480,9). ismember(3480,11). ismember(3480,12). 
ismember(3481,1). ismember(3481,4). ismember(3481,5). ismember(3481,8). ismember(3481,9). ismember(3481,11). ismember(3481,12). 
ismember(3482,2). ismember(3482,4). ismember(3482,5). ismember(3482,8). ismember(3482,9). ismember(3482,11). ismember(3482,12). 
ismember(3483,1). ismember(3483,2). ismember(3483,4). ismember(3483,5). ismember(3483,8). ismember(3483,9). ismember(3483,11). ismember(3483,12). 
ismember(3484,3). ismember(3484,4). ismember(3484,5). ismember(3484,8). ismember(3484,9). ismember(3484,11). ismember(3484,12). 
ismember(3485,1). ismember(3485,3). ismember(3485,4). ismember(3485,5). ismember(3485,8). ismember(3485,9). ismember(3485,11). ismember(3485,12). 
ismember(3486,2). ismember(3486,3). ismember(3486,4). ismember(3486,5). ismember(3486,8). ismember(3486,9). ismember(3486,11). ismember(3486,12). 
ismember(3487,1). ismember(3487,2). ismember(3487,3). ismember(3487,4). ismember(3487,5). ismember(3487,8). ismember(3487,9). ismember(3487,11). ismember(3487,12). 
ismember(3488,6). ismember(3488,8). ismember(3488,9). ismember(3488,11). ismember(3488,12). 
ismember(3489,1). ismember(3489,6). ismember(3489,8). ismember(3489,9). ismember(3489,11). ismember(3489,12). 
ismember(3490,2). ismember(3490,6). ismember(3490,8). ismember(3490,9). ismember(3490,11). ismember(3490,12). 
ismember(3491,1). ismember(3491,2). ismember(3491,6). ismember(3491,8). ismember(3491,9). ismember(3491,11). ismember(3491,12). 
ismember(3492,3). ismember(3492,6). ismember(3492,8). ismember(3492,9). ismember(3492,11). ismember(3492,12). 
ismember(3493,1). ismember(3493,3). ismember(3493,6). ismember(3493,8). ismember(3493,9). ismember(3493,11). ismember(3493,12). 
ismember(3494,2). ismember(3494,3). ismember(3494,6). ismember(3494,8). ismember(3494,9). ismember(3494,11). ismember(3494,12). 
ismember(3495,1). ismember(3495,2). ismember(3495,3). ismember(3495,6). ismember(3495,8). ismember(3495,9). ismember(3495,11). ismember(3495,12). 
ismember(3496,4). ismember(3496,6). ismember(3496,8). ismember(3496,9). ismember(3496,11). ismember(3496,12). 
ismember(3497,1). ismember(3497,4). ismember(3497,6). ismember(3497,8). ismember(3497,9). ismember(3497,11). ismember(3497,12). 
ismember(3498,2). ismember(3498,4). ismember(3498,6). ismember(3498,8). ismember(3498,9). ismember(3498,11). ismember(3498,12). 
ismember(3499,1). ismember(3499,2). ismember(3499,4). ismember(3499,6). ismember(3499,8). ismember(3499,9). ismember(3499,11). ismember(3499,12). 
ismember(3500,3). ismember(3500,4). ismember(3500,6). ismember(3500,8). ismember(3500,9). ismember(3500,11). ismember(3500,12). 
ismember(3501,1). ismember(3501,3). ismember(3501,4). ismember(3501,6). ismember(3501,8). ismember(3501,9). ismember(3501,11). ismember(3501,12). 
ismember(3502,2). ismember(3502,3). ismember(3502,4). ismember(3502,6). ismember(3502,8). ismember(3502,9). ismember(3502,11). ismember(3502,12). 
ismember(3503,1). ismember(3503,2). ismember(3503,3). ismember(3503,4). ismember(3503,6). ismember(3503,8). ismember(3503,9). ismember(3503,11). ismember(3503,12). 
ismember(3504,5). ismember(3504,6). ismember(3504,8). ismember(3504,9). ismember(3504,11). ismember(3504,12). 
ismember(3505,1). ismember(3505,5). ismember(3505,6). ismember(3505,8). ismember(3505,9). ismember(3505,11). ismember(3505,12). 
ismember(3506,2). ismember(3506,5). ismember(3506,6). ismember(3506,8). ismember(3506,9). ismember(3506,11). ismember(3506,12). 
ismember(3507,1). ismember(3507,2). ismember(3507,5). ismember(3507,6). ismember(3507,8). ismember(3507,9). ismember(3507,11). ismember(3507,12). 
ismember(3508,3). ismember(3508,5). ismember(3508,6). ismember(3508,8). ismember(3508,9). ismember(3508,11). ismember(3508,12). 
ismember(3509,1). ismember(3509,3). ismember(3509,5). ismember(3509,6). ismember(3509,8). ismember(3509,9). ismember(3509,11). ismember(3509,12). 
ismember(3510,2). ismember(3510,3). ismember(3510,5). ismember(3510,6). ismember(3510,8). ismember(3510,9). ismember(3510,11). ismember(3510,12). 
ismember(3511,1). ismember(3511,2). ismember(3511,3). ismember(3511,5). ismember(3511,6). ismember(3511,8). ismember(3511,9). ismember(3511,11). ismember(3511,12). 
ismember(3512,4). ismember(3512,5). ismember(3512,6). ismember(3512,8). ismember(3512,9). ismember(3512,11). ismember(3512,12). 
ismember(3513,1). ismember(3513,4). ismember(3513,5). ismember(3513,6). ismember(3513,8). ismember(3513,9). ismember(3513,11). ismember(3513,12). 
ismember(3514,2). ismember(3514,4). ismember(3514,5). ismember(3514,6). ismember(3514,8). ismember(3514,9). ismember(3514,11). ismember(3514,12). 
ismember(3515,1). ismember(3515,2). ismember(3515,4). ismember(3515,5). ismember(3515,6). ismember(3515,8). ismember(3515,9). ismember(3515,11). ismember(3515,12). 
ismember(3516,3). ismember(3516,4). ismember(3516,5). ismember(3516,6). ismember(3516,8). ismember(3516,9). ismember(3516,11). ismember(3516,12). 
ismember(3517,1). ismember(3517,3). ismember(3517,4). ismember(3517,5). ismember(3517,6). ismember(3517,8). ismember(3517,9). ismember(3517,11). ismember(3517,12). 
ismember(3518,2). ismember(3518,3). ismember(3518,4). ismember(3518,5). ismember(3518,6). ismember(3518,8). ismember(3518,9). ismember(3518,11). ismember(3518,12). 
ismember(3519,1). ismember(3519,2). ismember(3519,3). ismember(3519,4). ismember(3519,5). ismember(3519,6). ismember(3519,8). ismember(3519,9). ismember(3519,11). ismember(3519,12). 
ismember(3520,7). ismember(3520,8). ismember(3520,9). ismember(3520,11). ismember(3520,12). 
ismember(3521,1). ismember(3521,7). ismember(3521,8). ismember(3521,9). ismember(3521,11). ismember(3521,12). 
ismember(3522,2). ismember(3522,7). ismember(3522,8). ismember(3522,9). ismember(3522,11). ismember(3522,12). 
ismember(3523,1). ismember(3523,2). ismember(3523,7). ismember(3523,8). ismember(3523,9). ismember(3523,11). ismember(3523,12). 
ismember(3524,3). ismember(3524,7). ismember(3524,8). ismember(3524,9). ismember(3524,11). ismember(3524,12). 
ismember(3525,1). ismember(3525,3). ismember(3525,7). ismember(3525,8). ismember(3525,9). ismember(3525,11). ismember(3525,12). 
ismember(3526,2). ismember(3526,3). ismember(3526,7). ismember(3526,8). ismember(3526,9). ismember(3526,11). ismember(3526,12). 
ismember(3527,1). ismember(3527,2). ismember(3527,3). ismember(3527,7). ismember(3527,8). ismember(3527,9). ismember(3527,11). ismember(3527,12). 
ismember(3528,4). ismember(3528,7). ismember(3528,8). ismember(3528,9). ismember(3528,11). ismember(3528,12). 
ismember(3529,1). ismember(3529,4). ismember(3529,7). ismember(3529,8). ismember(3529,9). ismember(3529,11). ismember(3529,12). 
ismember(3530,2). ismember(3530,4). ismember(3530,7). ismember(3530,8). ismember(3530,9). ismember(3530,11). ismember(3530,12). 
ismember(3531,1). ismember(3531,2). ismember(3531,4). ismember(3531,7). ismember(3531,8). ismember(3531,9). ismember(3531,11). ismember(3531,12). 
ismember(3532,3). ismember(3532,4). ismember(3532,7). ismember(3532,8). ismember(3532,9). ismember(3532,11). ismember(3532,12). 
ismember(3533,1). ismember(3533,3). ismember(3533,4). ismember(3533,7). ismember(3533,8). ismember(3533,9). ismember(3533,11). ismember(3533,12). 
ismember(3534,2). ismember(3534,3). ismember(3534,4). ismember(3534,7). ismember(3534,8). ismember(3534,9). ismember(3534,11). ismember(3534,12). 
ismember(3535,1). ismember(3535,2). ismember(3535,3). ismember(3535,4). ismember(3535,7). ismember(3535,8). ismember(3535,9). ismember(3535,11). ismember(3535,12). 
ismember(3536,5). ismember(3536,7). ismember(3536,8). ismember(3536,9). ismember(3536,11). ismember(3536,12). 
ismember(3537,1). ismember(3537,5). ismember(3537,7). ismember(3537,8). ismember(3537,9). ismember(3537,11). ismember(3537,12). 
ismember(3538,2). ismember(3538,5). ismember(3538,7). ismember(3538,8). ismember(3538,9). ismember(3538,11). ismember(3538,12). 
ismember(3539,1). ismember(3539,2). ismember(3539,5). ismember(3539,7). ismember(3539,8). ismember(3539,9). ismember(3539,11). ismember(3539,12). 
ismember(3540,3). ismember(3540,5). ismember(3540,7). ismember(3540,8). ismember(3540,9). ismember(3540,11). ismember(3540,12). 
ismember(3541,1). ismember(3541,3). ismember(3541,5). ismember(3541,7). ismember(3541,8). ismember(3541,9). ismember(3541,11). ismember(3541,12). 
ismember(3542,2). ismember(3542,3). ismember(3542,5). ismember(3542,7). ismember(3542,8). ismember(3542,9). ismember(3542,11). ismember(3542,12). 
ismember(3543,1). ismember(3543,2). ismember(3543,3). ismember(3543,5). ismember(3543,7). ismember(3543,8). ismember(3543,9). ismember(3543,11). ismember(3543,12). 
ismember(3544,4). ismember(3544,5). ismember(3544,7). ismember(3544,8). ismember(3544,9). ismember(3544,11). ismember(3544,12). 
ismember(3545,1). ismember(3545,4). ismember(3545,5). ismember(3545,7). ismember(3545,8). ismember(3545,9). ismember(3545,11). ismember(3545,12). 
ismember(3546,2). ismember(3546,4). ismember(3546,5). ismember(3546,7). ismember(3546,8). ismember(3546,9). ismember(3546,11). ismember(3546,12). 
ismember(3547,1). ismember(3547,2). ismember(3547,4). ismember(3547,5). ismember(3547,7). ismember(3547,8). ismember(3547,9). ismember(3547,11). ismember(3547,12). 
ismember(3548,3). ismember(3548,4). ismember(3548,5). ismember(3548,7). ismember(3548,8). ismember(3548,9). ismember(3548,11). ismember(3548,12). 
ismember(3549,1). ismember(3549,3). ismember(3549,4). ismember(3549,5). ismember(3549,7). ismember(3549,8). ismember(3549,9). ismember(3549,11). ismember(3549,12). 
ismember(3550,2). ismember(3550,3). ismember(3550,4). ismember(3550,5). ismember(3550,7). ismember(3550,8). ismember(3550,9). ismember(3550,11). ismember(3550,12). 
ismember(3551,1). ismember(3551,2). ismember(3551,3). ismember(3551,4). ismember(3551,5). ismember(3551,7). ismember(3551,8). ismember(3551,9). ismember(3551,11). ismember(3551,12). 
ismember(3552,6). ismember(3552,7). ismember(3552,8). ismember(3552,9). ismember(3552,11). ismember(3552,12). 
ismember(3553,1). ismember(3553,6). ismember(3553,7). ismember(3553,8). ismember(3553,9). ismember(3553,11). ismember(3553,12). 
ismember(3554,2). ismember(3554,6). ismember(3554,7). ismember(3554,8). ismember(3554,9). ismember(3554,11). ismember(3554,12). 
ismember(3555,1). ismember(3555,2). ismember(3555,6). ismember(3555,7). ismember(3555,8). ismember(3555,9). ismember(3555,11). ismember(3555,12). 
ismember(3556,3). ismember(3556,6). ismember(3556,7). ismember(3556,8). ismember(3556,9). ismember(3556,11). ismember(3556,12). 
ismember(3557,1). ismember(3557,3). ismember(3557,6). ismember(3557,7). ismember(3557,8). ismember(3557,9). ismember(3557,11). ismember(3557,12). 
ismember(3558,2). ismember(3558,3). ismember(3558,6). ismember(3558,7). ismember(3558,8). ismember(3558,9). ismember(3558,11). ismember(3558,12). 
ismember(3559,1). ismember(3559,2). ismember(3559,3). ismember(3559,6). ismember(3559,7). ismember(3559,8). ismember(3559,9). ismember(3559,11). ismember(3559,12). 
ismember(3560,4). ismember(3560,6). ismember(3560,7). ismember(3560,8). ismember(3560,9). ismember(3560,11). ismember(3560,12). 
ismember(3561,1). ismember(3561,4). ismember(3561,6). ismember(3561,7). ismember(3561,8). ismember(3561,9). ismember(3561,11). ismember(3561,12). 
ismember(3562,2). ismember(3562,4). ismember(3562,6). ismember(3562,7). ismember(3562,8). ismember(3562,9). ismember(3562,11). ismember(3562,12). 
ismember(3563,1). ismember(3563,2). ismember(3563,4). ismember(3563,6). ismember(3563,7). ismember(3563,8). ismember(3563,9). ismember(3563,11). ismember(3563,12). 
ismember(3564,3). ismember(3564,4). ismember(3564,6). ismember(3564,7). ismember(3564,8). ismember(3564,9). ismember(3564,11). ismember(3564,12). 
ismember(3565,1). ismember(3565,3). ismember(3565,4). ismember(3565,6). ismember(3565,7). ismember(3565,8). ismember(3565,9). ismember(3565,11). ismember(3565,12). 
ismember(3566,2). ismember(3566,3). ismember(3566,4). ismember(3566,6). ismember(3566,7). ismember(3566,8). ismember(3566,9). ismember(3566,11). ismember(3566,12). 
ismember(3567,1). ismember(3567,2). ismember(3567,3). ismember(3567,4). ismember(3567,6). ismember(3567,7). ismember(3567,8). ismember(3567,9). ismember(3567,11). ismember(3567,12). 
ismember(3568,5). ismember(3568,6). ismember(3568,7). ismember(3568,8). ismember(3568,9). ismember(3568,11). ismember(3568,12). 
ismember(3569,1). ismember(3569,5). ismember(3569,6). ismember(3569,7). ismember(3569,8). ismember(3569,9). ismember(3569,11). ismember(3569,12). 
ismember(3570,2). ismember(3570,5). ismember(3570,6). ismember(3570,7). ismember(3570,8). ismember(3570,9). ismember(3570,11). ismember(3570,12). 
ismember(3571,1). ismember(3571,2). ismember(3571,5). ismember(3571,6). ismember(3571,7). ismember(3571,8). ismember(3571,9). ismember(3571,11). ismember(3571,12). 
ismember(3572,3). ismember(3572,5). ismember(3572,6). ismember(3572,7). ismember(3572,8). ismember(3572,9). ismember(3572,11). ismember(3572,12). 
ismember(3573,1). ismember(3573,3). ismember(3573,5). ismember(3573,6). ismember(3573,7). ismember(3573,8). ismember(3573,9). ismember(3573,11). ismember(3573,12). 
ismember(3574,2). ismember(3574,3). ismember(3574,5). ismember(3574,6). ismember(3574,7). ismember(3574,8). ismember(3574,9). ismember(3574,11). ismember(3574,12). 
ismember(3575,1). ismember(3575,2). ismember(3575,3). ismember(3575,5). ismember(3575,6). ismember(3575,7). ismember(3575,8). ismember(3575,9). ismember(3575,11). ismember(3575,12). 
ismember(3576,4). ismember(3576,5). ismember(3576,6). ismember(3576,7). ismember(3576,8). ismember(3576,9). ismember(3576,11). ismember(3576,12). 
ismember(3577,1). ismember(3577,4). ismember(3577,5). ismember(3577,6). ismember(3577,7). ismember(3577,8). ismember(3577,9). ismember(3577,11). ismember(3577,12). 
ismember(3578,2). ismember(3578,4). ismember(3578,5). ismember(3578,6). ismember(3578,7). ismember(3578,8). ismember(3578,9). ismember(3578,11). ismember(3578,12). 
ismember(3579,1). ismember(3579,2). ismember(3579,4). ismember(3579,5). ismember(3579,6). ismember(3579,7). ismember(3579,8). ismember(3579,9). ismember(3579,11). ismember(3579,12). 
ismember(3580,3). ismember(3580,4). ismember(3580,5). ismember(3580,6). ismember(3580,7). ismember(3580,8). ismember(3580,9). ismember(3580,11). ismember(3580,12). 
ismember(3581,1). ismember(3581,3). ismember(3581,4). ismember(3581,5). ismember(3581,6). ismember(3581,7). ismember(3581,8). ismember(3581,9). ismember(3581,11). ismember(3581,12). 
ismember(3582,2). ismember(3582,3). ismember(3582,4). ismember(3582,5). ismember(3582,6). ismember(3582,7). ismember(3582,8). ismember(3582,9). ismember(3582,11). ismember(3582,12). 
ismember(3583,1). ismember(3583,2). ismember(3583,3). ismember(3583,4). ismember(3583,5). ismember(3583,6). ismember(3583,7). ismember(3583,8). ismember(3583,9). ismember(3583,11). ismember(3583,12). 
ismember(3584,10). ismember(3584,11). ismember(3584,12). 
ismember(3585,1). ismember(3585,10). ismember(3585,11). ismember(3585,12). 
ismember(3586,2). ismember(3586,10). ismember(3586,11). ismember(3586,12). 
ismember(3587,1). ismember(3587,2). ismember(3587,10). ismember(3587,11). ismember(3587,12). 
ismember(3588,3). ismember(3588,10). ismember(3588,11). ismember(3588,12). 
ismember(3589,1). ismember(3589,3). ismember(3589,10). ismember(3589,11). ismember(3589,12). 
ismember(3590,2). ismember(3590,3). ismember(3590,10). ismember(3590,11). ismember(3590,12). 
ismember(3591,1). ismember(3591,2). ismember(3591,3). ismember(3591,10). ismember(3591,11). ismember(3591,12). 
ismember(3592,4). ismember(3592,10). ismember(3592,11). ismember(3592,12). 
ismember(3593,1). ismember(3593,4). ismember(3593,10). ismember(3593,11). ismember(3593,12). 
ismember(3594,2). ismember(3594,4). ismember(3594,10). ismember(3594,11). ismember(3594,12). 
ismember(3595,1). ismember(3595,2). ismember(3595,4). ismember(3595,10). ismember(3595,11). ismember(3595,12). 
ismember(3596,3). ismember(3596,4). ismember(3596,10). ismember(3596,11). ismember(3596,12). 
ismember(3597,1). ismember(3597,3). ismember(3597,4). ismember(3597,10). ismember(3597,11). ismember(3597,12). 
ismember(3598,2). ismember(3598,3). ismember(3598,4). ismember(3598,10). ismember(3598,11). ismember(3598,12). 
ismember(3599,1). ismember(3599,2). ismember(3599,3). ismember(3599,4). ismember(3599,10). ismember(3599,11). ismember(3599,12). 
ismember(3600,5). ismember(3600,10). ismember(3600,11). ismember(3600,12). 
ismember(3601,1). ismember(3601,5). ismember(3601,10). ismember(3601,11). ismember(3601,12). 
ismember(3602,2). ismember(3602,5). ismember(3602,10). ismember(3602,11). ismember(3602,12). 
ismember(3603,1). ismember(3603,2). ismember(3603,5). ismember(3603,10). ismember(3603,11). ismember(3603,12). 
ismember(3604,3). ismember(3604,5). ismember(3604,10). ismember(3604,11). ismember(3604,12). 
ismember(3605,1). ismember(3605,3). ismember(3605,5). ismember(3605,10). ismember(3605,11). ismember(3605,12). 
ismember(3606,2). ismember(3606,3). ismember(3606,5). ismember(3606,10). ismember(3606,11). ismember(3606,12). 
ismember(3607,1). ismember(3607,2). ismember(3607,3). ismember(3607,5). ismember(3607,10). ismember(3607,11). ismember(3607,12). 
ismember(3608,4). ismember(3608,5). ismember(3608,10). ismember(3608,11). ismember(3608,12). 
ismember(3609,1). ismember(3609,4). ismember(3609,5). ismember(3609,10). ismember(3609,11). ismember(3609,12). 
ismember(3610,2). ismember(3610,4). ismember(3610,5). ismember(3610,10). ismember(3610,11). ismember(3610,12). 
ismember(3611,1). ismember(3611,2). ismember(3611,4). ismember(3611,5). ismember(3611,10). ismember(3611,11). ismember(3611,12). 
ismember(3612,3). ismember(3612,4). ismember(3612,5). ismember(3612,10). ismember(3612,11). ismember(3612,12). 
ismember(3613,1). ismember(3613,3). ismember(3613,4). ismember(3613,5). ismember(3613,10). ismember(3613,11). ismember(3613,12). 
ismember(3614,2). ismember(3614,3). ismember(3614,4). ismember(3614,5). ismember(3614,10). ismember(3614,11). ismember(3614,12). 
ismember(3615,1). ismember(3615,2). ismember(3615,3). ismember(3615,4). ismember(3615,5). ismember(3615,10). ismember(3615,11). ismember(3615,12). 
ismember(3616,6). ismember(3616,10). ismember(3616,11). ismember(3616,12). 
ismember(3617,1). ismember(3617,6). ismember(3617,10). ismember(3617,11). ismember(3617,12). 
ismember(3618,2). ismember(3618,6). ismember(3618,10). ismember(3618,11). ismember(3618,12). 
ismember(3619,1). ismember(3619,2). ismember(3619,6). ismember(3619,10). ismember(3619,11). ismember(3619,12). 
ismember(3620,3). ismember(3620,6). ismember(3620,10). ismember(3620,11). ismember(3620,12). 
ismember(3621,1). ismember(3621,3). ismember(3621,6). ismember(3621,10). ismember(3621,11). ismember(3621,12). 
ismember(3622,2). ismember(3622,3). ismember(3622,6). ismember(3622,10). ismember(3622,11). ismember(3622,12). 
ismember(3623,1). ismember(3623,2). ismember(3623,3). ismember(3623,6). ismember(3623,10). ismember(3623,11). ismember(3623,12). 
ismember(3624,4). ismember(3624,6). ismember(3624,10). ismember(3624,11). ismember(3624,12). 
ismember(3625,1). ismember(3625,4). ismember(3625,6). ismember(3625,10). ismember(3625,11). ismember(3625,12). 
ismember(3626,2). ismember(3626,4). ismember(3626,6). ismember(3626,10). ismember(3626,11). ismember(3626,12). 
ismember(3627,1). ismember(3627,2). ismember(3627,4). ismember(3627,6). ismember(3627,10). ismember(3627,11). ismember(3627,12). 
ismember(3628,3). ismember(3628,4). ismember(3628,6). ismember(3628,10). ismember(3628,11). ismember(3628,12). 
ismember(3629,1). ismember(3629,3). ismember(3629,4). ismember(3629,6). ismember(3629,10). ismember(3629,11). ismember(3629,12). 
ismember(3630,2). ismember(3630,3). ismember(3630,4). ismember(3630,6). ismember(3630,10). ismember(3630,11). ismember(3630,12). 
ismember(3631,1). ismember(3631,2). ismember(3631,3). ismember(3631,4). ismember(3631,6). ismember(3631,10). ismember(3631,11). ismember(3631,12). 
ismember(3632,5). ismember(3632,6). ismember(3632,10). ismember(3632,11). ismember(3632,12). 
ismember(3633,1). ismember(3633,5). ismember(3633,6). ismember(3633,10). ismember(3633,11). ismember(3633,12). 
ismember(3634,2). ismember(3634,5). ismember(3634,6). ismember(3634,10). ismember(3634,11). ismember(3634,12). 
ismember(3635,1). ismember(3635,2). ismember(3635,5). ismember(3635,6). ismember(3635,10). ismember(3635,11). ismember(3635,12). 
ismember(3636,3). ismember(3636,5). ismember(3636,6). ismember(3636,10). ismember(3636,11). ismember(3636,12). 
ismember(3637,1). ismember(3637,3). ismember(3637,5). ismember(3637,6). ismember(3637,10). ismember(3637,11). ismember(3637,12). 
ismember(3638,2). ismember(3638,3). ismember(3638,5). ismember(3638,6). ismember(3638,10). ismember(3638,11). ismember(3638,12). 
ismember(3639,1). ismember(3639,2). ismember(3639,3). ismember(3639,5). ismember(3639,6). ismember(3639,10). ismember(3639,11). ismember(3639,12). 
ismember(3640,4). ismember(3640,5). ismember(3640,6). ismember(3640,10). ismember(3640,11). ismember(3640,12). 
ismember(3641,1). ismember(3641,4). ismember(3641,5). ismember(3641,6). ismember(3641,10). ismember(3641,11). ismember(3641,12). 
ismember(3642,2). ismember(3642,4). ismember(3642,5). ismember(3642,6). ismember(3642,10). ismember(3642,11). ismember(3642,12). 
ismember(3643,1). ismember(3643,2). ismember(3643,4). ismember(3643,5). ismember(3643,6). ismember(3643,10). ismember(3643,11). ismember(3643,12). 
ismember(3644,3). ismember(3644,4). ismember(3644,5). ismember(3644,6). ismember(3644,10). ismember(3644,11). ismember(3644,12). 
ismember(3645,1). ismember(3645,3). ismember(3645,4). ismember(3645,5). ismember(3645,6). ismember(3645,10). ismember(3645,11). ismember(3645,12). 
ismember(3646,2). ismember(3646,3). ismember(3646,4). ismember(3646,5). ismember(3646,6). ismember(3646,10). ismember(3646,11). ismember(3646,12). 
ismember(3647,1). ismember(3647,2). ismember(3647,3). ismember(3647,4). ismember(3647,5). ismember(3647,6). ismember(3647,10). ismember(3647,11). ismember(3647,12). 
ismember(3648,7). ismember(3648,10). ismember(3648,11). ismember(3648,12). 
ismember(3649,1). ismember(3649,7). ismember(3649,10). ismember(3649,11). ismember(3649,12). 
ismember(3650,2). ismember(3650,7). ismember(3650,10). ismember(3650,11). ismember(3650,12). 
ismember(3651,1). ismember(3651,2). ismember(3651,7). ismember(3651,10). ismember(3651,11). ismember(3651,12). 
ismember(3652,3). ismember(3652,7). ismember(3652,10). ismember(3652,11). ismember(3652,12). 
ismember(3653,1). ismember(3653,3). ismember(3653,7). ismember(3653,10). ismember(3653,11). ismember(3653,12). 
ismember(3654,2). ismember(3654,3). ismember(3654,7). ismember(3654,10). ismember(3654,11). ismember(3654,12). 
ismember(3655,1). ismember(3655,2). ismember(3655,3). ismember(3655,7). ismember(3655,10). ismember(3655,11). ismember(3655,12). 
ismember(3656,4). ismember(3656,7). ismember(3656,10). ismember(3656,11). ismember(3656,12). 
ismember(3657,1). ismember(3657,4). ismember(3657,7). ismember(3657,10). ismember(3657,11). ismember(3657,12). 
ismember(3658,2). ismember(3658,4). ismember(3658,7). ismember(3658,10). ismember(3658,11). ismember(3658,12). 
ismember(3659,1). ismember(3659,2). ismember(3659,4). ismember(3659,7). ismember(3659,10). ismember(3659,11). ismember(3659,12). 
ismember(3660,3). ismember(3660,4). ismember(3660,7). ismember(3660,10). ismember(3660,11). ismember(3660,12). 
ismember(3661,1). ismember(3661,3). ismember(3661,4). ismember(3661,7). ismember(3661,10). ismember(3661,11). ismember(3661,12). 
ismember(3662,2). ismember(3662,3). ismember(3662,4). ismember(3662,7). ismember(3662,10). ismember(3662,11). ismember(3662,12). 
ismember(3663,1). ismember(3663,2). ismember(3663,3). ismember(3663,4). ismember(3663,7). ismember(3663,10). ismember(3663,11). ismember(3663,12). 
ismember(3664,5). ismember(3664,7). ismember(3664,10). ismember(3664,11). ismember(3664,12). 
ismember(3665,1). ismember(3665,5). ismember(3665,7). ismember(3665,10). ismember(3665,11). ismember(3665,12). 
ismember(3666,2). ismember(3666,5). ismember(3666,7). ismember(3666,10). ismember(3666,11). ismember(3666,12). 
ismember(3667,1). ismember(3667,2). ismember(3667,5). ismember(3667,7). ismember(3667,10). ismember(3667,11). ismember(3667,12). 
ismember(3668,3). ismember(3668,5). ismember(3668,7). ismember(3668,10). ismember(3668,11). ismember(3668,12). 
ismember(3669,1). ismember(3669,3). ismember(3669,5). ismember(3669,7). ismember(3669,10). ismember(3669,11). ismember(3669,12). 
ismember(3670,2). ismember(3670,3). ismember(3670,5). ismember(3670,7). ismember(3670,10). ismember(3670,11). ismember(3670,12). 
ismember(3671,1). ismember(3671,2). ismember(3671,3). ismember(3671,5). ismember(3671,7). ismember(3671,10). ismember(3671,11). ismember(3671,12). 
ismember(3672,4). ismember(3672,5). ismember(3672,7). ismember(3672,10). ismember(3672,11). ismember(3672,12). 
ismember(3673,1). ismember(3673,4). ismember(3673,5). ismember(3673,7). ismember(3673,10). ismember(3673,11). ismember(3673,12). 
ismember(3674,2). ismember(3674,4). ismember(3674,5). ismember(3674,7). ismember(3674,10). ismember(3674,11). ismember(3674,12). 
ismember(3675,1). ismember(3675,2). ismember(3675,4). ismember(3675,5). ismember(3675,7). ismember(3675,10). ismember(3675,11). ismember(3675,12). 
ismember(3676,3). ismember(3676,4). ismember(3676,5). ismember(3676,7). ismember(3676,10). ismember(3676,11). ismember(3676,12). 
ismember(3677,1). ismember(3677,3). ismember(3677,4). ismember(3677,5). ismember(3677,7). ismember(3677,10). ismember(3677,11). ismember(3677,12). 
ismember(3678,2). ismember(3678,3). ismember(3678,4). ismember(3678,5). ismember(3678,7). ismember(3678,10). ismember(3678,11). ismember(3678,12). 
ismember(3679,1). ismember(3679,2). ismember(3679,3). ismember(3679,4). ismember(3679,5). ismember(3679,7). ismember(3679,10). ismember(3679,11). ismember(3679,12). 
ismember(3680,6). ismember(3680,7). ismember(3680,10). ismember(3680,11). ismember(3680,12). 
ismember(3681,1). ismember(3681,6). ismember(3681,7). ismember(3681,10). ismember(3681,11). ismember(3681,12). 
ismember(3682,2). ismember(3682,6). ismember(3682,7). ismember(3682,10). ismember(3682,11). ismember(3682,12). 
ismember(3683,1). ismember(3683,2). ismember(3683,6). ismember(3683,7). ismember(3683,10). ismember(3683,11). ismember(3683,12). 
ismember(3684,3). ismember(3684,6). ismember(3684,7). ismember(3684,10). ismember(3684,11). ismember(3684,12). 
ismember(3685,1). ismember(3685,3). ismember(3685,6). ismember(3685,7). ismember(3685,10). ismember(3685,11). ismember(3685,12). 
ismember(3686,2). ismember(3686,3). ismember(3686,6). ismember(3686,7). ismember(3686,10). ismember(3686,11). ismember(3686,12). 
ismember(3687,1). ismember(3687,2). ismember(3687,3). ismember(3687,6). ismember(3687,7). ismember(3687,10). ismember(3687,11). ismember(3687,12). 
ismember(3688,4). ismember(3688,6). ismember(3688,7). ismember(3688,10). ismember(3688,11). ismember(3688,12). 
ismember(3689,1). ismember(3689,4). ismember(3689,6). ismember(3689,7). ismember(3689,10). ismember(3689,11). ismember(3689,12). 
ismember(3690,2). ismember(3690,4). ismember(3690,6). ismember(3690,7). ismember(3690,10). ismember(3690,11). ismember(3690,12). 
ismember(3691,1). ismember(3691,2). ismember(3691,4). ismember(3691,6). ismember(3691,7). ismember(3691,10). ismember(3691,11). ismember(3691,12). 
ismember(3692,3). ismember(3692,4). ismember(3692,6). ismember(3692,7). ismember(3692,10). ismember(3692,11). ismember(3692,12). 
ismember(3693,1). ismember(3693,3). ismember(3693,4). ismember(3693,6). ismember(3693,7). ismember(3693,10). ismember(3693,11). ismember(3693,12). 
ismember(3694,2). ismember(3694,3). ismember(3694,4). ismember(3694,6). ismember(3694,7). ismember(3694,10). ismember(3694,11). ismember(3694,12). 
ismember(3695,1). ismember(3695,2). ismember(3695,3). ismember(3695,4). ismember(3695,6). ismember(3695,7). ismember(3695,10). ismember(3695,11). ismember(3695,12). 
ismember(3696,5). ismember(3696,6). ismember(3696,7). ismember(3696,10). ismember(3696,11). ismember(3696,12). 
ismember(3697,1). ismember(3697,5). ismember(3697,6). ismember(3697,7). ismember(3697,10). ismember(3697,11). ismember(3697,12). 
ismember(3698,2). ismember(3698,5). ismember(3698,6). ismember(3698,7). ismember(3698,10). ismember(3698,11). ismember(3698,12). 
ismember(3699,1). ismember(3699,2). ismember(3699,5). ismember(3699,6). ismember(3699,7). ismember(3699,10). ismember(3699,11). ismember(3699,12). 
ismember(3700,3). ismember(3700,5). ismember(3700,6). ismember(3700,7). ismember(3700,10). ismember(3700,11). ismember(3700,12). 
ismember(3701,1). ismember(3701,3). ismember(3701,5). ismember(3701,6). ismember(3701,7). ismember(3701,10). ismember(3701,11). ismember(3701,12). 
ismember(3702,2). ismember(3702,3). ismember(3702,5). ismember(3702,6). ismember(3702,7). ismember(3702,10). ismember(3702,11). ismember(3702,12). 
ismember(3703,1). ismember(3703,2). ismember(3703,3). ismember(3703,5). ismember(3703,6). ismember(3703,7). ismember(3703,10). ismember(3703,11). ismember(3703,12). 
ismember(3704,4). ismember(3704,5). ismember(3704,6). ismember(3704,7). ismember(3704,10). ismember(3704,11). ismember(3704,12). 
ismember(3705,1). ismember(3705,4). ismember(3705,5). ismember(3705,6). ismember(3705,7). ismember(3705,10). ismember(3705,11). ismember(3705,12). 
ismember(3706,2). ismember(3706,4). ismember(3706,5). ismember(3706,6). ismember(3706,7). ismember(3706,10). ismember(3706,11). ismember(3706,12). 
ismember(3707,1). ismember(3707,2). ismember(3707,4). ismember(3707,5). ismember(3707,6). ismember(3707,7). ismember(3707,10). ismember(3707,11). ismember(3707,12). 
ismember(3708,3). ismember(3708,4). ismember(3708,5). ismember(3708,6). ismember(3708,7). ismember(3708,10). ismember(3708,11). ismember(3708,12). 
ismember(3709,1). ismember(3709,3). ismember(3709,4). ismember(3709,5). ismember(3709,6). ismember(3709,7). ismember(3709,10). ismember(3709,11). ismember(3709,12). 
ismember(3710,2). ismember(3710,3). ismember(3710,4). ismember(3710,5). ismember(3710,6). ismember(3710,7). ismember(3710,10). ismember(3710,11). ismember(3710,12). 
ismember(3711,1). ismember(3711,2). ismember(3711,3). ismember(3711,4). ismember(3711,5). ismember(3711,6). ismember(3711,7). ismember(3711,10). ismember(3711,11). ismember(3711,12). 
ismember(3712,8). ismember(3712,10). ismember(3712,11). ismember(3712,12). 
ismember(3713,1). ismember(3713,8). ismember(3713,10). ismember(3713,11). ismember(3713,12). 
ismember(3714,2). ismember(3714,8). ismember(3714,10). ismember(3714,11). ismember(3714,12). 
ismember(3715,1). ismember(3715,2). ismember(3715,8). ismember(3715,10). ismember(3715,11). ismember(3715,12). 
ismember(3716,3). ismember(3716,8). ismember(3716,10). ismember(3716,11). ismember(3716,12). 
ismember(3717,1). ismember(3717,3). ismember(3717,8). ismember(3717,10). ismember(3717,11). ismember(3717,12). 
ismember(3718,2). ismember(3718,3). ismember(3718,8). ismember(3718,10). ismember(3718,11). ismember(3718,12). 
ismember(3719,1). ismember(3719,2). ismember(3719,3). ismember(3719,8). ismember(3719,10). ismember(3719,11). ismember(3719,12). 
ismember(3720,4). ismember(3720,8). ismember(3720,10). ismember(3720,11). ismember(3720,12). 
ismember(3721,1). ismember(3721,4). ismember(3721,8). ismember(3721,10). ismember(3721,11). ismember(3721,12). 
ismember(3722,2). ismember(3722,4). ismember(3722,8). ismember(3722,10). ismember(3722,11). ismember(3722,12). 
ismember(3723,1). ismember(3723,2). ismember(3723,4). ismember(3723,8). ismember(3723,10). ismember(3723,11). ismember(3723,12). 
ismember(3724,3). ismember(3724,4). ismember(3724,8). ismember(3724,10). ismember(3724,11). ismember(3724,12). 
ismember(3725,1). ismember(3725,3). ismember(3725,4). ismember(3725,8). ismember(3725,10). ismember(3725,11). ismember(3725,12). 
ismember(3726,2). ismember(3726,3). ismember(3726,4). ismember(3726,8). ismember(3726,10). ismember(3726,11). ismember(3726,12). 
ismember(3727,1). ismember(3727,2). ismember(3727,3). ismember(3727,4). ismember(3727,8). ismember(3727,10). ismember(3727,11). ismember(3727,12). 
ismember(3728,5). ismember(3728,8). ismember(3728,10). ismember(3728,11). ismember(3728,12). 
ismember(3729,1). ismember(3729,5). ismember(3729,8). ismember(3729,10). ismember(3729,11). ismember(3729,12). 
ismember(3730,2). ismember(3730,5). ismember(3730,8). ismember(3730,10). ismember(3730,11). ismember(3730,12). 
ismember(3731,1). ismember(3731,2). ismember(3731,5). ismember(3731,8). ismember(3731,10). ismember(3731,11). ismember(3731,12). 
ismember(3732,3). ismember(3732,5). ismember(3732,8). ismember(3732,10). ismember(3732,11). ismember(3732,12). 
ismember(3733,1). ismember(3733,3). ismember(3733,5). ismember(3733,8). ismember(3733,10). ismember(3733,11). ismember(3733,12). 
ismember(3734,2). ismember(3734,3). ismember(3734,5). ismember(3734,8). ismember(3734,10). ismember(3734,11). ismember(3734,12). 
ismember(3735,1). ismember(3735,2). ismember(3735,3). ismember(3735,5). ismember(3735,8). ismember(3735,10). ismember(3735,11). ismember(3735,12). 
ismember(3736,4). ismember(3736,5). ismember(3736,8). ismember(3736,10). ismember(3736,11). ismember(3736,12). 
ismember(3737,1). ismember(3737,4). ismember(3737,5). ismember(3737,8). ismember(3737,10). ismember(3737,11). ismember(3737,12). 
ismember(3738,2). ismember(3738,4). ismember(3738,5). ismember(3738,8). ismember(3738,10). ismember(3738,11). ismember(3738,12). 
ismember(3739,1). ismember(3739,2). ismember(3739,4). ismember(3739,5). ismember(3739,8). ismember(3739,10). ismember(3739,11). ismember(3739,12). 
ismember(3740,3). ismember(3740,4). ismember(3740,5). ismember(3740,8). ismember(3740,10). ismember(3740,11). ismember(3740,12). 
ismember(3741,1). ismember(3741,3). ismember(3741,4). ismember(3741,5). ismember(3741,8). ismember(3741,10). ismember(3741,11). ismember(3741,12). 
ismember(3742,2). ismember(3742,3). ismember(3742,4). ismember(3742,5). ismember(3742,8). ismember(3742,10). ismember(3742,11). ismember(3742,12). 
ismember(3743,1). ismember(3743,2). ismember(3743,3). ismember(3743,4). ismember(3743,5). ismember(3743,8). ismember(3743,10). ismember(3743,11). ismember(3743,12). 
ismember(3744,6). ismember(3744,8). ismember(3744,10). ismember(3744,11). ismember(3744,12). 
ismember(3745,1). ismember(3745,6). ismember(3745,8). ismember(3745,10). ismember(3745,11). ismember(3745,12). 
ismember(3746,2). ismember(3746,6). ismember(3746,8). ismember(3746,10). ismember(3746,11). ismember(3746,12). 
ismember(3747,1). ismember(3747,2). ismember(3747,6). ismember(3747,8). ismember(3747,10). ismember(3747,11). ismember(3747,12). 
ismember(3748,3). ismember(3748,6). ismember(3748,8). ismember(3748,10). ismember(3748,11). ismember(3748,12). 
ismember(3749,1). ismember(3749,3). ismember(3749,6). ismember(3749,8). ismember(3749,10). ismember(3749,11). ismember(3749,12). 
ismember(3750,2). ismember(3750,3). ismember(3750,6). ismember(3750,8). ismember(3750,10). ismember(3750,11). ismember(3750,12). 
ismember(3751,1). ismember(3751,2). ismember(3751,3). ismember(3751,6). ismember(3751,8). ismember(3751,10). ismember(3751,11). ismember(3751,12). 
ismember(3752,4). ismember(3752,6). ismember(3752,8). ismember(3752,10). ismember(3752,11). ismember(3752,12). 
ismember(3753,1). ismember(3753,4). ismember(3753,6). ismember(3753,8). ismember(3753,10). ismember(3753,11). ismember(3753,12). 
ismember(3754,2). ismember(3754,4). ismember(3754,6). ismember(3754,8). ismember(3754,10). ismember(3754,11). ismember(3754,12). 
ismember(3755,1). ismember(3755,2). ismember(3755,4). ismember(3755,6). ismember(3755,8). ismember(3755,10). ismember(3755,11). ismember(3755,12). 
ismember(3756,3). ismember(3756,4). ismember(3756,6). ismember(3756,8). ismember(3756,10). ismember(3756,11). ismember(3756,12). 
ismember(3757,1). ismember(3757,3). ismember(3757,4). ismember(3757,6). ismember(3757,8). ismember(3757,10). ismember(3757,11). ismember(3757,12). 
ismember(3758,2). ismember(3758,3). ismember(3758,4). ismember(3758,6). ismember(3758,8). ismember(3758,10). ismember(3758,11). ismember(3758,12). 
ismember(3759,1). ismember(3759,2). ismember(3759,3). ismember(3759,4). ismember(3759,6). ismember(3759,8). ismember(3759,10). ismember(3759,11). ismember(3759,12). 
ismember(3760,5). ismember(3760,6). ismember(3760,8). ismember(3760,10). ismember(3760,11). ismember(3760,12). 
ismember(3761,1). ismember(3761,5). ismember(3761,6). ismember(3761,8). ismember(3761,10). ismember(3761,11). ismember(3761,12). 
ismember(3762,2). ismember(3762,5). ismember(3762,6). ismember(3762,8). ismember(3762,10). ismember(3762,11). ismember(3762,12). 
ismember(3763,1). ismember(3763,2). ismember(3763,5). ismember(3763,6). ismember(3763,8). ismember(3763,10). ismember(3763,11). ismember(3763,12). 
ismember(3764,3). ismember(3764,5). ismember(3764,6). ismember(3764,8). ismember(3764,10). ismember(3764,11). ismember(3764,12). 
ismember(3765,1). ismember(3765,3). ismember(3765,5). ismember(3765,6). ismember(3765,8). ismember(3765,10). ismember(3765,11). ismember(3765,12). 
ismember(3766,2). ismember(3766,3). ismember(3766,5). ismember(3766,6). ismember(3766,8). ismember(3766,10). ismember(3766,11). ismember(3766,12). 
ismember(3767,1). ismember(3767,2). ismember(3767,3). ismember(3767,5). ismember(3767,6). ismember(3767,8). ismember(3767,10). ismember(3767,11). ismember(3767,12). 
ismember(3768,4). ismember(3768,5). ismember(3768,6). ismember(3768,8). ismember(3768,10). ismember(3768,11). ismember(3768,12). 
ismember(3769,1). ismember(3769,4). ismember(3769,5). ismember(3769,6). ismember(3769,8). ismember(3769,10). ismember(3769,11). ismember(3769,12). 
ismember(3770,2). ismember(3770,4). ismember(3770,5). ismember(3770,6). ismember(3770,8). ismember(3770,10). ismember(3770,11). ismember(3770,12). 
ismember(3771,1). ismember(3771,2). ismember(3771,4). ismember(3771,5). ismember(3771,6). ismember(3771,8). ismember(3771,10). ismember(3771,11). ismember(3771,12). 
ismember(3772,3). ismember(3772,4). ismember(3772,5). ismember(3772,6). ismember(3772,8). ismember(3772,10). ismember(3772,11). ismember(3772,12). 
ismember(3773,1). ismember(3773,3). ismember(3773,4). ismember(3773,5). ismember(3773,6). ismember(3773,8). ismember(3773,10). ismember(3773,11). ismember(3773,12). 
ismember(3774,2). ismember(3774,3). ismember(3774,4). ismember(3774,5). ismember(3774,6). ismember(3774,8). ismember(3774,10). ismember(3774,11). ismember(3774,12). 
ismember(3775,1). ismember(3775,2). ismember(3775,3). ismember(3775,4). ismember(3775,5). ismember(3775,6). ismember(3775,8). ismember(3775,10). ismember(3775,11). ismember(3775,12). 
ismember(3776,7). ismember(3776,8). ismember(3776,10). ismember(3776,11). ismember(3776,12). 
ismember(3777,1). ismember(3777,7). ismember(3777,8). ismember(3777,10). ismember(3777,11). ismember(3777,12). 
ismember(3778,2). ismember(3778,7). ismember(3778,8). ismember(3778,10). ismember(3778,11). ismember(3778,12). 
ismember(3779,1). ismember(3779,2). ismember(3779,7). ismember(3779,8). ismember(3779,10). ismember(3779,11). ismember(3779,12). 
ismember(3780,3). ismember(3780,7). ismember(3780,8). ismember(3780,10). ismember(3780,11). ismember(3780,12). 
ismember(3781,1). ismember(3781,3). ismember(3781,7). ismember(3781,8). ismember(3781,10). ismember(3781,11). ismember(3781,12). 
ismember(3782,2). ismember(3782,3). ismember(3782,7). ismember(3782,8). ismember(3782,10). ismember(3782,11). ismember(3782,12). 
ismember(3783,1). ismember(3783,2). ismember(3783,3). ismember(3783,7). ismember(3783,8). ismember(3783,10). ismember(3783,11). ismember(3783,12). 
ismember(3784,4). ismember(3784,7). ismember(3784,8). ismember(3784,10). ismember(3784,11). ismember(3784,12). 
ismember(3785,1). ismember(3785,4). ismember(3785,7). ismember(3785,8). ismember(3785,10). ismember(3785,11). ismember(3785,12). 
ismember(3786,2). ismember(3786,4). ismember(3786,7). ismember(3786,8). ismember(3786,10). ismember(3786,11). ismember(3786,12). 
ismember(3787,1). ismember(3787,2). ismember(3787,4). ismember(3787,7). ismember(3787,8). ismember(3787,10). ismember(3787,11). ismember(3787,12). 
ismember(3788,3). ismember(3788,4). ismember(3788,7). ismember(3788,8). ismember(3788,10). ismember(3788,11). ismember(3788,12). 
ismember(3789,1). ismember(3789,3). ismember(3789,4). ismember(3789,7). ismember(3789,8). ismember(3789,10). ismember(3789,11). ismember(3789,12). 
ismember(3790,2). ismember(3790,3). ismember(3790,4). ismember(3790,7). ismember(3790,8). ismember(3790,10). ismember(3790,11). ismember(3790,12). 
ismember(3791,1). ismember(3791,2). ismember(3791,3). ismember(3791,4). ismember(3791,7). ismember(3791,8). ismember(3791,10). ismember(3791,11). ismember(3791,12). 
ismember(3792,5). ismember(3792,7). ismember(3792,8). ismember(3792,10). ismember(3792,11). ismember(3792,12). 
ismember(3793,1). ismember(3793,5). ismember(3793,7). ismember(3793,8). ismember(3793,10). ismember(3793,11). ismember(3793,12). 
ismember(3794,2). ismember(3794,5). ismember(3794,7). ismember(3794,8). ismember(3794,10). ismember(3794,11). ismember(3794,12). 
ismember(3795,1). ismember(3795,2). ismember(3795,5). ismember(3795,7). ismember(3795,8). ismember(3795,10). ismember(3795,11). ismember(3795,12). 
ismember(3796,3). ismember(3796,5). ismember(3796,7). ismember(3796,8). ismember(3796,10). ismember(3796,11). ismember(3796,12). 
ismember(3797,1). ismember(3797,3). ismember(3797,5). ismember(3797,7). ismember(3797,8). ismember(3797,10). ismember(3797,11). ismember(3797,12). 
ismember(3798,2). ismember(3798,3). ismember(3798,5). ismember(3798,7). ismember(3798,8). ismember(3798,10). ismember(3798,11). ismember(3798,12). 
ismember(3799,1). ismember(3799,2). ismember(3799,3). ismember(3799,5). ismember(3799,7). ismember(3799,8). ismember(3799,10). ismember(3799,11). ismember(3799,12). 
ismember(3800,4). ismember(3800,5). ismember(3800,7). ismember(3800,8). ismember(3800,10). ismember(3800,11). ismember(3800,12). 
ismember(3801,1). ismember(3801,4). ismember(3801,5). ismember(3801,7). ismember(3801,8). ismember(3801,10). ismember(3801,11). ismember(3801,12). 
ismember(3802,2). ismember(3802,4). ismember(3802,5). ismember(3802,7). ismember(3802,8). ismember(3802,10). ismember(3802,11). ismember(3802,12). 
ismember(3803,1). ismember(3803,2). ismember(3803,4). ismember(3803,5). ismember(3803,7). ismember(3803,8). ismember(3803,10). ismember(3803,11). ismember(3803,12). 
ismember(3804,3). ismember(3804,4). ismember(3804,5). ismember(3804,7). ismember(3804,8). ismember(3804,10). ismember(3804,11). ismember(3804,12). 
ismember(3805,1). ismember(3805,3). ismember(3805,4). ismember(3805,5). ismember(3805,7). ismember(3805,8). ismember(3805,10). ismember(3805,11). ismember(3805,12). 
ismember(3806,2). ismember(3806,3). ismember(3806,4). ismember(3806,5). ismember(3806,7). ismember(3806,8). ismember(3806,10). ismember(3806,11). ismember(3806,12). 
ismember(3807,1). ismember(3807,2). ismember(3807,3). ismember(3807,4). ismember(3807,5). ismember(3807,7). ismember(3807,8). ismember(3807,10). ismember(3807,11). ismember(3807,12). 
ismember(3808,6). ismember(3808,7). ismember(3808,8). ismember(3808,10). ismember(3808,11). ismember(3808,12). 
ismember(3809,1). ismember(3809,6). ismember(3809,7). ismember(3809,8). ismember(3809,10). ismember(3809,11). ismember(3809,12). 
ismember(3810,2). ismember(3810,6). ismember(3810,7). ismember(3810,8). ismember(3810,10). ismember(3810,11). ismember(3810,12). 
ismember(3811,1). ismember(3811,2). ismember(3811,6). ismember(3811,7). ismember(3811,8). ismember(3811,10). ismember(3811,11). ismember(3811,12). 
ismember(3812,3). ismember(3812,6). ismember(3812,7). ismember(3812,8). ismember(3812,10). ismember(3812,11). ismember(3812,12). 
ismember(3813,1). ismember(3813,3). ismember(3813,6). ismember(3813,7). ismember(3813,8). ismember(3813,10). ismember(3813,11). ismember(3813,12). 
ismember(3814,2). ismember(3814,3). ismember(3814,6). ismember(3814,7). ismember(3814,8). ismember(3814,10). ismember(3814,11). ismember(3814,12). 
ismember(3815,1). ismember(3815,2). ismember(3815,3). ismember(3815,6). ismember(3815,7). ismember(3815,8). ismember(3815,10). ismember(3815,11). ismember(3815,12). 
ismember(3816,4). ismember(3816,6). ismember(3816,7). ismember(3816,8). ismember(3816,10). ismember(3816,11). ismember(3816,12). 
ismember(3817,1). ismember(3817,4). ismember(3817,6). ismember(3817,7). ismember(3817,8). ismember(3817,10). ismember(3817,11). ismember(3817,12). 
ismember(3818,2). ismember(3818,4). ismember(3818,6). ismember(3818,7). ismember(3818,8). ismember(3818,10). ismember(3818,11). ismember(3818,12). 
ismember(3819,1). ismember(3819,2). ismember(3819,4). ismember(3819,6). ismember(3819,7). ismember(3819,8). ismember(3819,10). ismember(3819,11). ismember(3819,12). 
ismember(3820,3). ismember(3820,4). ismember(3820,6). ismember(3820,7). ismember(3820,8). ismember(3820,10). ismember(3820,11). ismember(3820,12). 
ismember(3821,1). ismember(3821,3). ismember(3821,4). ismember(3821,6). ismember(3821,7). ismember(3821,8). ismember(3821,10). ismember(3821,11). ismember(3821,12). 
ismember(3822,2). ismember(3822,3). ismember(3822,4). ismember(3822,6). ismember(3822,7). ismember(3822,8). ismember(3822,10). ismember(3822,11). ismember(3822,12). 
ismember(3823,1). ismember(3823,2). ismember(3823,3). ismember(3823,4). ismember(3823,6). ismember(3823,7). ismember(3823,8). ismember(3823,10). ismember(3823,11). ismember(3823,12). 
ismember(3824,5). ismember(3824,6). ismember(3824,7). ismember(3824,8). ismember(3824,10). ismember(3824,11). ismember(3824,12). 
ismember(3825,1). ismember(3825,5). ismember(3825,6). ismember(3825,7). ismember(3825,8). ismember(3825,10). ismember(3825,11). ismember(3825,12). 
ismember(3826,2). ismember(3826,5). ismember(3826,6). ismember(3826,7). ismember(3826,8). ismember(3826,10). ismember(3826,11). ismember(3826,12). 
ismember(3827,1). ismember(3827,2). ismember(3827,5). ismember(3827,6). ismember(3827,7). ismember(3827,8). ismember(3827,10). ismember(3827,11). ismember(3827,12). 
ismember(3828,3). ismember(3828,5). ismember(3828,6). ismember(3828,7). ismember(3828,8). ismember(3828,10). ismember(3828,11). ismember(3828,12). 
ismember(3829,1). ismember(3829,3). ismember(3829,5). ismember(3829,6). ismember(3829,7). ismember(3829,8). ismember(3829,10). ismember(3829,11). ismember(3829,12). 
ismember(3830,2). ismember(3830,3). ismember(3830,5). ismember(3830,6). ismember(3830,7). ismember(3830,8). ismember(3830,10). ismember(3830,11). ismember(3830,12). 
ismember(3831,1). ismember(3831,2). ismember(3831,3). ismember(3831,5). ismember(3831,6). ismember(3831,7). ismember(3831,8). ismember(3831,10). ismember(3831,11). ismember(3831,12). 
ismember(3832,4). ismember(3832,5). ismember(3832,6). ismember(3832,7). ismember(3832,8). ismember(3832,10). ismember(3832,11). ismember(3832,12). 
ismember(3833,1). ismember(3833,4). ismember(3833,5). ismember(3833,6). ismember(3833,7). ismember(3833,8). ismember(3833,10). ismember(3833,11). ismember(3833,12). 
ismember(3834,2). ismember(3834,4). ismember(3834,5). ismember(3834,6). ismember(3834,7). ismember(3834,8). ismember(3834,10). ismember(3834,11). ismember(3834,12). 
ismember(3835,1). ismember(3835,2). ismember(3835,4). ismember(3835,5). ismember(3835,6). ismember(3835,7). ismember(3835,8). ismember(3835,10). ismember(3835,11). ismember(3835,12). 
ismember(3836,3). ismember(3836,4). ismember(3836,5). ismember(3836,6). ismember(3836,7). ismember(3836,8). ismember(3836,10). ismember(3836,11). ismember(3836,12). 
ismember(3837,1). ismember(3837,3). ismember(3837,4). ismember(3837,5). ismember(3837,6). ismember(3837,7). ismember(3837,8). ismember(3837,10). ismember(3837,11). ismember(3837,12). 
ismember(3838,2). ismember(3838,3). ismember(3838,4). ismember(3838,5). ismember(3838,6). ismember(3838,7). ismember(3838,8). ismember(3838,10). ismember(3838,11). ismember(3838,12). 
ismember(3839,1). ismember(3839,2). ismember(3839,3). ismember(3839,4). ismember(3839,5). ismember(3839,6). ismember(3839,7). ismember(3839,8). ismember(3839,10). ismember(3839,11). ismember(3839,12). 
ismember(3840,9). ismember(3840,10). ismember(3840,11). ismember(3840,12). 
ismember(3841,1). ismember(3841,9). ismember(3841,10). ismember(3841,11). ismember(3841,12). 
ismember(3842,2). ismember(3842,9). ismember(3842,10). ismember(3842,11). ismember(3842,12). 
ismember(3843,1). ismember(3843,2). ismember(3843,9). ismember(3843,10). ismember(3843,11). ismember(3843,12). 
ismember(3844,3). ismember(3844,9). ismember(3844,10). ismember(3844,11). ismember(3844,12). 
ismember(3845,1). ismember(3845,3). ismember(3845,9). ismember(3845,10). ismember(3845,11). ismember(3845,12). 
ismember(3846,2). ismember(3846,3). ismember(3846,9). ismember(3846,10). ismember(3846,11). ismember(3846,12). 
ismember(3847,1). ismember(3847,2). ismember(3847,3). ismember(3847,9). ismember(3847,10). ismember(3847,11). ismember(3847,12). 
ismember(3848,4). ismember(3848,9). ismember(3848,10). ismember(3848,11). ismember(3848,12). 
ismember(3849,1). ismember(3849,4). ismember(3849,9). ismember(3849,10). ismember(3849,11). ismember(3849,12). 
ismember(3850,2). ismember(3850,4). ismember(3850,9). ismember(3850,10). ismember(3850,11). ismember(3850,12). 
ismember(3851,1). ismember(3851,2). ismember(3851,4). ismember(3851,9). ismember(3851,10). ismember(3851,11). ismember(3851,12). 
ismember(3852,3). ismember(3852,4). ismember(3852,9). ismember(3852,10). ismember(3852,11). ismember(3852,12). 
ismember(3853,1). ismember(3853,3). ismember(3853,4). ismember(3853,9). ismember(3853,10). ismember(3853,11). ismember(3853,12). 
ismember(3854,2). ismember(3854,3). ismember(3854,4). ismember(3854,9). ismember(3854,10). ismember(3854,11). ismember(3854,12). 
ismember(3855,1). ismember(3855,2). ismember(3855,3). ismember(3855,4). ismember(3855,9). ismember(3855,10). ismember(3855,11). ismember(3855,12). 
ismember(3856,5). ismember(3856,9). ismember(3856,10). ismember(3856,11). ismember(3856,12). 
ismember(3857,1). ismember(3857,5). ismember(3857,9). ismember(3857,10). ismember(3857,11). ismember(3857,12). 
ismember(3858,2). ismember(3858,5). ismember(3858,9). ismember(3858,10). ismember(3858,11). ismember(3858,12). 
ismember(3859,1). ismember(3859,2). ismember(3859,5). ismember(3859,9). ismember(3859,10). ismember(3859,11). ismember(3859,12). 
ismember(3860,3). ismember(3860,5). ismember(3860,9). ismember(3860,10). ismember(3860,11). ismember(3860,12). 
ismember(3861,1). ismember(3861,3). ismember(3861,5). ismember(3861,9). ismember(3861,10). ismember(3861,11). ismember(3861,12). 
ismember(3862,2). ismember(3862,3). ismember(3862,5). ismember(3862,9). ismember(3862,10). ismember(3862,11). ismember(3862,12). 
ismember(3863,1). ismember(3863,2). ismember(3863,3). ismember(3863,5). ismember(3863,9). ismember(3863,10). ismember(3863,11). ismember(3863,12). 
ismember(3864,4). ismember(3864,5). ismember(3864,9). ismember(3864,10). ismember(3864,11). ismember(3864,12). 
ismember(3865,1). ismember(3865,4). ismember(3865,5). ismember(3865,9). ismember(3865,10). ismember(3865,11). ismember(3865,12). 
ismember(3866,2). ismember(3866,4). ismember(3866,5). ismember(3866,9). ismember(3866,10). ismember(3866,11). ismember(3866,12). 
ismember(3867,1). ismember(3867,2). ismember(3867,4). ismember(3867,5). ismember(3867,9). ismember(3867,10). ismember(3867,11). ismember(3867,12). 
ismember(3868,3). ismember(3868,4). ismember(3868,5). ismember(3868,9). ismember(3868,10). ismember(3868,11). ismember(3868,12). 
ismember(3869,1). ismember(3869,3). ismember(3869,4). ismember(3869,5). ismember(3869,9). ismember(3869,10). ismember(3869,11). ismember(3869,12). 
ismember(3870,2). ismember(3870,3). ismember(3870,4). ismember(3870,5). ismember(3870,9). ismember(3870,10). ismember(3870,11). ismember(3870,12). 
ismember(3871,1). ismember(3871,2). ismember(3871,3). ismember(3871,4). ismember(3871,5). ismember(3871,9). ismember(3871,10). ismember(3871,11). ismember(3871,12). 
ismember(3872,6). ismember(3872,9). ismember(3872,10). ismember(3872,11). ismember(3872,12). 
ismember(3873,1). ismember(3873,6). ismember(3873,9). ismember(3873,10). ismember(3873,11). ismember(3873,12). 
ismember(3874,2). ismember(3874,6). ismember(3874,9). ismember(3874,10). ismember(3874,11). ismember(3874,12). 
ismember(3875,1). ismember(3875,2). ismember(3875,6). ismember(3875,9). ismember(3875,10). ismember(3875,11). ismember(3875,12). 
ismember(3876,3). ismember(3876,6). ismember(3876,9). ismember(3876,10). ismember(3876,11). ismember(3876,12). 
ismember(3877,1). ismember(3877,3). ismember(3877,6). ismember(3877,9). ismember(3877,10). ismember(3877,11). ismember(3877,12). 
ismember(3878,2). ismember(3878,3). ismember(3878,6). ismember(3878,9). ismember(3878,10). ismember(3878,11). ismember(3878,12). 
ismember(3879,1). ismember(3879,2). ismember(3879,3). ismember(3879,6). ismember(3879,9). ismember(3879,10). ismember(3879,11). ismember(3879,12). 
ismember(3880,4). ismember(3880,6). ismember(3880,9). ismember(3880,10). ismember(3880,11). ismember(3880,12). 
ismember(3881,1). ismember(3881,4). ismember(3881,6). ismember(3881,9). ismember(3881,10). ismember(3881,11). ismember(3881,12). 
ismember(3882,2). ismember(3882,4). ismember(3882,6). ismember(3882,9). ismember(3882,10). ismember(3882,11). ismember(3882,12). 
ismember(3883,1). ismember(3883,2). ismember(3883,4). ismember(3883,6). ismember(3883,9). ismember(3883,10). ismember(3883,11). ismember(3883,12). 
ismember(3884,3). ismember(3884,4). ismember(3884,6). ismember(3884,9). ismember(3884,10). ismember(3884,11). ismember(3884,12). 
ismember(3885,1). ismember(3885,3). ismember(3885,4). ismember(3885,6). ismember(3885,9). ismember(3885,10). ismember(3885,11). ismember(3885,12). 
ismember(3886,2). ismember(3886,3). ismember(3886,4). ismember(3886,6). ismember(3886,9). ismember(3886,10). ismember(3886,11). ismember(3886,12). 
ismember(3887,1). ismember(3887,2). ismember(3887,3). ismember(3887,4). ismember(3887,6). ismember(3887,9). ismember(3887,10). ismember(3887,11). ismember(3887,12). 
ismember(3888,5). ismember(3888,6). ismember(3888,9). ismember(3888,10). ismember(3888,11). ismember(3888,12). 
ismember(3889,1). ismember(3889,5). ismember(3889,6). ismember(3889,9). ismember(3889,10). ismember(3889,11). ismember(3889,12). 
ismember(3890,2). ismember(3890,5). ismember(3890,6). ismember(3890,9). ismember(3890,10). ismember(3890,11). ismember(3890,12). 
ismember(3891,1). ismember(3891,2). ismember(3891,5). ismember(3891,6). ismember(3891,9). ismember(3891,10). ismember(3891,11). ismember(3891,12). 
ismember(3892,3). ismember(3892,5). ismember(3892,6). ismember(3892,9). ismember(3892,10). ismember(3892,11). ismember(3892,12). 
ismember(3893,1). ismember(3893,3). ismember(3893,5). ismember(3893,6). ismember(3893,9). ismember(3893,10). ismember(3893,11). ismember(3893,12). 
ismember(3894,2). ismember(3894,3). ismember(3894,5). ismember(3894,6). ismember(3894,9). ismember(3894,10). ismember(3894,11). ismember(3894,12). 
ismember(3895,1). ismember(3895,2). ismember(3895,3). ismember(3895,5). ismember(3895,6). ismember(3895,9). ismember(3895,10). ismember(3895,11). ismember(3895,12). 
ismember(3896,4). ismember(3896,5). ismember(3896,6). ismember(3896,9). ismember(3896,10). ismember(3896,11). ismember(3896,12). 
ismember(3897,1). ismember(3897,4). ismember(3897,5). ismember(3897,6). ismember(3897,9). ismember(3897,10). ismember(3897,11). ismember(3897,12). 
ismember(3898,2). ismember(3898,4). ismember(3898,5). ismember(3898,6). ismember(3898,9). ismember(3898,10). ismember(3898,11). ismember(3898,12). 
ismember(3899,1). ismember(3899,2). ismember(3899,4). ismember(3899,5). ismember(3899,6). ismember(3899,9). ismember(3899,10). ismember(3899,11). ismember(3899,12). 
ismember(3900,3). ismember(3900,4). ismember(3900,5). ismember(3900,6). ismember(3900,9). ismember(3900,10). ismember(3900,11). ismember(3900,12). 
ismember(3901,1). ismember(3901,3). ismember(3901,4). ismember(3901,5). ismember(3901,6). ismember(3901,9). ismember(3901,10). ismember(3901,11). ismember(3901,12). 
ismember(3902,2). ismember(3902,3). ismember(3902,4). ismember(3902,5). ismember(3902,6). ismember(3902,9). ismember(3902,10). ismember(3902,11). ismember(3902,12). 
ismember(3903,1). ismember(3903,2). ismember(3903,3). ismember(3903,4). ismember(3903,5). ismember(3903,6). ismember(3903,9). ismember(3903,10). ismember(3903,11). ismember(3903,12). 
ismember(3904,7). ismember(3904,9). ismember(3904,10). ismember(3904,11). ismember(3904,12). 
ismember(3905,1). ismember(3905,7). ismember(3905,9). ismember(3905,10). ismember(3905,11). ismember(3905,12). 
ismember(3906,2). ismember(3906,7). ismember(3906,9). ismember(3906,10). ismember(3906,11). ismember(3906,12). 
ismember(3907,1). ismember(3907,2). ismember(3907,7). ismember(3907,9). ismember(3907,10). ismember(3907,11). ismember(3907,12). 
ismember(3908,3). ismember(3908,7). ismember(3908,9). ismember(3908,10). ismember(3908,11). ismember(3908,12). 
ismember(3909,1). ismember(3909,3). ismember(3909,7). ismember(3909,9). ismember(3909,10). ismember(3909,11). ismember(3909,12). 
ismember(3910,2). ismember(3910,3). ismember(3910,7). ismember(3910,9). ismember(3910,10). ismember(3910,11). ismember(3910,12). 
ismember(3911,1). ismember(3911,2). ismember(3911,3). ismember(3911,7). ismember(3911,9). ismember(3911,10). ismember(3911,11). ismember(3911,12). 
ismember(3912,4). ismember(3912,7). ismember(3912,9). ismember(3912,10). ismember(3912,11). ismember(3912,12). 
ismember(3913,1). ismember(3913,4). ismember(3913,7). ismember(3913,9). ismember(3913,10). ismember(3913,11). ismember(3913,12). 
ismember(3914,2). ismember(3914,4). ismember(3914,7). ismember(3914,9). ismember(3914,10). ismember(3914,11). ismember(3914,12). 
ismember(3915,1). ismember(3915,2). ismember(3915,4). ismember(3915,7). ismember(3915,9). ismember(3915,10). ismember(3915,11). ismember(3915,12). 
ismember(3916,3). ismember(3916,4). ismember(3916,7). ismember(3916,9). ismember(3916,10). ismember(3916,11). ismember(3916,12). 
ismember(3917,1). ismember(3917,3). ismember(3917,4). ismember(3917,7). ismember(3917,9). ismember(3917,10). ismember(3917,11). ismember(3917,12). 
ismember(3918,2). ismember(3918,3). ismember(3918,4). ismember(3918,7). ismember(3918,9). ismember(3918,10). ismember(3918,11). ismember(3918,12). 
ismember(3919,1). ismember(3919,2). ismember(3919,3). ismember(3919,4). ismember(3919,7). ismember(3919,9). ismember(3919,10). ismember(3919,11). ismember(3919,12). 
ismember(3920,5). ismember(3920,7). ismember(3920,9). ismember(3920,10). ismember(3920,11). ismember(3920,12). 
ismember(3921,1). ismember(3921,5). ismember(3921,7). ismember(3921,9). ismember(3921,10). ismember(3921,11). ismember(3921,12). 
ismember(3922,2). ismember(3922,5). ismember(3922,7). ismember(3922,9). ismember(3922,10). ismember(3922,11). ismember(3922,12). 
ismember(3923,1). ismember(3923,2). ismember(3923,5). ismember(3923,7). ismember(3923,9). ismember(3923,10). ismember(3923,11). ismember(3923,12). 
ismember(3924,3). ismember(3924,5). ismember(3924,7). ismember(3924,9). ismember(3924,10). ismember(3924,11). ismember(3924,12). 
ismember(3925,1). ismember(3925,3). ismember(3925,5). ismember(3925,7). ismember(3925,9). ismember(3925,10). ismember(3925,11). ismember(3925,12). 
ismember(3926,2). ismember(3926,3). ismember(3926,5). ismember(3926,7). ismember(3926,9). ismember(3926,10). ismember(3926,11). ismember(3926,12). 
ismember(3927,1). ismember(3927,2). ismember(3927,3). ismember(3927,5). ismember(3927,7). ismember(3927,9). ismember(3927,10). ismember(3927,11). ismember(3927,12). 
ismember(3928,4). ismember(3928,5). ismember(3928,7). ismember(3928,9). ismember(3928,10). ismember(3928,11). ismember(3928,12). 
ismember(3929,1). ismember(3929,4). ismember(3929,5). ismember(3929,7). ismember(3929,9). ismember(3929,10). ismember(3929,11). ismember(3929,12). 
ismember(3930,2). ismember(3930,4). ismember(3930,5). ismember(3930,7). ismember(3930,9). ismember(3930,10). ismember(3930,11). ismember(3930,12). 
ismember(3931,1). ismember(3931,2). ismember(3931,4). ismember(3931,5). ismember(3931,7). ismember(3931,9). ismember(3931,10). ismember(3931,11). ismember(3931,12). 
ismember(3932,3). ismember(3932,4). ismember(3932,5). ismember(3932,7). ismember(3932,9). ismember(3932,10). ismember(3932,11). ismember(3932,12). 
ismember(3933,1). ismember(3933,3). ismember(3933,4). ismember(3933,5). ismember(3933,7). ismember(3933,9). ismember(3933,10). ismember(3933,11). ismember(3933,12). 
ismember(3934,2). ismember(3934,3). ismember(3934,4). ismember(3934,5). ismember(3934,7). ismember(3934,9). ismember(3934,10). ismember(3934,11). ismember(3934,12). 
ismember(3935,1). ismember(3935,2). ismember(3935,3). ismember(3935,4). ismember(3935,5). ismember(3935,7). ismember(3935,9). ismember(3935,10). ismember(3935,11). ismember(3935,12). 
ismember(3936,6). ismember(3936,7). ismember(3936,9). ismember(3936,10). ismember(3936,11). ismember(3936,12). 
ismember(3937,1). ismember(3937,6). ismember(3937,7). ismember(3937,9). ismember(3937,10). ismember(3937,11). ismember(3937,12). 
ismember(3938,2). ismember(3938,6). ismember(3938,7). ismember(3938,9). ismember(3938,10). ismember(3938,11). ismember(3938,12). 
ismember(3939,1). ismember(3939,2). ismember(3939,6). ismember(3939,7). ismember(3939,9). ismember(3939,10). ismember(3939,11). ismember(3939,12). 
ismember(3940,3). ismember(3940,6). ismember(3940,7). ismember(3940,9). ismember(3940,10). ismember(3940,11). ismember(3940,12). 
ismember(3941,1). ismember(3941,3). ismember(3941,6). ismember(3941,7). ismember(3941,9). ismember(3941,10). ismember(3941,11). ismember(3941,12). 
ismember(3942,2). ismember(3942,3). ismember(3942,6). ismember(3942,7). ismember(3942,9). ismember(3942,10). ismember(3942,11). ismember(3942,12). 
ismember(3943,1). ismember(3943,2). ismember(3943,3). ismember(3943,6). ismember(3943,7). ismember(3943,9). ismember(3943,10). ismember(3943,11). ismember(3943,12). 
ismember(3944,4). ismember(3944,6). ismember(3944,7). ismember(3944,9). ismember(3944,10). ismember(3944,11). ismember(3944,12). 
ismember(3945,1). ismember(3945,4). ismember(3945,6). ismember(3945,7). ismember(3945,9). ismember(3945,10). ismember(3945,11). ismember(3945,12). 
ismember(3946,2). ismember(3946,4). ismember(3946,6). ismember(3946,7). ismember(3946,9). ismember(3946,10). ismember(3946,11). ismember(3946,12). 
ismember(3947,1). ismember(3947,2). ismember(3947,4). ismember(3947,6). ismember(3947,7). ismember(3947,9). ismember(3947,10). ismember(3947,11). ismember(3947,12). 
ismember(3948,3). ismember(3948,4). ismember(3948,6). ismember(3948,7). ismember(3948,9). ismember(3948,10). ismember(3948,11). ismember(3948,12). 
ismember(3949,1). ismember(3949,3). ismember(3949,4). ismember(3949,6). ismember(3949,7). ismember(3949,9). ismember(3949,10). ismember(3949,11). ismember(3949,12). 
ismember(3950,2). ismember(3950,3). ismember(3950,4). ismember(3950,6). ismember(3950,7). ismember(3950,9). ismember(3950,10). ismember(3950,11). ismember(3950,12). 
ismember(3951,1). ismember(3951,2). ismember(3951,3). ismember(3951,4). ismember(3951,6). ismember(3951,7). ismember(3951,9). ismember(3951,10). ismember(3951,11). ismember(3951,12). 
ismember(3952,5). ismember(3952,6). ismember(3952,7). ismember(3952,9). ismember(3952,10). ismember(3952,11). ismember(3952,12). 
ismember(3953,1). ismember(3953,5). ismember(3953,6). ismember(3953,7). ismember(3953,9). ismember(3953,10). ismember(3953,11). ismember(3953,12). 
ismember(3954,2). ismember(3954,5). ismember(3954,6). ismember(3954,7). ismember(3954,9). ismember(3954,10). ismember(3954,11). ismember(3954,12). 
ismember(3955,1). ismember(3955,2). ismember(3955,5). ismember(3955,6). ismember(3955,7). ismember(3955,9). ismember(3955,10). ismember(3955,11). ismember(3955,12). 
ismember(3956,3). ismember(3956,5). ismember(3956,6). ismember(3956,7). ismember(3956,9). ismember(3956,10). ismember(3956,11). ismember(3956,12). 
ismember(3957,1). ismember(3957,3). ismember(3957,5). ismember(3957,6). ismember(3957,7). ismember(3957,9). ismember(3957,10). ismember(3957,11). ismember(3957,12). 
ismember(3958,2). ismember(3958,3). ismember(3958,5). ismember(3958,6). ismember(3958,7). ismember(3958,9). ismember(3958,10). ismember(3958,11). ismember(3958,12). 
ismember(3959,1). ismember(3959,2). ismember(3959,3). ismember(3959,5). ismember(3959,6). ismember(3959,7). ismember(3959,9). ismember(3959,10). ismember(3959,11). ismember(3959,12). 
ismember(3960,4). ismember(3960,5). ismember(3960,6). ismember(3960,7). ismember(3960,9). ismember(3960,10). ismember(3960,11). ismember(3960,12). 
ismember(3961,1). ismember(3961,4). ismember(3961,5). ismember(3961,6). ismember(3961,7). ismember(3961,9). ismember(3961,10). ismember(3961,11). ismember(3961,12). 
ismember(3962,2). ismember(3962,4). ismember(3962,5). ismember(3962,6). ismember(3962,7). ismember(3962,9). ismember(3962,10). ismember(3962,11). ismember(3962,12). 
ismember(3963,1). ismember(3963,2). ismember(3963,4). ismember(3963,5). ismember(3963,6). ismember(3963,7). ismember(3963,9). ismember(3963,10). ismember(3963,11). ismember(3963,12). 
ismember(3964,3). ismember(3964,4). ismember(3964,5). ismember(3964,6). ismember(3964,7). ismember(3964,9). ismember(3964,10). ismember(3964,11). ismember(3964,12). 
ismember(3965,1). ismember(3965,3). ismember(3965,4). ismember(3965,5). ismember(3965,6). ismember(3965,7). ismember(3965,9). ismember(3965,10). ismember(3965,11). ismember(3965,12). 
ismember(3966,2). ismember(3966,3). ismember(3966,4). ismember(3966,5). ismember(3966,6). ismember(3966,7). ismember(3966,9). ismember(3966,10). ismember(3966,11). ismember(3966,12). 
ismember(3967,1). ismember(3967,2). ismember(3967,3). ismember(3967,4). ismember(3967,5). ismember(3967,6). ismember(3967,7). ismember(3967,9). ismember(3967,10). ismember(3967,11). ismember(3967,12). 
ismember(3968,8). ismember(3968,9). ismember(3968,10). ismember(3968,11). ismember(3968,12). 
ismember(3969,1). ismember(3969,8). ismember(3969,9). ismember(3969,10). ismember(3969,11). ismember(3969,12). 
ismember(3970,2). ismember(3970,8). ismember(3970,9). ismember(3970,10). ismember(3970,11). ismember(3970,12). 
ismember(3971,1). ismember(3971,2). ismember(3971,8). ismember(3971,9). ismember(3971,10). ismember(3971,11). ismember(3971,12). 
ismember(3972,3). ismember(3972,8). ismember(3972,9). ismember(3972,10). ismember(3972,11). ismember(3972,12). 
ismember(3973,1). ismember(3973,3). ismember(3973,8). ismember(3973,9). ismember(3973,10). ismember(3973,11). ismember(3973,12). 
ismember(3974,2). ismember(3974,3). ismember(3974,8). ismember(3974,9). ismember(3974,10). ismember(3974,11). ismember(3974,12). 
ismember(3975,1). ismember(3975,2). ismember(3975,3). ismember(3975,8). ismember(3975,9). ismember(3975,10). ismember(3975,11). ismember(3975,12). 
ismember(3976,4). ismember(3976,8). ismember(3976,9). ismember(3976,10). ismember(3976,11). ismember(3976,12). 
ismember(3977,1). ismember(3977,4). ismember(3977,8). ismember(3977,9). ismember(3977,10). ismember(3977,11). ismember(3977,12). 
ismember(3978,2). ismember(3978,4). ismember(3978,8). ismember(3978,9). ismember(3978,10). ismember(3978,11). ismember(3978,12). 
ismember(3979,1). ismember(3979,2). ismember(3979,4). ismember(3979,8). ismember(3979,9). ismember(3979,10). ismember(3979,11). ismember(3979,12). 
ismember(3980,3). ismember(3980,4). ismember(3980,8). ismember(3980,9). ismember(3980,10). ismember(3980,11). ismember(3980,12). 
ismember(3981,1). ismember(3981,3). ismember(3981,4). ismember(3981,8). ismember(3981,9). ismember(3981,10). ismember(3981,11). ismember(3981,12). 
ismember(3982,2). ismember(3982,3). ismember(3982,4). ismember(3982,8). ismember(3982,9). ismember(3982,10). ismember(3982,11). ismember(3982,12). 
ismember(3983,1). ismember(3983,2). ismember(3983,3). ismember(3983,4). ismember(3983,8). ismember(3983,9). ismember(3983,10). ismember(3983,11). ismember(3983,12). 
ismember(3984,5). ismember(3984,8). ismember(3984,9). ismember(3984,10). ismember(3984,11). ismember(3984,12). 
ismember(3985,1). ismember(3985,5). ismember(3985,8). ismember(3985,9). ismember(3985,10). ismember(3985,11). ismember(3985,12). 
ismember(3986,2). ismember(3986,5). ismember(3986,8). ismember(3986,9). ismember(3986,10). ismember(3986,11). ismember(3986,12). 
ismember(3987,1). ismember(3987,2). ismember(3987,5). ismember(3987,8). ismember(3987,9). ismember(3987,10). ismember(3987,11). ismember(3987,12). 
ismember(3988,3). ismember(3988,5). ismember(3988,8). ismember(3988,9). ismember(3988,10). ismember(3988,11). ismember(3988,12). 
ismember(3989,1). ismember(3989,3). ismember(3989,5). ismember(3989,8). ismember(3989,9). ismember(3989,10). ismember(3989,11). ismember(3989,12). 
ismember(3990,2). ismember(3990,3). ismember(3990,5). ismember(3990,8). ismember(3990,9). ismember(3990,10). ismember(3990,11). ismember(3990,12). 
ismember(3991,1). ismember(3991,2). ismember(3991,3). ismember(3991,5). ismember(3991,8). ismember(3991,9). ismember(3991,10). ismember(3991,11). ismember(3991,12). 
ismember(3992,4). ismember(3992,5). ismember(3992,8). ismember(3992,9). ismember(3992,10). ismember(3992,11). ismember(3992,12). 
ismember(3993,1). ismember(3993,4). ismember(3993,5). ismember(3993,8). ismember(3993,9). ismember(3993,10). ismember(3993,11). ismember(3993,12). 
ismember(3994,2). ismember(3994,4). ismember(3994,5). ismember(3994,8). ismember(3994,9). ismember(3994,10). ismember(3994,11). ismember(3994,12). 
ismember(3995,1). ismember(3995,2). ismember(3995,4). ismember(3995,5). ismember(3995,8). ismember(3995,9). ismember(3995,10). ismember(3995,11). ismember(3995,12). 
ismember(3996,3). ismember(3996,4). ismember(3996,5). ismember(3996,8). ismember(3996,9). ismember(3996,10). ismember(3996,11). ismember(3996,12). 
ismember(3997,1). ismember(3997,3). ismember(3997,4). ismember(3997,5). ismember(3997,8). ismember(3997,9). ismember(3997,10). ismember(3997,11). ismember(3997,12). 
ismember(3998,2). ismember(3998,3). ismember(3998,4). ismember(3998,5). ismember(3998,8). ismember(3998,9). ismember(3998,10). ismember(3998,11). ismember(3998,12). 
ismember(3999,1). ismember(3999,2). ismember(3999,3). ismember(3999,4). ismember(3999,5). ismember(3999,8). ismember(3999,9). ismember(3999,10). ismember(3999,11). ismember(3999,12). 
ismember(4000,6). ismember(4000,8). ismember(4000,9). ismember(4000,10). ismember(4000,11). ismember(4000,12). 
ismember(4001,1). ismember(4001,6). ismember(4001,8). ismember(4001,9). ismember(4001,10). ismember(4001,11). ismember(4001,12). 
ismember(4002,2). ismember(4002,6). ismember(4002,8). ismember(4002,9). ismember(4002,10). ismember(4002,11). ismember(4002,12). 
ismember(4003,1). ismember(4003,2). ismember(4003,6). ismember(4003,8). ismember(4003,9). ismember(4003,10). ismember(4003,11). ismember(4003,12). 
ismember(4004,3). ismember(4004,6). ismember(4004,8). ismember(4004,9). ismember(4004,10). ismember(4004,11). ismember(4004,12). 
ismember(4005,1). ismember(4005,3). ismember(4005,6). ismember(4005,8). ismember(4005,9). ismember(4005,10). ismember(4005,11). ismember(4005,12). 
ismember(4006,2). ismember(4006,3). ismember(4006,6). ismember(4006,8). ismember(4006,9). ismember(4006,10). ismember(4006,11). ismember(4006,12). 
ismember(4007,1). ismember(4007,2). ismember(4007,3). ismember(4007,6). ismember(4007,8). ismember(4007,9). ismember(4007,10). ismember(4007,11). ismember(4007,12). 
ismember(4008,4). ismember(4008,6). ismember(4008,8). ismember(4008,9). ismember(4008,10). ismember(4008,11). ismember(4008,12). 
ismember(4009,1). ismember(4009,4). ismember(4009,6). ismember(4009,8). ismember(4009,9). ismember(4009,10). ismember(4009,11). ismember(4009,12). 
ismember(4010,2). ismember(4010,4). ismember(4010,6). ismember(4010,8). ismember(4010,9). ismember(4010,10). ismember(4010,11). ismember(4010,12). 
ismember(4011,1). ismember(4011,2). ismember(4011,4). ismember(4011,6). ismember(4011,8). ismember(4011,9). ismember(4011,10). ismember(4011,11). ismember(4011,12). 
ismember(4012,3). ismember(4012,4). ismember(4012,6). ismember(4012,8). ismember(4012,9). ismember(4012,10). ismember(4012,11). ismember(4012,12). 
ismember(4013,1). ismember(4013,3). ismember(4013,4). ismember(4013,6). ismember(4013,8). ismember(4013,9). ismember(4013,10). ismember(4013,11). ismember(4013,12). 
ismember(4014,2). ismember(4014,3). ismember(4014,4). ismember(4014,6). ismember(4014,8). ismember(4014,9). ismember(4014,10). ismember(4014,11). ismember(4014,12). 
ismember(4015,1). ismember(4015,2). ismember(4015,3). ismember(4015,4). ismember(4015,6). ismember(4015,8). ismember(4015,9). ismember(4015,10). ismember(4015,11). ismember(4015,12). 
ismember(4016,5). ismember(4016,6). ismember(4016,8). ismember(4016,9). ismember(4016,10). ismember(4016,11). ismember(4016,12). 
ismember(4017,1). ismember(4017,5). ismember(4017,6). ismember(4017,8). ismember(4017,9). ismember(4017,10). ismember(4017,11). ismember(4017,12). 
ismember(4018,2). ismember(4018,5). ismember(4018,6). ismember(4018,8). ismember(4018,9). ismember(4018,10). ismember(4018,11). ismember(4018,12). 
ismember(4019,1). ismember(4019,2). ismember(4019,5). ismember(4019,6). ismember(4019,8). ismember(4019,9). ismember(4019,10). ismember(4019,11). ismember(4019,12). 
ismember(4020,3). ismember(4020,5). ismember(4020,6). ismember(4020,8). ismember(4020,9). ismember(4020,10). ismember(4020,11). ismember(4020,12). 
ismember(4021,1). ismember(4021,3). ismember(4021,5). ismember(4021,6). ismember(4021,8). ismember(4021,9). ismember(4021,10). ismember(4021,11). ismember(4021,12). 
ismember(4022,2). ismember(4022,3). ismember(4022,5). ismember(4022,6). ismember(4022,8). ismember(4022,9). ismember(4022,10). ismember(4022,11). ismember(4022,12). 
ismember(4023,1). ismember(4023,2). ismember(4023,3). ismember(4023,5). ismember(4023,6). ismember(4023,8). ismember(4023,9). ismember(4023,10). ismember(4023,11). ismember(4023,12). 
ismember(4024,4). ismember(4024,5). ismember(4024,6). ismember(4024,8). ismember(4024,9). ismember(4024,10). ismember(4024,11). ismember(4024,12). 
ismember(4025,1). ismember(4025,4). ismember(4025,5). ismember(4025,6). ismember(4025,8). ismember(4025,9). ismember(4025,10). ismember(4025,11). ismember(4025,12). 
ismember(4026,2). ismember(4026,4). ismember(4026,5). ismember(4026,6). ismember(4026,8). ismember(4026,9). ismember(4026,10). ismember(4026,11). ismember(4026,12). 
ismember(4027,1). ismember(4027,2). ismember(4027,4). ismember(4027,5). ismember(4027,6). ismember(4027,8). ismember(4027,9). ismember(4027,10). ismember(4027,11). ismember(4027,12). 
ismember(4028,3). ismember(4028,4). ismember(4028,5). ismember(4028,6). ismember(4028,8). ismember(4028,9). ismember(4028,10). ismember(4028,11). ismember(4028,12). 
ismember(4029,1). ismember(4029,3). ismember(4029,4). ismember(4029,5). ismember(4029,6). ismember(4029,8). ismember(4029,9). ismember(4029,10). ismember(4029,11). ismember(4029,12). 
ismember(4030,2). ismember(4030,3). ismember(4030,4). ismember(4030,5). ismember(4030,6). ismember(4030,8). ismember(4030,9). ismember(4030,10). ismember(4030,11). ismember(4030,12). 
ismember(4031,1). ismember(4031,2). ismember(4031,3). ismember(4031,4). ismember(4031,5). ismember(4031,6). ismember(4031,8). ismember(4031,9). ismember(4031,10). ismember(4031,11). ismember(4031,12). 
ismember(4032,7). ismember(4032,8). ismember(4032,9). ismember(4032,10). ismember(4032,11). ismember(4032,12). 
ismember(4033,1). ismember(4033,7). ismember(4033,8). ismember(4033,9). ismember(4033,10). ismember(4033,11). ismember(4033,12). 
ismember(4034,2). ismember(4034,7). ismember(4034,8). ismember(4034,9). ismember(4034,10). ismember(4034,11). ismember(4034,12). 
ismember(4035,1). ismember(4035,2). ismember(4035,7). ismember(4035,8). ismember(4035,9). ismember(4035,10). ismember(4035,11). ismember(4035,12). 
ismember(4036,3). ismember(4036,7). ismember(4036,8). ismember(4036,9). ismember(4036,10). ismember(4036,11). ismember(4036,12). 
ismember(4037,1). ismember(4037,3). ismember(4037,7). ismember(4037,8). ismember(4037,9). ismember(4037,10). ismember(4037,11). ismember(4037,12). 
ismember(4038,2). ismember(4038,3). ismember(4038,7). ismember(4038,8). ismember(4038,9). ismember(4038,10). ismember(4038,11). ismember(4038,12). 
ismember(4039,1). ismember(4039,2). ismember(4039,3). ismember(4039,7). ismember(4039,8). ismember(4039,9). ismember(4039,10). ismember(4039,11). ismember(4039,12). 
ismember(4040,4). ismember(4040,7). ismember(4040,8). ismember(4040,9). ismember(4040,10). ismember(4040,11). ismember(4040,12). 
ismember(4041,1). ismember(4041,4). ismember(4041,7). ismember(4041,8). ismember(4041,9). ismember(4041,10). ismember(4041,11). ismember(4041,12). 
ismember(4042,2). ismember(4042,4). ismember(4042,7). ismember(4042,8). ismember(4042,9). ismember(4042,10). ismember(4042,11). ismember(4042,12). 
ismember(4043,1). ismember(4043,2). ismember(4043,4). ismember(4043,7). ismember(4043,8). ismember(4043,9). ismember(4043,10). ismember(4043,11). ismember(4043,12). 
ismember(4044,3). ismember(4044,4). ismember(4044,7). ismember(4044,8). ismember(4044,9). ismember(4044,10). ismember(4044,11). ismember(4044,12). 
ismember(4045,1). ismember(4045,3). ismember(4045,4). ismember(4045,7). ismember(4045,8). ismember(4045,9). ismember(4045,10). ismember(4045,11). ismember(4045,12). 
ismember(4046,2). ismember(4046,3). ismember(4046,4). ismember(4046,7). ismember(4046,8). ismember(4046,9). ismember(4046,10). ismember(4046,11). ismember(4046,12). 
ismember(4047,1). ismember(4047,2). ismember(4047,3). ismember(4047,4). ismember(4047,7). ismember(4047,8). ismember(4047,9). ismember(4047,10). ismember(4047,11). ismember(4047,12). 
ismember(4048,5). ismember(4048,7). ismember(4048,8). ismember(4048,9). ismember(4048,10). ismember(4048,11). ismember(4048,12). 
ismember(4049,1). ismember(4049,5). ismember(4049,7). ismember(4049,8). ismember(4049,9). ismember(4049,10). ismember(4049,11). ismember(4049,12). 
ismember(4050,2). ismember(4050,5). ismember(4050,7). ismember(4050,8). ismember(4050,9). ismember(4050,10). ismember(4050,11). ismember(4050,12). 
ismember(4051,1). ismember(4051,2). ismember(4051,5). ismember(4051,7). ismember(4051,8). ismember(4051,9). ismember(4051,10). ismember(4051,11). ismember(4051,12). 
ismember(4052,3). ismember(4052,5). ismember(4052,7). ismember(4052,8). ismember(4052,9). ismember(4052,10). ismember(4052,11). ismember(4052,12). 
ismember(4053,1). ismember(4053,3). ismember(4053,5). ismember(4053,7). ismember(4053,8). ismember(4053,9). ismember(4053,10). ismember(4053,11). ismember(4053,12). 
ismember(4054,2). ismember(4054,3). ismember(4054,5). ismember(4054,7). ismember(4054,8). ismember(4054,9). ismember(4054,10). ismember(4054,11). ismember(4054,12). 
ismember(4055,1). ismember(4055,2). ismember(4055,3). ismember(4055,5). ismember(4055,7). ismember(4055,8). ismember(4055,9). ismember(4055,10). ismember(4055,11). ismember(4055,12). 
ismember(4056,4). ismember(4056,5). ismember(4056,7). ismember(4056,8). ismember(4056,9). ismember(4056,10). ismember(4056,11). ismember(4056,12). 
ismember(4057,1). ismember(4057,4). ismember(4057,5). ismember(4057,7). ismember(4057,8). ismember(4057,9). ismember(4057,10). ismember(4057,11). ismember(4057,12). 
ismember(4058,2). ismember(4058,4). ismember(4058,5). ismember(4058,7). ismember(4058,8). ismember(4058,9). ismember(4058,10). ismember(4058,11). ismember(4058,12). 
ismember(4059,1). ismember(4059,2). ismember(4059,4). ismember(4059,5). ismember(4059,7). ismember(4059,8). ismember(4059,9). ismember(4059,10). ismember(4059,11). ismember(4059,12). 
ismember(4060,3). ismember(4060,4). ismember(4060,5). ismember(4060,7). ismember(4060,8). ismember(4060,9). ismember(4060,10). ismember(4060,11). ismember(4060,12). 
ismember(4061,1). ismember(4061,3). ismember(4061,4). ismember(4061,5). ismember(4061,7). ismember(4061,8). ismember(4061,9). ismember(4061,10). ismember(4061,11). ismember(4061,12). 
ismember(4062,2). ismember(4062,3). ismember(4062,4). ismember(4062,5). ismember(4062,7). ismember(4062,8). ismember(4062,9). ismember(4062,10). ismember(4062,11). ismember(4062,12). 
ismember(4063,1). ismember(4063,2). ismember(4063,3). ismember(4063,4). ismember(4063,5). ismember(4063,7). ismember(4063,8). ismember(4063,9). ismember(4063,10). ismember(4063,11). ismember(4063,12). 
ismember(4064,6). ismember(4064,7). ismember(4064,8). ismember(4064,9). ismember(4064,10). ismember(4064,11). ismember(4064,12). 
ismember(4065,1). ismember(4065,6). ismember(4065,7). ismember(4065,8). ismember(4065,9). ismember(4065,10). ismember(4065,11). ismember(4065,12). 
ismember(4066,2). ismember(4066,6). ismember(4066,7). ismember(4066,8). ismember(4066,9). ismember(4066,10). ismember(4066,11). ismember(4066,12). 
ismember(4067,1). ismember(4067,2). ismember(4067,6). ismember(4067,7). ismember(4067,8). ismember(4067,9). ismember(4067,10). ismember(4067,11). ismember(4067,12). 
ismember(4068,3). ismember(4068,6). ismember(4068,7). ismember(4068,8). ismember(4068,9). ismember(4068,10). ismember(4068,11). ismember(4068,12). 
ismember(4069,1). ismember(4069,3). ismember(4069,6). ismember(4069,7). ismember(4069,8). ismember(4069,9). ismember(4069,10). ismember(4069,11). ismember(4069,12). 
ismember(4070,2). ismember(4070,3). ismember(4070,6). ismember(4070,7). ismember(4070,8). ismember(4070,9). ismember(4070,10). ismember(4070,11). ismember(4070,12). 
ismember(4071,1). ismember(4071,2). ismember(4071,3). ismember(4071,6). ismember(4071,7). ismember(4071,8). ismember(4071,9). ismember(4071,10). ismember(4071,11). ismember(4071,12). 
ismember(4072,4). ismember(4072,6). ismember(4072,7). ismember(4072,8). ismember(4072,9). ismember(4072,10). ismember(4072,11). ismember(4072,12). 
ismember(4073,1). ismember(4073,4). ismember(4073,6). ismember(4073,7). ismember(4073,8). ismember(4073,9). ismember(4073,10). ismember(4073,11). ismember(4073,12). 
ismember(4074,2). ismember(4074,4). ismember(4074,6). ismember(4074,7). ismember(4074,8). ismember(4074,9). ismember(4074,10). ismember(4074,11). ismember(4074,12). 
ismember(4075,1). ismember(4075,2). ismember(4075,4). ismember(4075,6). ismember(4075,7). ismember(4075,8). ismember(4075,9). ismember(4075,10). ismember(4075,11). ismember(4075,12). 
ismember(4076,3). ismember(4076,4). ismember(4076,6). ismember(4076,7). ismember(4076,8). ismember(4076,9). ismember(4076,10). ismember(4076,11). ismember(4076,12). 
ismember(4077,1). ismember(4077,3). ismember(4077,4). ismember(4077,6). ismember(4077,7). ismember(4077,8). ismember(4077,9). ismember(4077,10). ismember(4077,11). ismember(4077,12). 
ismember(4078,2). ismember(4078,3). ismember(4078,4). ismember(4078,6). ismember(4078,7). ismember(4078,8). ismember(4078,9). ismember(4078,10). ismember(4078,11). ismember(4078,12). 
ismember(4079,1). ismember(4079,2). ismember(4079,3). ismember(4079,4). ismember(4079,6). ismember(4079,7). ismember(4079,8). ismember(4079,9). ismember(4079,10). ismember(4079,11). ismember(4079,12). 
ismember(4080,5). ismember(4080,6). ismember(4080,7). ismember(4080,8). ismember(4080,9). ismember(4080,10). ismember(4080,11). ismember(4080,12). 
ismember(4081,1). ismember(4081,5). ismember(4081,6). ismember(4081,7). ismember(4081,8). ismember(4081,9). ismember(4081,10). ismember(4081,11). ismember(4081,12). 
ismember(4082,2). ismember(4082,5). ismember(4082,6). ismember(4082,7). ismember(4082,8). ismember(4082,9). ismember(4082,10). ismember(4082,11). ismember(4082,12). 
ismember(4083,1). ismember(4083,2). ismember(4083,5). ismember(4083,6). ismember(4083,7). ismember(4083,8). ismember(4083,9). ismember(4083,10). ismember(4083,11). ismember(4083,12). 
ismember(4084,3). ismember(4084,5). ismember(4084,6). ismember(4084,7). ismember(4084,8). ismember(4084,9). ismember(4084,10). ismember(4084,11). ismember(4084,12). 
ismember(4085,1). ismember(4085,3). ismember(4085,5). ismember(4085,6). ismember(4085,7). ismember(4085,8). ismember(4085,9). ismember(4085,10). ismember(4085,11). ismember(4085,12). 
ismember(4086,2). ismember(4086,3). ismember(4086,5). ismember(4086,6). ismember(4086,7). ismember(4086,8). ismember(4086,9). ismember(4086,10). ismember(4086,11). ismember(4086,12). 
ismember(4087,1). ismember(4087,2). ismember(4087,3). ismember(4087,5). ismember(4087,6). ismember(4087,7). ismember(4087,8). ismember(4087,9). ismember(4087,10). ismember(4087,11). ismember(4087,12). 
ismember(4088,4). ismember(4088,5). ismember(4088,6). ismember(4088,7). ismember(4088,8). ismember(4088,9). ismember(4088,10). ismember(4088,11). ismember(4088,12). 
ismember(4089,1). ismember(4089,4). ismember(4089,5). ismember(4089,6). ismember(4089,7). ismember(4089,8). ismember(4089,9). ismember(4089,10). ismember(4089,11). ismember(4089,12). 
ismember(4090,2). ismember(4090,4). ismember(4090,5). ismember(4090,6). ismember(4090,7). ismember(4090,8). ismember(4090,9). ismember(4090,10). ismember(4090,11). ismember(4090,12). 
ismember(4091,1). ismember(4091,2). ismember(4091,4). ismember(4091,5). ismember(4091,6). ismember(4091,7). ismember(4091,8). ismember(4091,9). ismember(4091,10). ismember(4091,11). ismember(4091,12). 
ismember(4092,3). ismember(4092,4). ismember(4092,5). ismember(4092,6). ismember(4092,7). ismember(4092,8). ismember(4092,9). ismember(4092,10). ismember(4092,11). ismember(4092,12). 
ismember(4093,1). ismember(4093,3). ismember(4093,4). ismember(4093,5). ismember(4093,6). ismember(4093,7). ismember(4093,8). ismember(4093,9). ismember(4093,10). ismember(4093,11). ismember(4093,12). 
ismember(4094,2). ismember(4094,3). ismember(4094,4). ismember(4094,5). ismember(4094,6). ismember(4094,7). ismember(4094,8). ismember(4094,9). ismember(4094,10). ismember(4094,11). ismember(4094,12). 
ismember(4095,1). ismember(4095,2). ismember(4095,3). ismember(4095,4). ismember(4095,5). ismember(4095,6). ismember(4095,7). ismember(4095,8). ismember(4095,9). ismember(4095,10). ismember(4095,11). ismember(4095,12). 
marginalize(0,0,4088,3,4092).
marginalize(0,0,3960,8,4088).
marginalize(0,0,3448,10,3960).
marginalize(0,0,1400,12,3448).
marginalize(0,0,1144,9,1400).
marginalize(0,0,1112,6,1144).
marginalize(0,0,88,11,1112).
marginalize(0,0,24,7,88).
marginalize(0,0,8,5,24).
marginalize(0,0,0,4,8).
marginalize(0,0,3962,8,4090).
marginalize(0,0,2938,11,3962).
marginalize(0,0,2906,6,2938).
marginalize(0,0,858,12,2906).
marginalize(0,0,842,5,858).
marginalize(0,0,586,9,842).
marginalize(0,0,522,7,586).
marginalize(0,0,10,10,522).
marginalize(0,0,8,2,10).
marginalize(0,0,4082,3,4086).
marginalize(0,0,4050,6,4082).
marginalize(0,0,4048,2,4050).
marginalize(0,0,3984,7,4048).
marginalize(0,0,3728,9,3984).
marginalize(0,0,3216,10,3728).
marginalize(0,0,3200,5,3216).
marginalize(0,0,1152,12,3200).
marginalize(0,0,1024,8,1152).
marginalize(0,0,0,11,1024).
marginalize(0,0,3950,8,4078).
marginalize(0,0,2926,11,3950).
marginalize(0,0,2862,7,2926).
marginalize(0,0,2860,2,2862).
marginalize(0,0,2856,3,2860).
marginalize(0,0,2848,4,2856).
marginalize(0,0,2592,9,2848).
marginalize(0,0,2080,10,2592).
marginalize(0,0,32,12,2080).
marginalize(0,0,0,6,32).
marginalize(0,0,4054,4,4062).
marginalize(0,0,3926,8,4054).
marginalize(0,0,1878,12,3926).
marginalize(0,0,1622,9,1878).
marginalize(0,0,1606,5,1622).
marginalize(0,0,1094,10,1606).
marginalize(0,0,70,11,1094).
marginalize(0,0,68,2,70).
marginalize(0,0,4,7,68).
marginalize(0,0,0,3,4).
marginalize(0,0,3518,10,4030).
marginalize(0,0,2494,11,3518).
marginalize(0,0,2490,3,2494).
marginalize(0,0,442,12,2490).
marginalize(0,0,440,2,442).
marginalize(0,0,184,9,440).
marginalize(0,0,168,5,184).
marginalize(0,0,40,8,168).
marginalize(0,0,32,4,40).
marginalize(0,0,3934,6,3966).
marginalize(0,0,2910,11,3934).
marginalize(0,0,2846,7,2910).
marginalize(0,0,2838,4,2846).
marginalize(0,0,2582,9,2838).
marginalize(0,0,2580,2,2582).
marginalize(0,0,532,12,2580).
marginalize(0,0,20,10,532).
marginalize(0,0,4,5,20).
marginalize(0,0,2814,11,3838).
marginalize(0,0,2750,7,2814).
marginalize(0,0,2734,5,2750).
marginalize(0,0,2730,3,2734).
marginalize(0,0,682,12,2730).
marginalize(0,0,674,4,682).
marginalize(0,0,162,10,674).
marginalize(0,0,160,2,162).
marginalize(0,0,128,6,160).
marginalize(0,0,0,8,128).
marginalize(0,0,3566,5,3582).
marginalize(0,0,3310,9,3566).
marginalize(0,0,3308,2,3310).
marginalize(0,0,1260,12,3308).
marginalize(0,0,1228,6,1260).
marginalize(0,0,1224,3,1228).
marginalize(0,0,200,11,1224).
marginalize(0,0,192,4,200).
marginalize(0,0,128,7,192).
marginalize(0,0,2558,10,3070).
marginalize(0,0,2302,9,2558).
marginalize(0,0,2270,6,2302).
marginalize(0,0,2262,4,2270).
marginalize(0,0,2198,7,2262).
marginalize(0,0,2196,2,2198).
marginalize(0,0,148,12,2196).
marginalize(0,0,144,3,148).
marginalize(0,0,128,5,144).
marginalize(0,0,1534,10,2046).
marginalize(0,0,1502,6,1534).
marginalize(0,0,1500,2,1502).
marginalize(0,0,1484,5,1500).
marginalize(0,0,460,11,1484).
marginalize(0,0,332,8,460).
marginalize(0,0,328,3,332).
marginalize(0,0,72,9,328).
marginalize(0,0,64,4,72).
marginalize(0,0,0,7,64).
marginalize(0,0,2041,12,4089).
marginalize(0,0,2033,4,2041).
marginalize(0,0,2017,5,2033).
marginalize(0,0,1761,9,2017).
marginalize(0,0,1633,8,1761).
marginalize(0,0,1601,6,1633).
marginalize(0,0,1537,7,1601).
marginalize(0,0,1536,1,1537).
marginalize(0,0,512,11,1536).
marginalize(0,0,0,10,512).
marginalize(0,0,3957,8,4085).
marginalize(0,0,2933,11,3957).
marginalize(0,0,2932,1,2933).
marginalize(0,0,2916,5,2932).
marginalize(0,0,2852,7,2916).
marginalize(0,0,2596,9,2852).
marginalize(0,0,2592,3,2596).
marginalize(0,0,4073,3,4077).
marginalize(0,0,2025,12,4073).
marginalize(0,0,1513,10,2025).
marginalize(0,0,489,11,1513).
marginalize(0,0,481,4,489).
marginalize(0,0,225,9,481).
marginalize(0,0,161,7,225).
marginalize(0,0,33,8,161).
marginalize(0,0,32,1,33).
marginalize(0,0,3997,7,4061).
marginalize(0,0,3741,9,3997).
marginalize(0,0,1693,12,3741).
marginalize(0,0,1181,10,1693).
marginalize(0,0,1165,5,1181).
marginalize(0,0,1161,3,1165).
marginalize(0,0,137,11,1161).
marginalize(0,0,136,1,137).
marginalize(0,0,8,8,136).
marginalize(0,0,3773,9,4029).
marginalize(0,0,3769,3,3773).
marginalize(0,0,3768,1,3769).
marginalize(0,0,3760,4,3768).
marginalize(0,0,1712,12,3760).
marginalize(0,0,1680,6,1712).
marginalize(0,0,1552,8,1680).
marginalize(0,0,528,11,1552).
marginalize(0,0,16,10,528).
marginalize(0,0,0,5,16).
marginalize(0,0,3961,3,3965).
marginalize(0,0,3449,10,3961).
marginalize(0,0,3417,6,3449).
marginalize(0,0,3161,9,3417).
marginalize(0,0,3097,7,3161).
marginalize(0,0,1049,12,3097).
marginalize(0,0,25,11,1049).
marginalize(0,0,24,1,25).
marginalize(0,0,3805,6,3837).
marginalize(0,0,3293,10,3805).
marginalize(0,0,3289,3,3293).
marginalize(0,0,3273,5,3289).
marginalize(0,0,3272,1,3273).
marginalize(0,0,1224,12,3272).
marginalize(0,0,2557,11,3581).
marginalize(0,0,2553,3,2557).
marginalize(0,0,2537,5,2553).
marginalize(0,0,2473,7,2537).
marginalize(0,0,2465,4,2473).
marginalize(0,0,417,12,2465).
marginalize(0,0,416,1,417).
marginalize(0,0,288,8,416).
marginalize(0,0,256,6,288).
marginalize(0,0,0,9,256).
marginalize(0,0,2941,8,3069).
marginalize(0,0,2877,7,2941).
marginalize(0,0,2869,4,2877).
marginalize(0,0,2357,10,2869).
marginalize(0,0,309,12,2357).
marginalize(0,0,293,5,309).
marginalize(0,0,292,1,293).
marginalize(0,0,288,3,292).
marginalize(0,0,1981,7,2045).
marginalize(0,0,1973,4,1981).
marginalize(0,0,1969,3,1973).
marginalize(0,0,945,11,1969).
marginalize(0,0,433,10,945).
marginalize(0,0,417,5,433).
marginalize(0,0,3571,10,4083).
marginalize(0,0,1523,12,3571).
marginalize(0,0,1395,8,1523).
marginalize(0,0,371,11,1395).
marginalize(0,0,370,1,371).
marginalize(0,0,114,9,370).
marginalize(0,0,112,2,114).
marginalize(0,0,96,5,112).
marginalize(0,0,32,7,96).
marginalize(0,0,3051,11,4075).
marginalize(0,0,2987,7,3051).
marginalize(0,0,2985,2,2987).
marginalize(0,0,2473,10,2985).
marginalize(0,0,3035,11,4059).
marginalize(0,0,2523,10,3035).
marginalize(0,0,2459,7,2523).
marginalize(0,0,2451,4,2459).
marginalize(0,0,2323,8,2451).
marginalize(0,0,2067,9,2323).
marginalize(0,0,2065,2,2067).
marginalize(0,0,17,12,2065).
marginalize(0,0,16,1,17).
marginalize(0,0,3899,8,4027).
marginalize(0,0,2875,11,3899).
marginalize(0,0,2619,9,2875).
marginalize(0,0,2618,1,2619).
marginalize(0,0,2586,6,2618).
marginalize(0,0,2578,4,2586).
marginalize(0,0,2066,10,2578).
marginalize(0,0,2064,2,2066).
marginalize(0,0,16,12,2064).
marginalize(0,0,3931,6,3963).
marginalize(0,0,3675,9,3931).
marginalize(0,0,3611,7,3675).
marginalize(0,0,2587,11,3611).
marginalize(0,0,2075,10,2587).
marginalize(0,0,2067,4,2075).
marginalize(0,0,3827,4,3835).
marginalize(0,0,3795,6,3827).
marginalize(0,0,3667,8,3795).
marginalize(0,0,1619,12,3667).
marginalize(0,0,1555,7,1619).
marginalize(0,0,1553,2,1555).
marginalize(0,0,1537,5,1553).
marginalize(0,0,3571,4,3579).
marginalize(0,0,1019,12,3067).
marginalize(0,0,1003,5,1019).
marginalize(0,0,1002,1,1003).
marginalize(0,0,994,4,1002).
marginalize(0,0,992,2,994).
marginalize(0,0,928,7,992).
marginalize(0,0,672,9,928).
marginalize(0,0,160,10,672).
marginalize(0,0,1531,10,2043).
marginalize(0,0,1275,9,1531).
marginalize(0,0,1267,4,1275).
marginalize(0,0,1265,2,1267).
marginalize(0,0,1233,6,1265).
marginalize(0,0,1232,1,1233).
marginalize(0,0,1216,5,1232).
marginalize(0,0,1088,8,1216).
marginalize(0,0,1024,7,1088).
marginalize(0,0,3943,8,4071).
marginalize(0,0,3879,7,3943).
marginalize(0,0,2855,11,3879).
marginalize(0,0,2853,2,2855).
marginalize(0,0,805,12,2853).
marginalize(0,0,801,3,805).
marginalize(0,0,769,6,801).
marginalize(0,0,768,1,769).
marginalize(0,0,256,10,768).
marginalize(0,0,2007,12,4055).
marginalize(0,0,2005,2,2007).
marginalize(0,0,1493,10,2005).
marginalize(0,0,1492,1,1493).
marginalize(0,0,1476,5,1492).
marginalize(0,0,1412,7,1476).
marginalize(0,0,1156,9,1412).
marginalize(0,0,1028,8,1156).
marginalize(0,0,1024,3,1028).
marginalize(0,0,3767,9,4023).
marginalize(0,0,3765,2,3767).
marginalize(0,0,3749,5,3765).
marginalize(0,0,3237,10,3749).
marginalize(0,0,3109,8,3237).
marginalize(0,0,2085,11,3109).
marginalize(0,0,2053,6,2085).
marginalize(0,0,2052,1,2053).
marginalize(0,0,4,12,2052).
marginalize(0,0,3943,5,3959).
marginalize(0,0,3799,6,3831).
marginalize(0,0,3797,2,3799).
marginalize(0,0,3669,8,3797).
marginalize(0,0,3668,1,3669).
marginalize(0,0,2644,11,3668).
marginalize(0,0,596,12,2644).
marginalize(0,0,532,7,596).
marginalize(0,0,3543,6,3575).
marginalize(0,0,3542,1,3543).
marginalize(0,0,3286,9,3542).
marginalize(0,0,3284,2,3286).
marginalize(0,0,3156,8,3284).
marginalize(0,0,3092,7,3156).
marginalize(0,0,3088,3,3092).
marginalize(0,0,2064,11,3088).
marginalize(0,0,2999,7,3063).
marginalize(0,0,2487,10,2999).
marginalize(0,0,2455,6,2487).
marginalize(0,0,407,12,2455).
marginalize(0,0,279,8,407).
marginalize(0,0,277,2,279).
marginalize(0,0,273,3,277).
marginalize(0,0,17,9,273).
marginalize(0,0,1015,11,2039).
marginalize(0,0,1011,3,1015).
marginalize(0,0,1010,1,1011).
marginalize(0,0,946,7,1010).
marginalize(0,0,914,6,946).
marginalize(0,0,786,8,914).
marginalize(0,0,274,10,786).
marginalize(0,0,272,2,274).
marginalize(0,0,16,9,272).
marginalize(0,0,4043,3,4047).
marginalize(0,0,3531,10,4043).
marginalize(0,0,3403,8,3531).
marginalize(0,0,1355,12,3403).
marginalize(0,0,1347,4,1355).
marginalize(0,0,323,11,1347).
marginalize(0,0,259,7,323).
marginalize(0,0,258,1,259).
marginalize(0,0,2,9,258).
marginalize(0,0,0,2,2).
marginalize(0,0,3983,6,4015).
marginalize(0,0,3975,4,3983).
marginalize(0,0,3973,2,3975).
marginalize(0,0,1925,12,3973).
marginalize(0,0,1669,9,1925).
marginalize(0,0,1665,3,1669).
marginalize(0,0,1537,8,1665).
marginalize(0,0,2927,11,3951).
marginalize(0,0,2671,9,2927).
marginalize(0,0,2607,7,2671).
marginalize(0,0,559,12,2607).
marginalize(0,0,555,3,559).
marginalize(0,0,43,10,555).
marginalize(0,0,35,4,43).
marginalize(0,0,3,6,35).
marginalize(0,0,2,1,3).
marginalize(0,0,2799,11,3823).
marginalize(0,0,2735,7,2799).
marginalize(0,0,2731,3,2735).
marginalize(0,0,2219,10,2731).
marginalize(0,0,2217,2,2219).
marginalize(0,0,2209,4,2217).
marginalize(0,0,2177,6,2209).
marginalize(0,0,129,12,2177).
marginalize(0,0,128,1,129).
marginalize(0,0,3565,2,3567).
marginalize(0,0,3309,9,3565).
marginalize(0,0,3245,7,3309).
marginalize(0,0,3241,3,3245).
marginalize(0,0,3113,8,3241).
marginalize(0,0,2089,11,3113).
marginalize(0,0,2057,6,2089).
marginalize(0,0,2056,1,2057).
marginalize(0,0,8,12,2056).
marginalize(0,0,3023,6,3055).
marginalize(0,0,3015,4,3023).
marginalize(0,0,2887,8,3015).
marginalize(0,0,2886,1,2887).
marginalize(0,0,2374,10,2886).
marginalize(0,0,2310,7,2374).
marginalize(0,0,262,12,2310).
marginalize(0,0,258,3,262).
marginalize(0,0,1903,8,2031).
marginalize(0,0,1391,10,1903).
marginalize(0,0,1327,7,1391).
marginalize(0,0,1295,6,1327).
marginalize(0,0,1294,1,1295).
marginalize(0,0,1290,3,1294).
marginalize(0,0,266,11,1290).
marginalize(0,0,264,2,266).
marginalize(0,0,256,4,264).
marginalize(0,0,3997,2,3999).
marginalize(0,0,3919,5,3935).
marginalize(0,0,3917,2,3919).
marginalize(0,0,2893,11,3917).
marginalize(0,0,2381,10,2893).
marginalize(0,0,333,12,2381).
marginalize(0,0,269,7,333).
marginalize(0,0,268,1,269).
marginalize(0,0,264,3,268).
marginalize(0,0,3679,8,3807).
marginalize(0,0,3677,2,3679).
marginalize(0,0,3165,10,3677).
marginalize(0,0,3164,1,3165).
marginalize(0,0,3148,5,3164).
marginalize(0,0,1100,12,3148).
marginalize(0,0,1036,7,1100).
marginalize(0,0,12,11,1036).
marginalize(0,0,8,3,12).
marginalize(0,0,3549,2,3551).
marginalize(0,0,3545,3,3549).
marginalize(0,0,3537,4,3545).
marginalize(0,0,2513,11,3537).
marginalize(0,0,465,12,2513).
marginalize(0,0,449,5,465).
marginalize(0,0,193,9,449).
marginalize(0,0,129,7,193).
marginalize(0,0,3031,4,3039).
marginalize(0,0,983,12,3031).
marginalize(0,0,727,9,983).
marginalize(0,0,663,7,727).
marginalize(0,0,535,8,663).
marginalize(0,0,534,1,535).
marginalize(0,0,532,2,534).
marginalize(0,0,1999,5,2015).
marginalize(0,0,1935,7,1999).
marginalize(0,0,1807,8,1935).
marginalize(0,0,1551,9,1807).
marginalize(0,0,1039,10,1551).
marginalize(0,0,1031,4,1039).
marginalize(0,0,1029,2,1031).
marginalize(0,0,1028,1,1029).
marginalize(0,0,3895,4,3903).
marginalize(0,0,3893,2,3895).
marginalize(0,0,3877,5,3893).
marginalize(0,0,1829,12,3877).
marginalize(0,0,1317,10,1829).
marginalize(0,0,1061,9,1317).
marginalize(0,0,1060,1,1061).
marginalize(0,0,1056,3,1060).
marginalize(0,0,32,11,1056).
marginalize(0,0,3767,4,3775).
marginalize(0,0,3487,6,3519).
marginalize(0,0,3483,3,3487).
marginalize(0,0,2459,11,3483).
marginalize(0,0,3005,2,3007).
marginalize(0,0,957,12,3005).
marginalize(0,0,829,8,957).
marginalize(0,0,813,5,829).
marginalize(0,0,809,3,813).
marginalize(0,0,777,6,809).
marginalize(0,0,521,9,777).
marginalize(0,0,9,10,521).
marginalize(0,0,1,4,9).
marginalize(0,0,0,1,1).
marginalize(0,0,1727,9,1983).
marginalize(0,0,1723,3,1727).
marginalize(0,0,1721,2,1723).
marginalize(0,0,1209,10,1721).
marginalize(0,0,185,11,1209).
marginalize(0,0,177,4,185).
marginalize(0,0,49,8,177).
marginalize(0,0,33,5,49).
marginalize(0,0,2687,11,3711).
marginalize(0,0,639,12,2687).
marginalize(0,0,127,10,639).
marginalize(0,0,111,5,127).
marginalize(0,0,109,2,111).
marginalize(0,0,77,6,109).
marginalize(0,0,69,4,77).
marginalize(0,0,68,1,69).
marginalize(0,0,3453,2,3455).
marginalize(0,0,1405,12,3453).
marginalize(0,0,1149,9,1405).
marginalize(0,0,1148,1,1149).
marginalize(0,0,1144,3,1148).
marginalize(0,0,2935,4,2943).
marginalize(0,0,2679,9,2935).
marginalize(0,0,631,12,2679).
marginalize(0,0,627,3,631).
marginalize(0,0,595,6,627).
marginalize(0,0,531,7,595).
marginalize(0,0,529,2,531).
marginalize(0,0,17,10,529).
marginalize(0,0,1663,9,1919).
marginalize(0,0,1647,5,1663).
marginalize(0,0,1583,7,1647).
marginalize(0,0,1582,1,1583).
marginalize(0,0,558,11,1582).
marginalize(0,0,550,4,558).
marginalize(0,0,546,3,550).
marginalize(0,0,514,6,546).
marginalize(0,0,512,2,514).
marginalize(0,0,1279,12,3327).
marginalize(0,0,1263,5,1279).
marginalize(0,0,1261,2,1263).
marginalize(0,0,1133,8,1261).
marginalize(0,0,1129,3,1133).
marginalize(0,0,1121,4,1129).
marginalize(0,0,97,11,1121).
marginalize(0,0,65,6,97).
marginalize(0,0,1,7,65).
marginalize(0,0,2813,2,2815).
marginalize(0,0,2805,4,2813).
marginalize(0,0,2801,3,2805).
marginalize(0,0,2737,7,2801).
marginalize(0,0,689,12,2737).
marginalize(0,0,657,6,689).
marginalize(0,0,656,1,657).
marginalize(0,0,640,5,656).
marginalize(0,0,512,8,640).
marginalize(0,0,1727,7,1791).
marginalize(0,0,2551,4,2559).
marginalize(0,0,2423,8,2551).
marginalize(0,0,375,12,2423).
marginalize(0,0,371,3,375).
marginalize(0,0,1527,4,1535).
marginalize(0,0,1526,1,1527).
marginalize(0,0,1522,3,1526).
marginalize(0,0,498,11,1522).
marginalize(0,0,482,5,498).
marginalize(0,0,418,7,482).
marginalize(0,0,416,2,418).
marginalize(0,0,895,8,1023).
marginalize(0,0,639,9,895).
condition(0,3,4,0,4088).
condition(0,4,8,0,4084).
marginalize(0,0,3060,11,4084).
marginalize(0,0,3056,3,3060).
marginalize(0,0,2800,9,3056).
marginalize(0,0,2672,8,2800).
marginalize(0,0,2608,7,2672).
marginalize(0,0,2592,5,2608).
condition(0,5,16,0,4076).
marginalize(0,0,3820,9,4076).
marginalize(0,0,1772,12,3820).
marginalize(0,0,1708,7,1772).
marginalize(0,0,684,11,1708).
marginalize(0,0,652,6,684).
marginalize(0,0,524,8,652).
marginalize(0,0,12,10,524).
condition(0,6,32,0,4060).
marginalize(0,0,3548,10,4060).
marginalize(0,0,1500,12,3548).
condition(0,7,64,0,4028).
marginalize(0,0,3772,9,4028).
marginalize(0,0,3260,10,3772).
marginalize(0,0,3252,4,3260).
marginalize(0,0,1204,12,3252).
marginalize(0,0,1200,3,1204).
marginalize(0,0,1072,8,1200).
marginalize(0,0,1056,5,1072).
condition(0,8,128,0,3964).
marginalize(0,0,3932,6,3964).
marginalize(0,0,3924,4,3932).
marginalize(0,0,2900,11,3924).
marginalize(0,0,2644,9,2900).
condition(0,9,256,0,3836).
marginalize(0,0,3324,10,3836).
marginalize(0,0,3308,5,3324).
condition(0,10,512,0,3580).
marginalize(0,0,3516,7,3580).
marginalize(0,0,3500,5,3516).
marginalize(0,0,3468,6,3500).
marginalize(0,0,3212,9,3468).
marginalize(0,0,3204,4,3212).
marginalize(0,0,1156,12,3204).
condition(0,11,1024,0,3068).
marginalize(0,0,1020,12,3068).
marginalize(0,0,1016,3,1020).
marginalize(0,0,1000,5,1016).
marginalize(0,0,488,10,1000).
marginalize(0,0,456,6,488).
marginalize(0,0,200,9,456).
condition(0,12,2048,0,2044).
marginalize(0,0,2040,3,2044).
marginalize(0,0,1976,7,2040).
marginalize(0,0,952,11,1976).
marginalize(0,0,440,10,952).
condition(0,2,2,0,4088).
condition(0,4,8,0,4082).
condition(0,5,16,0,4074).
marginalize(0,0,4042,6,4074).
marginalize(0,0,4034,4,4042).
marginalize(0,0,3010,11,4034).
marginalize(0,0,2498,10,3010).
marginalize(0,0,450,12,2498).
marginalize(0,0,386,7,450).
marginalize(0,0,384,2,386).
marginalize(0,0,128,9,384).
condition(0,6,32,0,4058).
marginalize(0,0,4042,5,4058).
condition(0,7,64,0,4026).
marginalize(0,0,3770,9,4026).
marginalize(0,0,3642,8,3770).
marginalize(0,0,2618,11,3642).
condition(0,8,128,0,3962).
condition(0,9,256,0,3834).
marginalize(0,0,3322,10,3834).
marginalize(0,0,1274,12,3322).
marginalize(0,0,1266,4,1274).
marginalize(0,0,1250,5,1266).
marginalize(0,0,226,11,1250).
marginalize(0,0,224,2,226).
marginalize(0,0,192,6,224).
condition(0,10,512,0,3578).
marginalize(0,0,3546,6,3578).
marginalize(0,0,3538,4,3546).
marginalize(0,0,3522,5,3538).
marginalize(0,0,3394,8,3522).
marginalize(0,0,2370,11,3394).
marginalize(0,0,322,12,2370).
marginalize(0,0,258,7,322).
condition(0,11,1024,0,3066).
marginalize(0,0,2554,10,3066).
marginalize(0,0,2552,2,2554).
marginalize(0,0,2424,8,2552).
marginalize(0,0,2360,7,2424).
marginalize(0,0,2104,9,2360).
marginalize(0,0,2072,6,2104).
marginalize(0,0,2064,4,2072).
condition(0,12,2048,0,2042).
marginalize(0,0,1914,8,2042).
marginalize(0,0,1882,6,1914).
marginalize(0,0,1866,5,1882).
marginalize(0,0,1354,10,1866).
marginalize(0,0,1098,9,1354).
marginalize(0,0,1034,7,1098).
marginalize(0,0,1032,2,1034).
marginalize(0,0,8,11,1032).
condition(0,2,2,0,4084).
condition(0,3,4,0,4082).
condition(0,5,16,0,4070).
marginalize(0,0,4068,2,4070).
marginalize(0,0,3812,9,4068).
marginalize(0,0,3808,3,3812).
marginalize(0,0,1760,12,3808).
marginalize(0,0,1248,10,1760).
marginalize(0,0,1216,6,1248).
condition(0,6,32,0,4054).
condition(0,7,64,0,4022).
marginalize(0,0,1974,12,4022).
marginalize(0,0,1718,9,1974).
marginalize(0,0,694,11,1718).
marginalize(0,0,678,5,694).
marginalize(0,0,646,6,678).
marginalize(0,0,518,8,646).
marginalize(0,0,514,3,518).
condition(0,8,128,0,3958).
marginalize(0,0,1910,12,3958).
marginalize(0,0,1398,10,1910).
marginalize(0,0,1394,3,1398).
marginalize(0,0,1330,7,1394).
marginalize(0,0,306,11,1330).
marginalize(0,0,304,2,306).
marginalize(0,0,288,5,304).
condition(0,9,256,0,3830).
marginalize(0,0,1782,12,3830).
marginalize(0,0,1750,6,1782).
marginalize(0,0,1746,3,1750).
marginalize(0,0,1744,2,1746).
marginalize(0,0,1680,7,1744).
condition(0,10,512,0,3574).
marginalize(0,0,2550,11,3574).
marginalize(0,0,2486,7,2550).
marginalize(0,0,438,12,2486).
marginalize(0,0,422,5,438).
marginalize(0,0,166,9,422).
marginalize(0,0,134,6,166).
marginalize(0,0,132,2,134).
marginalize(0,0,128,3,132).
condition(0,11,1024,0,3062).
marginalize(0,0,2934,8,3062).
marginalize(0,0,2422,10,2934).
marginalize(0,0,2358,7,2422).
marginalize(0,0,2354,3,2358).
marginalize(0,0,306,12,2354).
condition(0,12,2048,0,2038).
marginalize(0,0,2006,6,2038).
marginalize(0,0,1750,9,2006).
condition(0,2,2,0,4076).
condition(0,3,4,0,4074).
condition(0,4,8,0,4070).
condition(0,6,32,0,4046).
marginalize(0,0,1998,12,4046).
marginalize(0,0,1934,7,1998).
marginalize(0,0,1806,8,1934).
marginalize(0,0,1804,2,1806).
marginalize(0,0,780,11,1804).
marginalize(0,0,772,4,780).
marginalize(0,0,516,9,772).
marginalize(0,0,4,10,516).
condition(0,7,64,0,4014).
marginalize(0,0,4010,3,4014).
marginalize(0,0,3882,8,4010).
marginalize(0,0,3874,4,3882).
marginalize(0,0,3872,2,3874).
marginalize(0,0,3616,9,3872).
marginalize(0,0,3584,6,3616).
marginalize(0,0,3072,10,3584).
marginalize(0,0,1024,12,3072).
condition(0,8,128,0,3950).
condition(0,9,256,0,3822).
marginalize(0,0,3820,2,3822).
condition(0,10,512,0,3566).
condition(0,11,1024,0,3054).
marginalize(0,0,3022,6,3054).
marginalize(0,0,3020,2,3022).
marginalize(0,0,2764,9,3020).
marginalize(0,0,2760,3,2764).
marginalize(0,0,2248,10,2760).
marginalize(0,0,200,12,2248).
condition(0,12,2048,0,2030).
marginalize(0,0,1966,7,2030).
marginalize(0,0,1934,6,1966).
condition(0,2,2,0,4060).
condition(0,3,4,0,4058).
condition(0,4,8,0,4054).
condition(0,5,16,0,4046).
condition(0,7,64,0,3998).
marginalize(0,0,3870,8,3998).
marginalize(0,0,3866,3,3870).
marginalize(0,0,3858,4,3866).
marginalize(0,0,3842,5,3858).
marginalize(0,0,2818,11,3842).
marginalize(0,0,2306,10,2818).
marginalize(0,0,2304,2,2306).
marginalize(0,0,2048,9,2304).
marginalize(0,0,0,12,2048).
condition(0,8,128,0,3934).
condition(0,9,256,0,3806).
marginalize(0,0,3678,8,3806).
marginalize(0,0,2654,11,3678).
marginalize(0,0,2646,4,2654).
marginalize(0,0,2642,3,2646).
marginalize(0,0,594,12,2642).
marginalize(0,0,82,10,594).
marginalize(0,0,80,2,82).
marginalize(0,0,64,5,80).
condition(0,10,512,0,3550).
marginalize(0,0,3422,8,3550).
marginalize(0,0,3406,5,3422).
marginalize(0,0,3404,2,3406).
marginalize(0,0,2380,11,3404).
marginalize(0,0,2124,9,2380).
marginalize(0,0,2060,7,2124).
marginalize(0,0,2056,3,2060).
condition(0,11,1024,0,3038).
marginalize(0,0,2526,10,3038).
marginalize(0,0,2398,8,2526).
marginalize(0,0,2396,2,2398).
marginalize(0,0,348,12,2396).
marginalize(0,0,92,9,348).
marginalize(0,0,76,5,92).
marginalize(0,0,12,7,76).
condition(0,12,2048,0,2014).
marginalize(0,0,990,11,2014).
marginalize(0,0,974,5,990).
marginalize(0,0,970,3,974).
marginalize(0,0,842,8,970).
condition(0,2,2,0,4028).
condition(0,3,4,0,4026).
condition(0,4,8,0,4022).
condition(0,5,16,0,4014).
condition(0,6,32,0,3998).
condition(0,8,128,0,3902).
marginalize(0,0,1854,12,3902).
marginalize(0,0,1838,5,1854).
marginalize(0,0,1836,2,1838).
marginalize(0,0,1828,4,1836).
marginalize(0,0,1316,10,1828).
marginalize(0,0,292,11,1316).
condition(0,9,256,0,3774).
marginalize(0,0,3758,5,3774).
marginalize(0,0,3756,2,3758).
marginalize(0,0,3628,8,3756).
marginalize(0,0,3116,10,3628).
marginalize(0,0,3108,4,3116).
marginalize(0,0,1060,12,3108).
condition(0,10,512,0,3518).
condition(0,11,1024,0,3006).
marginalize(0,0,2750,9,3006).
condition(0,12,2048,0,1982).
marginalize(0,0,958,11,1982).
marginalize(0,0,950,4,958).
marginalize(0,0,822,8,950).
marginalize(0,0,818,3,822).
marginalize(0,0,306,10,818).
condition(0,2,2,0,3964).
condition(0,3,4,0,3962).
condition(0,4,8,0,3958).
condition(0,5,16,0,3950).
condition(0,6,32,0,3934).
condition(0,7,64,0,3902).
condition(0,9,256,0,3710).
marginalize(0,0,1662,12,3710).
marginalize(0,0,1658,3,1662).
marginalize(0,0,1650,4,1658).
marginalize(0,0,1586,7,1650).
marginalize(0,0,1074,10,1586).
marginalize(0,0,1072,2,1074).
condition(0,10,512,0,3454).
marginalize(0,0,2430,11,3454).
marginalize(0,0,2414,5,2430).
marginalize(0,0,2412,2,2414).
marginalize(0,0,2156,9,2412).
marginalize(0,0,2148,4,2156).
marginalize(0,0,100,12,2148).
marginalize(0,0,68,6,100).
condition(0,11,1024,0,2942).
marginalize(0,0,2910,6,2942).
condition(0,12,2048,0,1918).
marginalize(0,0,1916,2,1918).
marginalize(0,0,1404,10,1916).
marginalize(0,0,1372,6,1404).
marginalize(0,0,1308,7,1372).
marginalize(0,0,284,11,1308).
marginalize(0,0,268,5,284).
condition(0,2,2,0,3836).
condition(0,3,4,0,3834).
condition(0,4,8,0,3830).
condition(0,5,16,0,3822).
condition(0,6,32,0,3806).
condition(0,7,64,0,3774).
condition(0,8,128,0,3710).
condition(0,10,512,0,3326).
marginalize(0,0,3318,4,3326).
marginalize(0,0,3314,3,3318).
marginalize(0,0,3312,2,3314).
marginalize(0,0,2288,11,3312).
marginalize(0,0,2224,7,2288).
marginalize(0,0,176,12,2224).
marginalize(0,0,144,6,176).
condition(0,11,1024,0,2814).
condition(0,12,2048,0,1790).
marginalize(0,0,1782,4,1790).
condition(0,2,2,0,3580).
condition(0,3,4,0,3578).
condition(0,4,8,0,3574).
condition(0,5,16,0,3566).
condition(0,6,32,0,3550).
condition(0,7,64,0,3518).
condition(0,8,128,0,3454).
condition(0,9,256,0,3326).
condition(0,11,1024,0,2558).
condition(0,12,2048,0,1534).
condition(0,2,2,0,3068).
condition(0,3,4,0,3066).
condition(0,4,8,0,3062).
condition(0,5,16,0,3054).
condition(0,6,32,0,3038).
condition(0,7,64,0,3006).
condition(0,8,128,0,2942).
condition(0,9,256,0,2814).
condition(0,10,512,0,2558).
condition(0,12,2048,0,1022).
marginalize(0,0,990,6,1022).
condition(0,2,2,0,2044).
condition(0,3,4,0,2042).
condition(0,4,8,0,2038).
condition(0,5,16,0,2030).
condition(0,6,32,0,2014).
condition(0,7,64,0,1982).
condition(0,8,128,0,1918).
condition(0,9,256,0,1790).
condition(0,10,512,0,1534).
condition(0,11,1024,0,1022).
condition(0,1,1,0,4088).
condition(0,4,8,0,4081).
marginalize(0,0,3569,10,4081).
marginalize(0,0,3568,1,3569).
marginalize(0,0,3552,5,3568).
marginalize(0,0,3424,8,3552).
marginalize(0,0,3392,6,3424).
marginalize(0,0,2368,11,3392).
marginalize(0,0,320,12,2368).
marginalize(0,0,64,9,320).
condition(0,5,16,0,4073).
condition(0,6,32,0,4057).
marginalize(0,0,4049,4,4057).
marginalize(0,0,2001,12,4049).
marginalize(0,0,1745,9,2001).
marginalize(0,0,721,11,1745).
marginalize(0,0,209,10,721).
marginalize(0,0,208,1,209).
marginalize(0,0,80,8,208).
condition(0,7,64,0,4025).
marginalize(0,0,3897,8,4025).
marginalize(0,0,3385,10,3897).
marginalize(0,0,1337,12,3385).
marginalize(0,0,1305,6,1337).
marginalize(0,0,1289,5,1305).
marginalize(0,0,1288,1,1289).
marginalize(0,0,264,11,1288).
condition(0,8,128,0,3961).
condition(0,9,256,0,3833).
marginalize(0,0,3321,10,3833).
marginalize(0,0,1273,12,3321).
marginalize(0,0,1241,6,1273).
marginalize(0,0,1240,1,1241).
marginalize(0,0,1232,4,1240).
condition(0,10,512,0,3577).
marginalize(0,0,3449,8,3577).
condition(0,11,1024,0,3065).
marginalize(0,0,1017,12,3065).
marginalize(0,0,889,8,1017).
marginalize(0,0,633,9,889).
marginalize(0,0,632,1,633).
marginalize(0,0,616,5,632).
marginalize(0,0,552,7,616).
marginalize(0,0,544,4,552).
marginalize(0,0,512,6,544).
condition(0,12,2048,0,2041).
condition(0,1,1,0,4084).
condition(0,3,4,0,4081).
condition(0,5,16,0,4069).
marginalize(0,0,2021,12,4069).
marginalize(0,0,1765,9,2021).
marginalize(0,0,1764,1,1765).
marginalize(0,0,1760,3,1764).
condition(0,6,32,0,4053).
marginalize(0,0,4037,5,4053).
marginalize(0,0,3909,8,4037).
marginalize(0,0,3845,7,3909).
marginalize(0,0,3589,9,3845).
marginalize(0,0,3588,1,3589).
marginalize(0,0,2564,11,3588).
marginalize(0,0,2560,3,2564).
marginalize(0,0,512,12,2560).
condition(0,7,64,0,4021).
marginalize(0,0,4017,3,4021).
marginalize(0,0,2993,11,4017).
marginalize(0,0,945,12,2993).
condition(0,8,128,0,3957).
condition(0,9,256,0,3829).
marginalize(0,0,2805,11,3829).
condition(0,10,512,0,3573).
marginalize(0,0,2549,11,3573).
marginalize(0,0,2517,6,2549).
marginalize(0,0,2501,5,2517).
marginalize(0,0,2500,1,2501).
marginalize(0,0,2244,9,2500).
marginalize(0,0,2116,8,2244).
marginalize(0,0,2112,3,2116).
marginalize(0,0,2048,7,2112).
condition(0,11,1024,0,3061).
marginalize(0,0,3060,1,3061).
condition(0,12,2048,0,2037).
marginalize(0,0,1013,11,2037).
marginalize(0,0,981,6,1013).
marginalize(0,0,977,3,981).
marginalize(0,0,849,8,977).
marginalize(0,0,848,1,849).
marginalize(0,0,336,10,848).
marginalize(0,0,272,7,336).
condition(0,1,1,0,4076).
condition(0,3,4,0,4073).
condition(0,4,8,0,4069).
condition(0,6,32,0,4045).
marginalize(0,0,4044,1,4045).
marginalize(0,0,3532,10,4044).
marginalize(0,0,2508,11,3532).
marginalize(0,0,2500,4,2508).
condition(0,7,64,0,4013).
marginalize(0,0,3981,6,4013).
marginalize(0,0,1933,12,3981).
marginalize(0,0,1421,10,1933).
marginalize(0,0,1413,4,1421).
marginalize(0,0,389,11,1413).
marginalize(0,0,388,1,389).
marginalize(0,0,132,9,388).
condition(0,8,128,0,3949).
marginalize(0,0,3693,9,3949).
marginalize(0,0,3661,6,3693).
marginalize(0,0,3657,3,3661).
marginalize(0,0,3649,4,3657).
marginalize(0,0,1601,12,3649).
condition(0,9,256,0,3821).
marginalize(0,0,3820,1,3821).
condition(0,10,512,0,3565).
condition(0,11,1024,0,3053).
marginalize(0,0,2541,10,3053).
marginalize(0,0,2540,1,2541).
marginalize(0,0,2412,8,2540).
condition(0,12,2048,0,2029).
marginalize(0,0,1901,8,2029).
marginalize(0,0,877,11,1901).
marginalize(0,0,845,6,877).
marginalize(0,0,781,7,845).
marginalize(0,0,269,10,781).
condition(0,1,1,0,4060).
condition(0,3,4,0,4057).
condition(0,4,8,0,4053).
condition(0,5,16,0,4045).
condition(0,7,64,0,3997).
condition(0,8,128,0,3933).
marginalize(0,0,3925,4,3933).
marginalize(0,0,3921,3,3925).
marginalize(0,0,1873,12,3921).
marginalize(0,0,1857,5,1873).
marginalize(0,0,1793,7,1857).
marginalize(0,0,1792,1,1793).
marginalize(0,0,1536,9,1792).
condition(0,9,256,0,3805).
condition(0,10,512,0,3549).
condition(0,11,1024,0,3037).
marginalize(0,0,2781,9,3037).
marginalize(0,0,733,12,2781).
marginalize(0,0,729,3,733).
marginalize(0,0,217,10,729).
marginalize(0,0,209,4,217).
condition(0,12,2048,0,2013).
marginalize(0,0,2005,4,2013).
condition(0,1,1,0,4028).
condition(0,3,4,0,4025).
condition(0,4,8,0,4021).
condition(0,5,16,0,4013).
condition(0,6,32,0,3997).
condition(0,8,128,0,3901).
marginalize(0,0,3885,5,3901).
marginalize(0,0,3629,9,3885).
marginalize(0,0,3625,3,3629).
marginalize(0,0,3593,6,3625).
marginalize(0,0,1545,12,3593).
marginalize(0,0,1033,10,1545).
marginalize(0,0,1032,1,1033).
condition(0,9,256,0,3773).
condition(0,10,512,0,3517).
marginalize(0,0,3509,4,3517).
marginalize(0,0,3493,5,3509).
marginalize(0,0,3461,6,3493).
marginalize(0,0,3460,1,3461).
marginalize(0,0,3456,3,3460).
marginalize(0,0,3328,8,3456).
marginalize(0,0,3072,9,3328).
condition(0,11,1024,0,3005).
condition(0,12,2048,0,1981).
condition(0,1,1,0,3964).
condition(0,3,4,0,3961).
condition(0,4,8,0,3957).
condition(0,5,16,0,3949).
condition(0,6,32,0,3933).
condition(0,7,64,0,3901).
condition(0,9,256,0,3709).
marginalize(0,0,3705,3,3709).
marginalize(0,0,3193,10,3705).
marginalize(0,0,2169,11,3193).
marginalize(0,0,2161,4,2169).
marginalize(0,0,2160,1,2161).
marginalize(0,0,2096,7,2160).
marginalize(0,0,2064,6,2096).
condition(0,10,512,0,3453).
condition(0,11,1024,0,2941).
condition(0,12,2048,0,1917).
marginalize(0,0,1405,10,1917).
condition(0,1,1,0,3836).
condition(0,3,4,0,3833).
condition(0,4,8,0,3829).
condition(0,5,16,0,3821).
condition(0,6,32,0,3805).
condition(0,7,64,0,3773).
condition(0,8,128,0,3709).
condition(0,10,512,0,3325).
marginalize(0,0,1277,12,3325).
marginalize(0,0,1261,5,1277).
condition(0,11,1024,0,2813).
condition(0,12,2048,0,1789).
marginalize(0,0,1277,10,1789).
condition(0,1,1,0,3580).
condition(0,3,4,0,3577).
condition(0,4,8,0,3573).
condition(0,5,16,0,3565).
condition(0,6,32,0,3549).
condition(0,7,64,0,3517).
condition(0,8,128,0,3453).
condition(0,9,256,0,3325).
condition(0,11,1024,0,2557).
condition(0,12,2048,0,1533).
marginalize(0,0,1469,7,1533).
marginalize(0,0,1468,1,1469).
marginalize(0,0,1452,5,1468).
marginalize(0,0,1420,6,1452).
marginalize(0,0,1416,3,1420).
marginalize(0,0,1408,4,1416).
marginalize(0,0,1280,8,1408).
marginalize(0,0,256,11,1280).
condition(0,1,1,0,3068).
condition(0,3,4,0,3065).
condition(0,4,8,0,3061).
condition(0,5,16,0,3053).
condition(0,6,32,0,3037).
condition(0,7,64,0,3005).
condition(0,8,128,0,2941).
condition(0,9,256,0,2813).
condition(0,10,512,0,2557).
condition(0,12,2048,0,1021).
marginalize(0,0,1017,3,1021).
condition(0,1,1,0,2044).
condition(0,3,4,0,2041).
condition(0,4,8,0,2037).
condition(0,5,16,0,2029).
condition(0,6,32,0,2013).
condition(0,7,64,0,1981).
condition(0,8,128,0,1917).
condition(0,9,256,0,1789).
condition(0,10,512,0,1533).
condition(0,11,1024,0,1021).
condition(0,1,1,0,4082).
condition(0,2,2,0,4081).
condition(0,5,16,0,4067).
marginalize(0,0,4035,6,4067).
marginalize(0,0,4033,2,4035).
marginalize(0,0,1985,12,4033).
marginalize(0,0,1729,9,1985).
marginalize(0,0,705,11,1729).
marginalize(0,0,641,7,705).
marginalize(0,0,513,8,641).
marginalize(0,0,1,10,513).
condition(0,6,32,0,4051).
marginalize(0,0,4049,2,4051).
condition(0,7,64,0,4019).
marginalize(0,0,3987,6,4019).
marginalize(0,0,2963,11,3987).
marginalize(0,0,915,12,2963).
marginalize(0,0,899,5,915).
marginalize(0,0,897,2,899).
marginalize(0,0,641,9,897).
condition(0,8,128,0,3955).
marginalize(0,0,3699,9,3955).
marginalize(0,0,3635,7,3699).
marginalize(0,0,3634,1,3635).
marginalize(0,0,1586,12,3634).
condition(0,9,256,0,3827).
condition(0,10,512,0,3571).
condition(0,11,1024,0,3059).
marginalize(0,0,2803,9,3059).
marginalize(0,0,2291,10,2803).
marginalize(0,0,2290,1,2291).
marginalize(0,0,2162,8,2290).
marginalize(0,0,2146,5,2162).
marginalize(0,0,2114,6,2146).
marginalize(0,0,2050,7,2114).
marginalize(0,0,2,12,2050).
condition(0,12,2048,0,2035).
marginalize(0,0,2003,6,2035).
marginalize(0,0,1747,9,2003).
marginalize(0,0,1683,7,1747).
marginalize(0,0,1171,10,1683).
marginalize(0,0,1170,1,1171).
marginalize(0,0,1154,5,1170).
marginalize(0,0,1026,8,1154).
marginalize(0,0,2,11,1026).
condition(0,1,1,0,4074).
condition(0,2,2,0,4073).
condition(0,4,8,0,4067).
condition(0,6,32,0,4043).
condition(0,7,64,0,4011).
marginalize(0,0,3755,9,4011).
marginalize(0,0,3243,10,3755).
marginalize(0,0,3242,1,3243).
marginalize(0,0,2218,11,3242).
marginalize(0,0,2216,2,2218).
marginalize(0,0,2184,6,2216).
marginalize(0,0,2176,4,2184).
marginalize(0,0,128,12,2176).
condition(0,8,128,0,3947).
marginalize(0,0,3946,1,3947).
marginalize(0,0,3882,7,3946).
condition(0,9,256,0,3819).
marginalize(0,0,1771,12,3819).
marginalize(0,0,1707,7,1771).
marginalize(0,0,1579,8,1707).
marginalize(0,0,555,11,1579).
condition(0,10,512,0,3563).
marginalize(0,0,3307,9,3563).
marginalize(0,0,3275,6,3307).
marginalize(0,0,3211,7,3275).
marginalize(0,0,2187,11,3211).
marginalize(0,0,2059,8,2187).
marginalize(0,0,2058,1,2059).
marginalize(0,0,2050,4,2058).
condition(0,11,1024,0,3051).
condition(0,12,2048,0,2027).
marginalize(0,0,1771,9,2027).
condition(0,1,1,0,4058).
condition(0,2,2,0,4057).
condition(0,4,8,0,4051).
condition(0,5,16,0,4043).
condition(0,7,64,0,3995).
marginalize(0,0,3867,8,3995).
marginalize(0,0,3865,2,3867).
marginalize(0,0,3609,9,3865).
marginalize(0,0,1561,12,3609).
marginalize(0,0,1553,4,1561).
condition(0,8,128,0,3931).
condition(0,9,256,0,3803).
marginalize(0,0,3675,8,3803).
condition(0,10,512,0,3547).
marginalize(0,0,1499,12,3547).
marginalize(0,0,475,11,1499).
marginalize(0,0,474,1,475).
marginalize(0,0,472,2,474).
marginalize(0,0,408,7,472).
marginalize(0,0,152,9,408).
marginalize(0,0,24,8,152).
condition(0,11,1024,0,3035).
condition(0,12,2048,0,2011).
marginalize(0,0,1499,10,2011).
condition(0,1,1,0,4026).
condition(0,2,2,0,4025).
condition(0,4,8,0,4019).
condition(0,5,16,0,4011).
condition(0,6,32,0,3995).
condition(0,8,128,0,3899).
condition(0,9,256,0,3771).
marginalize(0,0,3770,1,3771).
condition(0,10,512,0,3515).
marginalize(0,0,1467,12,3515).
marginalize(0,0,1451,5,1467).
marginalize(0,0,1449,2,1451).
marginalize(0,0,1321,8,1449).
marginalize(0,0,1320,1,1321).
marginalize(0,0,1312,4,1320).
marginalize(0,0,1056,9,1312).
condition(0,11,1024,0,3003).
marginalize(0,0,2875,8,3003).
condition(0,12,2048,0,1979).
marginalize(0,0,955,11,1979).
marginalize(0,0,923,6,955).
marginalize(0,0,921,2,923).
marginalize(0,0,665,9,921).
marginalize(0,0,537,8,665).
marginalize(0,0,521,5,537).
condition(0,1,1,0,3962).
condition(0,2,2,0,3961).
condition(0,4,8,0,3955).
condition(0,5,16,0,3947).
condition(0,6,32,0,3931).
condition(0,7,64,0,3899).
condition(0,9,256,0,3707).
marginalize(0,0,3706,1,3707).
marginalize(0,0,2682,11,3706).
marginalize(0,0,2650,6,2682).
marginalize(0,0,2642,4,2650).
condition(0,10,512,0,3451).
marginalize(0,0,3450,1,3451).
marginalize(0,0,3418,6,3450).
marginalize(0,0,2394,11,3418).
marginalize(0,0,2386,4,2394).
marginalize(0,0,338,12,2386).
marginalize(0,0,336,2,338).
condition(0,11,1024,0,2939).
marginalize(0,0,2875,7,2939).
condition(0,12,2048,0,1915).
marginalize(0,0,1914,1,1915).
condition(0,1,1,0,3834).
condition(0,2,2,0,3833).
condition(0,4,8,0,3827).
condition(0,5,16,0,3819).
condition(0,6,32,0,3803).
condition(0,7,64,0,3771).
condition(0,8,128,0,3707).
condition(0,10,512,0,3323).
marginalize(0,0,3259,7,3323).
marginalize(0,0,1211,12,3259).
marginalize(0,0,1195,5,1211).
marginalize(0,0,1187,4,1195).
marginalize(0,0,163,11,1187).
marginalize(0,0,162,1,163).
condition(0,11,1024,0,2811).
marginalize(0,0,2803,4,2811).
condition(0,12,2048,0,1787).
marginalize(0,0,1755,6,1787).
marginalize(0,0,1754,1,1755).
marginalize(0,0,1752,2,1754).
marginalize(0,0,1688,7,1752).
marginalize(0,0,664,11,1688).
marginalize(0,0,152,10,664).
condition(0,1,1,0,3578).
condition(0,2,2,0,3577).
condition(0,4,8,0,3571).
condition(0,5,16,0,3563).
condition(0,6,32,0,3547).
condition(0,7,64,0,3515).
condition(0,8,128,0,3451).
condition(0,9,256,0,3323).
condition(0,11,1024,0,2555).
marginalize(0,0,2427,8,2555).
marginalize(0,0,2426,1,2427).
marginalize(0,0,2418,4,2426).
marginalize(0,0,2386,6,2418).
condition(0,12,2048,0,1531).
condition(0,1,1,0,3066).
condition(0,2,2,0,3065).
condition(0,4,8,0,3059).
condition(0,5,16,0,3051).
condition(0,6,32,0,3035).
condition(0,7,64,0,3003).
condition(0,8,128,0,2939).
condition(0,9,256,0,2811).
condition(0,10,512,0,2555).
condition(0,12,2048,0,1019).
condition(0,1,1,0,2042).
condition(0,2,2,0,2041).
condition(0,4,8,0,2035).
condition(0,5,16,0,2027).
condition(0,6,32,0,2011).
condition(0,7,64,0,1979).
condition(0,8,128,0,1915).
condition(0,9,256,0,1787).
condition(0,10,512,0,1531).
condition(0,11,1024,0,1019).
condition(0,1,1,0,4070).
condition(0,2,2,0,4069).
condition(0,3,4,0,4067).
condition(0,6,32,0,4039).
marginalize(0,0,4035,3,4039).
condition(0,7,64,0,4007).
marginalize(0,0,4005,2,4007).
marginalize(0,0,4004,1,4005).
marginalize(0,0,3492,10,4004).
marginalize(0,0,3460,6,3492).
condition(0,8,128,0,3943).
condition(0,9,256,0,3815).
marginalize(0,0,3303,10,3815).
marginalize(0,0,3239,7,3303).
marginalize(0,0,2215,11,3239).
marginalize(0,0,2183,6,2215).
marginalize(0,0,2182,1,2183).
marginalize(0,0,2180,2,2182).
marginalize(0,0,2176,3,2180).
condition(0,10,512,0,3559).
marginalize(0,0,3527,6,3559).
marginalize(0,0,3525,2,3527).
marginalize(0,0,3397,8,3525).
marginalize(0,0,3141,9,3397).
marginalize(0,0,3140,1,3141).
marginalize(0,0,2116,11,3140).
condition(0,11,1024,0,3047).
marginalize(0,0,3015,6,3047).
condition(0,12,2048,0,2023).
marginalize(0,0,1767,9,2023).
marginalize(0,0,1703,7,1767).
marginalize(0,0,679,11,1703).
marginalize(0,0,167,10,679).
marginalize(0,0,166,1,167).
condition(0,1,1,0,4054).
condition(0,2,2,0,4053).
condition(0,3,4,0,4051).
condition(0,5,16,0,4039).
condition(0,7,64,0,3991).
marginalize(0,0,3987,3,3991).
condition(0,8,128,0,3927).
marginalize(0,0,3415,10,3927).
marginalize(0,0,3413,2,3415).
marginalize(0,0,3412,1,3413).
marginalize(0,0,3156,9,3412).
condition(0,9,256,0,3799).
condition(0,10,512,0,3543).
condition(0,11,1024,0,3031).
condition(0,12,2048,0,2007).
condition(0,1,1,0,4022).
condition(0,2,2,0,4021).
condition(0,3,4,0,4019).
condition(0,5,16,0,4007).
condition(0,6,32,0,3991).
condition(0,8,128,0,3895).
condition(0,9,256,0,3767).
condition(0,10,512,0,3511).
marginalize(0,0,2487,11,3511).
condition(0,11,1024,0,2999).
condition(0,12,2048,0,1975).
marginalize(0,0,1971,3,1975).
marginalize(0,0,1970,1,1971).
marginalize(0,0,946,11,1970).
condition(0,1,1,0,3958).
condition(0,2,2,0,3957).
condition(0,3,4,0,3955).
condition(0,5,16,0,3943).
condition(0,6,32,0,3927).
condition(0,7,64,0,3895).
condition(0,9,256,0,3703).
marginalize(0,0,1655,12,3703).
marginalize(0,0,631,11,1655).
condition(0,10,512,0,3447).
marginalize(0,0,3383,7,3447).
marginalize(0,0,3379,3,3383).
marginalize(0,0,3363,5,3379).
marginalize(0,0,3107,9,3363).
marginalize(0,0,2083,11,3107).
marginalize(0,0,2051,6,2083).
marginalize(0,0,2050,1,2051).
condition(0,11,1024,0,2935).
condition(0,12,2048,0,1911).
marginalize(0,0,887,11,1911).
marginalize(0,0,886,1,887).
marginalize(0,0,884,2,886).
marginalize(0,0,868,5,884).
marginalize(0,0,356,10,868).
marginalize(0,0,100,9,356).
condition(0,1,1,0,3830).
condition(0,2,2,0,3829).
condition(0,3,4,0,3827).
condition(0,5,16,0,3815).
condition(0,6,32,0,3799).
condition(0,7,64,0,3767).
condition(0,8,128,0,3703).
condition(0,10,512,0,3319).
marginalize(0,0,3255,7,3319).
marginalize(0,0,3239,5,3255).
condition(0,11,1024,0,2807).
marginalize(0,0,2806,1,2807).
marginalize(0,0,2742,7,2806).
marginalize(0,0,2726,5,2742).
marginalize(0,0,2722,3,2726).
marginalize(0,0,2210,10,2722).
marginalize(0,0,2082,8,2210).
marginalize(0,0,2080,2,2082).
condition(0,12,2048,0,1783).
marginalize(0,0,1781,2,1783).
marginalize(0,0,1780,1,1781).
marginalize(0,0,756,11,1780).
marginalize(0,0,724,6,756).
marginalize(0,0,212,10,724).
marginalize(0,0,148,7,212).
condition(0,1,1,0,3574).
condition(0,2,2,0,3573).
condition(0,3,4,0,3571).
condition(0,5,16,0,3559).
condition(0,6,32,0,3543).
condition(0,7,64,0,3511).
condition(0,8,128,0,3447).
condition(0,9,256,0,3319).
condition(0,11,1024,0,2551).
condition(0,12,2048,0,1527).
condition(0,1,1,0,3062).
condition(0,2,2,0,3061).
condition(0,3,4,0,3059).
condition(0,5,16,0,3047).
condition(0,6,32,0,3031).
condition(0,7,64,0,2999).
condition(0,8,128,0,2935).
condition(0,9,256,0,2807).
condition(0,10,512,0,2551).
condition(0,12,2048,0,1015).
condition(0,1,1,0,2038).
condition(0,2,2,0,2037).
condition(0,3,4,0,2035).
condition(0,5,16,0,2023).
condition(0,6,32,0,2007).
condition(0,7,64,0,1975).
condition(0,8,128,0,1911).
condition(0,9,256,0,1783).
condition(0,10,512,0,1527).
condition(0,11,1024,0,1015).
condition(0,1,1,0,4046).
condition(0,2,2,0,4045).
condition(0,3,4,0,4043).
condition(0,4,8,0,4039).
condition(0,7,64,0,3983).
condition(0,8,128,0,3919).
condition(0,9,256,0,3791).
marginalize(0,0,3783,4,3791).
marginalize(0,0,3782,1,3783).
marginalize(0,0,3718,7,3782).
marginalize(0,0,3714,3,3718).
marginalize(0,0,3586,8,3714).
marginalize(0,0,3074,10,3586).
marginalize(0,0,2050,11,3074).
condition(0,10,512,0,3535).
marginalize(0,0,3533,2,3535).
marginalize(0,0,3405,8,3533).
marginalize(0,0,3341,7,3405).
marginalize(0,0,2317,11,3341).
marginalize(0,0,269,12,2317).
condition(0,11,1024,0,3023).
condition(0,12,2048,0,1999).
condition(0,1,1,0,4014).
condition(0,2,2,0,4013).
condition(0,3,4,0,4011).
condition(0,4,8,0,4007).
condition(0,6,32,0,3983).
condition(0,8,128,0,3887).
marginalize(0,0,3886,1,3887).
marginalize(0,0,1838,12,3886).
condition(0,9,256,0,3759).
marginalize(0,0,3631,8,3759).
marginalize(0,0,1583,12,3631).
condition(0,10,512,0,3503).
marginalize(0,0,3471,6,3503).
marginalize(0,0,3469,2,3471).
marginalize(0,0,1421,12,3469).
condition(0,11,1024,0,2991).
marginalize(0,0,2983,4,2991).
marginalize(0,0,2982,1,2983).
marginalize(0,0,2980,2,2982).
marginalize(0,0,2976,3,2980).
marginalize(0,0,928,12,2976).
condition(0,12,2048,0,1967).
marginalize(0,0,1935,6,1967).
condition(0,1,1,0,3950).
condition(0,2,2,0,3949).
condition(0,3,4,0,3947).
condition(0,4,8,0,3943).
condition(0,6,32,0,3919).
condition(0,7,64,0,3887).
condition(0,9,256,0,3695).
marginalize(0,0,3631,7,3695).
condition(0,10,512,0,3439).
marginalize(0,0,3435,3,3439).
marginalize(0,0,3434,1,3435).
marginalize(0,0,2410,11,3434).
marginalize(0,0,2402,4,2410).
marginalize(0,0,2370,6,2402).
condition(0,11,1024,0,2927).
condition(0,12,2048,0,1903).
condition(0,1,1,0,3822).
condition(0,2,2,0,3821).
condition(0,3,4,0,3819).
condition(0,4,8,0,3815).
condition(0,6,32,0,3791).
condition(0,7,64,0,3759).
condition(0,8,128,0,3695).
condition(0,10,512,0,3311).
marginalize(0,0,3279,6,3311).
marginalize(0,0,3151,8,3279).
marginalize(0,0,1103,12,3151).
marginalize(0,0,1102,1,1103).
marginalize(0,0,1038,7,1102).
marginalize(0,0,1034,3,1038).
condition(0,11,1024,0,2799).
condition(0,12,2048,0,1775).
marginalize(0,0,1263,10,1775).
condition(0,1,1,0,3566).
condition(0,2,2,0,3565).
condition(0,3,4,0,3563).
condition(0,4,8,0,3559).
condition(0,6,32,0,3535).
condition(0,7,64,0,3503).
condition(0,8,128,0,3439).
condition(0,9,256,0,3311).
condition(0,11,1024,0,2543).
marginalize(0,0,2511,6,2543).
marginalize(0,0,2447,7,2511).
marginalize(0,0,2191,9,2447).
marginalize(0,0,2063,8,2191).
marginalize(0,0,2061,2,2063).
marginalize(0,0,2060,1,2061).
condition(0,12,2048,0,1519).
marginalize(0,0,495,11,1519).
marginalize(0,0,493,2,495).
marginalize(0,0,365,8,493).
marginalize(0,0,109,9,365).
condition(0,1,1,0,3054).
condition(0,2,2,0,3053).
condition(0,3,4,0,3051).
condition(0,4,8,0,3047).
condition(0,6,32,0,3023).
condition(0,7,64,0,2991).
condition(0,8,128,0,2927).
condition(0,9,256,0,2799).
condition(0,10,512,0,2543).
condition(0,12,2048,0,1007).
marginalize(0,0,1005,2,1007).
marginalize(0,0,1001,3,1005).
marginalize(0,0,969,6,1001).
marginalize(0,0,968,1,969).
marginalize(0,0,712,9,968).
marginalize(0,0,648,7,712).
marginalize(0,0,136,10,648).
condition(0,1,1,0,2030).
condition(0,2,2,0,2029).
condition(0,3,4,0,2027).
condition(0,4,8,0,2023).
condition(0,6,32,0,1999).
condition(0,7,64,0,1967).
condition(0,8,128,0,1903).
condition(0,9,256,0,1775).
condition(0,10,512,0,1519).
condition(0,11,1024,0,1007).
condition(0,1,1,0,3998).
condition(0,2,2,0,3997).
condition(0,3,4,0,3995).
condition(0,4,8,0,3991).
condition(0,5,16,0,3983).
condition(0,8,128,0,3871).
marginalize(0,0,2847,11,3871).
marginalize(0,0,2846,1,2847).
condition(0,9,256,0,3743).
marginalize(0,0,3615,8,3743).
marginalize(0,0,2591,11,3615).
marginalize(0,0,543,12,2591).
marginalize(0,0,541,2,543).
marginalize(0,0,533,4,541).
marginalize(0,0,532,1,533).
condition(0,10,512,0,3487).
condition(0,11,1024,0,2975).
marginalize(0,0,2967,4,2975).
marginalize(0,0,2455,10,2967).
condition(0,12,2048,0,1951).
marginalize(0,0,1950,1,1951).
marginalize(0,0,1948,2,1950).
marginalize(0,0,1436,10,1948).
marginalize(0,0,1180,9,1436).
marginalize(0,0,1164,5,1180).
marginalize(0,0,1156,4,1164).
condition(0,1,1,0,3934).
condition(0,2,2,0,3933).
condition(0,3,4,0,3931).
condition(0,4,8,0,3927).
condition(0,5,16,0,3919).
condition(0,7,64,0,3871).
condition(0,9,256,0,3679).
condition(0,10,512,0,3423).
marginalize(0,0,3359,7,3423).
marginalize(0,0,3351,4,3359).
marginalize(0,0,3349,2,3351).
marginalize(0,0,3345,3,3349).
marginalize(0,0,2321,11,3345).
marginalize(0,0,2065,9,2321).
condition(0,11,1024,0,2911).
marginalize(0,0,2399,10,2911).
marginalize(0,0,2335,7,2399).
marginalize(0,0,2333,2,2335).
marginalize(0,0,2329,3,2333).
marginalize(0,0,2313,5,2329).
marginalize(0,0,2305,4,2313).
marginalize(0,0,2304,1,2305).
condition(0,12,2048,0,1887).
marginalize(0,0,1879,4,1887).
marginalize(0,0,1815,7,1879).
marginalize(0,0,1813,2,1815).
marginalize(0,0,1557,9,1813).
marginalize(0,0,1556,1,1557).
marginalize(0,0,1552,3,1556).
condition(0,1,1,0,3806).
condition(0,2,2,0,3805).
condition(0,3,4,0,3803).
condition(0,4,8,0,3799).
condition(0,5,16,0,3791).
condition(0,7,64,0,3743).
condition(0,8,128,0,3679).
condition(0,10,512,0,3295).
marginalize(0,0,3279,5,3295).
condition(0,11,1024,0,2783).
marginalize(0,0,2782,1,2783).
marginalize(0,0,2766,5,2782).
marginalize(0,0,718,12,2766).
marginalize(0,0,206,10,718).
marginalize(0,0,204,2,206).
marginalize(0,0,140,7,204).
marginalize(0,0,12,8,140).
condition(0,12,2048,0,1759).
marginalize(0,0,1631,8,1759).
marginalize(0,0,1567,7,1631).
marginalize(0,0,1055,10,1567).
marginalize(0,0,1053,2,1055).
marginalize(0,0,1037,5,1053).
marginalize(0,0,1036,1,1037).
condition(0,1,1,0,3550).
condition(0,2,2,0,3549).
condition(0,3,4,0,3547).
condition(0,4,8,0,3543).
condition(0,5,16,0,3535).
condition(0,7,64,0,3487).
condition(0,8,128,0,3423).
condition(0,9,256,0,3295).
condition(0,11,1024,0,2527).
marginalize(0,0,2399,8,2527).
condition(0,12,2048,0,1503).
marginalize(0,0,1495,4,1503).
marginalize(0,0,1491,3,1495).
marginalize(0,0,1475,5,1491).
marginalize(0,0,1219,9,1475).
marginalize(0,0,1155,7,1219).
marginalize(0,0,131,11,1155).
marginalize(0,0,129,2,131).
condition(0,1,1,0,3038).
condition(0,2,2,0,3037).
condition(0,3,4,0,3035).
condition(0,4,8,0,3031).
condition(0,5,16,0,3023).
condition(0,7,64,0,2975).
condition(0,8,128,0,2911).
condition(0,9,256,0,2783).
condition(0,10,512,0,2527).
condition(0,12,2048,0,991).
marginalize(0,0,975,5,991).
marginalize(0,0,911,7,975).
marginalize(0,0,399,10,911).
marginalize(0,0,143,9,399).
marginalize(0,0,142,1,143).
marginalize(0,0,140,2,142).
condition(0,1,1,0,2014).
condition(0,2,2,0,2013).
condition(0,3,4,0,2011).
condition(0,4,8,0,2007).
condition(0,5,16,0,1999).
condition(0,7,64,0,1951).
condition(0,8,128,0,1887).
condition(0,9,256,0,1759).
condition(0,10,512,0,1503).
condition(0,11,1024,0,991).
condition(0,1,1,0,3902).
condition(0,2,2,0,3901).
condition(0,3,4,0,3899).
condition(0,4,8,0,3895).
condition(0,5,16,0,3887).
condition(0,6,32,0,3871).
condition(0,9,256,0,3647).
marginalize(0,0,3645,2,3647).
marginalize(0,0,3641,3,3645).
marginalize(0,0,3633,4,3641).
marginalize(0,0,1585,12,3633).
marginalize(0,0,1553,6,1585).
condition(0,10,512,0,3391).
marginalize(0,0,3359,6,3391).
condition(0,11,1024,0,2879).
marginalize(0,0,2878,1,2879).
marginalize(0,0,2874,3,2878).
marginalize(0,0,2866,4,2874).
marginalize(0,0,2354,10,2866).
condition(0,12,2048,0,1855).
marginalize(0,0,1823,6,1855).
marginalize(0,0,1567,9,1823).
condition(0,1,1,0,3774).
condition(0,2,2,0,3773).
condition(0,3,4,0,3771).
condition(0,4,8,0,3767).
condition(0,5,16,0,3759).
condition(0,6,32,0,3743).
condition(0,8,128,0,3647).
condition(0,10,512,0,3263).
marginalize(0,0,3259,3,3263).
condition(0,11,1024,0,2751).
marginalize(0,0,703,12,2751).
marginalize(0,0,699,3,703).
marginalize(0,0,571,8,699).
marginalize(0,0,555,5,571).
condition(0,12,2048,0,1727).
condition(0,1,1,0,3518).
condition(0,2,2,0,3517).
condition(0,3,4,0,3515).
condition(0,4,8,0,3511).
condition(0,5,16,0,3503).
condition(0,6,32,0,3487).
condition(0,8,128,0,3391).
condition(0,9,256,0,3263).
condition(0,11,1024,0,2495).
marginalize(0,0,2367,8,2495).
marginalize(0,0,2366,1,2367).
marginalize(0,0,318,12,2366).
marginalize(0,0,314,3,318).
marginalize(0,0,298,5,314).
marginalize(0,0,296,2,298).
marginalize(0,0,288,4,296).
condition(0,12,2048,0,1471).
marginalize(0,0,1470,1,1471).
marginalize(0,0,446,11,1470).
marginalize(0,0,444,2,446).
marginalize(0,0,428,5,444).
marginalize(0,0,172,9,428).
marginalize(0,0,168,3,172).
condition(0,1,1,0,3006).
condition(0,2,2,0,3005).
condition(0,3,4,0,3003).
condition(0,4,8,0,2999).
condition(0,5,16,0,2991).
condition(0,6,32,0,2975).
condition(0,8,128,0,2879).
condition(0,9,256,0,2751).
condition(0,10,512,0,2495).
condition(0,12,2048,0,959).
marginalize(0,0,927,6,959).
marginalize(0,0,926,1,927).
marginalize(0,0,918,4,926).
marginalize(0,0,902,5,918).
marginalize(0,0,900,2,902).
marginalize(0,0,896,3,900).
marginalize(0,0,384,10,896).
condition(0,1,1,0,1982).
condition(0,2,2,0,1981).
condition(0,3,4,0,1979).
condition(0,4,8,0,1975).
condition(0,5,16,0,1967).
condition(0,6,32,0,1951).
condition(0,8,128,0,1855).
condition(0,9,256,0,1727).
condition(0,10,512,0,1471).
condition(0,11,1024,0,959).
condition(0,1,1,0,3710).
condition(0,2,2,0,3709).
condition(0,3,4,0,3707).
condition(0,4,8,0,3703).
condition(0,5,16,0,3695).
condition(0,6,32,0,3679).
condition(0,7,64,0,3647).
condition(0,10,512,0,3199).
marginalize(0,0,3183,5,3199).
marginalize(0,0,3181,2,3183).
marginalize(0,0,3180,1,3181).
marginalize(0,0,3176,3,3180).
marginalize(0,0,3112,7,3176).
marginalize(0,0,1064,12,3112).
marginalize(0,0,40,11,1064).
condition(0,11,1024,0,2687).
condition(0,12,2048,0,1663).
condition(0,1,1,0,3454).
condition(0,2,2,0,3453).
condition(0,3,4,0,3451).
condition(0,4,8,0,3447).
condition(0,5,16,0,3439).
condition(0,6,32,0,3423).
condition(0,7,64,0,3391).
condition(0,9,256,0,3199).
condition(0,11,1024,0,2431).
marginalize(0,0,2423,4,2431).
condition(0,12,2048,0,1407).
marginalize(0,0,1391,5,1407).
condition(0,1,1,0,2942).
condition(0,2,2,0,2941).
condition(0,3,4,0,2939).
condition(0,4,8,0,2935).
condition(0,5,16,0,2927).
condition(0,6,32,0,2911).
condition(0,7,64,0,2879).
condition(0,9,256,0,2687).
condition(0,10,512,0,2431).
condition(0,12,2048,0,895).
condition(0,1,1,0,1918).
condition(0,2,2,0,1917).
condition(0,3,4,0,1915).
condition(0,4,8,0,1911).
condition(0,5,16,0,1903).
condition(0,6,32,0,1887).
condition(0,7,64,0,1855).
condition(0,9,256,0,1663).
condition(0,10,512,0,1407).
condition(0,11,1024,0,895).
condition(0,1,1,0,3326).
condition(0,2,2,0,3325).
condition(0,3,4,0,3323).
condition(0,4,8,0,3319).
condition(0,5,16,0,3311).
condition(0,6,32,0,3295).
condition(0,7,64,0,3263).
condition(0,8,128,0,3199).
condition(0,11,1024,0,2303).
marginalize(0,0,2271,6,2303).
marginalize(0,0,2270,1,2271).
condition(0,12,2048,0,1279).
condition(0,1,1,0,2814).
condition(0,2,2,0,2813).
condition(0,3,4,0,2811).
condition(0,4,8,0,2807).
condition(0,5,16,0,2799).
condition(0,6,32,0,2783).
condition(0,7,64,0,2751).
condition(0,8,128,0,2687).
condition(0,10,512,0,2303).
condition(0,12,2048,0,767).
marginalize(0,0,751,5,767).
marginalize(0,0,750,1,751).
marginalize(0,0,718,6,750).
condition(0,1,1,0,1790).
condition(0,2,2,0,1789).
condition(0,3,4,0,1787).
condition(0,4,8,0,1783).
condition(0,5,16,0,1775).
condition(0,6,32,0,1759).
condition(0,7,64,0,1727).
condition(0,8,128,0,1663).
condition(0,10,512,0,1279).
condition(0,11,1024,0,767).
condition(0,1,1,0,2558).
condition(0,2,2,0,2557).
condition(0,3,4,0,2555).
condition(0,4,8,0,2551).
condition(0,5,16,0,2543).
condition(0,6,32,0,2527).
condition(0,7,64,0,2495).
condition(0,8,128,0,2431).
condition(0,9,256,0,2303).
condition(0,12,2048,0,511).
marginalize(0,0,503,4,511).
marginalize(0,0,471,6,503).
marginalize(0,0,407,7,471).
condition(0,1,1,0,1534).
condition(0,2,2,0,1533).
condition(0,3,4,0,1531).
condition(0,4,8,0,1527).
condition(0,5,16,0,1519).
condition(0,6,32,0,1503).
condition(0,7,64,0,1471).
condition(0,8,128,0,1407).
condition(0,9,256,0,1279).
condition(0,11,1024,0,511).
condition(0,1,1,0,1022).
condition(0,2,2,0,1021).
condition(0,3,4,0,1019).
condition(0,4,8,0,1015).
condition(0,5,16,0,1007).
condition(0,6,32,0,991).
condition(0,7,64,0,959).
condition(0,8,128,0,895).
condition(0,9,256,0,767).
condition(0,10,512,0,511).
